export default {
  'component.tagSelect.expand': '展开',
  'component.tagSelect.collapse': '收起',
  'component.tagSelect.all': '全部',
  'component.tagSelect.ph': '请选择',
  'component.text.send': '发送给 ...',
  'component.button.send': '发送',
  'component.authorized.none': '对不起，您没有权限访问这个页面',
  'component.page.none': '对不起，您访问的页面不存在',
  'component.back.home': '返回登录',
  'component.go.login': '去登录',
};

import React, { Component } from 'react';
import { SketchPicker, ColorResult } from 'react-color';
import { rgba2Obj } from '@/utils/tool';

export type ColorConfigType = string;
export type OpenType = 'top' | 'bottom';

interface ColorProps {
    open?: OpenType;
    value?: ColorConfigType;
    onChange?: (v: ColorConfigType) => void;
}

class ColorPicker extends Component<ColorProps> {
    state = {
        displayColorPicker: false,
        color: rgba2Obj(this.props.value),
    };

    handleClick = () => {
        this.setState({ displayColorPicker: !this.state.displayColorPicker });
    };

    handleClose = () => {
        this.setState({ displayColorPicker: false });
    };

    handleChange = (c: ColorResult) => {
        this.setState({ color: c.rgb });
        this.props.onChange &&
            this.props.onChange(`rgba(${c.rgb.r},${c.rgb.g},${c.rgb.b},${c.rgb.a})`);
    };

    render() {
        const { open } = this.props;

        return (
            <>
                <div
                    style={{
                        background: '#fff',
                        borderRadius: '1px',
                        boxShadow: '0 0 0 1px rgba(0,0,0,.1)',
                        display: 'inline-block',
                        cursor: 'pointer',
                        width: '100%',
                    }}
                    onClick={this.handleClick}
                >
                    <div
                        style={{
                            width: '100%',
                            height: '30px',
                            borderRadius: '2px',
                            background: `rgba(${this.state.color.r}, ${this.state.color.g}, ${this.state.color.b}, ${this.state.color.a})`,
                        }}
                    /></div>
                {
                    this.state.displayColorPicker ? (
                        <React.Fragment>
                            <div
                                style={
                                    open === 'top' ? {
                                        position: 'absolute',
                                        bottom: 40,
                                        zIndex: 2000,
                                    } : {
                                            position: 'absolute',
                                            top: 32,
                                            zIndex: 2000,
                                        }
                                }
                            >
                                <SketchPicker color={this.state.color} onChange={this.handleChange} />
                            </div>
                            <div
                                style={{
                                    position: 'fixed',
                                    top: 0,
                                    right: 0,
                                    bottom: 0,
                                    left: 0,
                                    zIndex: 1000,
                                }}
                                onClick={this.handleClose}
                            />
                        </React.Fragment>
                    ) : null
                }
            </>
        )
    }
}

export default ColorPicker;
export interface IColorConfigType {
    key: string;
    name: string;
    type: 'Color';
    open: 'top' | 'bottom';
}

export interface INumberConfigType {
    key: string;
    name: string;
    type: 'Number';
    range?: [number,number];
    step?: number;
}

// generics interface
export interface ISelectConfigType<T> {
    key: string;
    name: string;
    type: 'Select';
    range: Array<{
        key: string;
        value: T;
    }>;
}

export interface ICascadeConfigType {
    key: string;
    type: 'Cascade';
    associated: string;
    range: Array<{
        key: string;
        value: string;
    }>, 
}

export interface ITextConfigType {
    key: string;
    name: string;
    type: 'Text';
    maxLength: number;
}

export interface ITitleConfigType {
    key: string;
    name: string;
    type: 'Text';
    maxLength?: number;
}

export interface IRadioConfigType {
    key: string;
    name: string;
    type: 'Radio';
    range: Array<{
        key: string;
        value: boolean;
    }>;
}

export interface IOptionConfigType {
    key: string;
    name: string;
    type: 'Option';
    maxLength: number;
    options: string [];
}

export interface IMaxLengthType {
    key: string;
    name: string;
    type: 'Number';
}

export interface IUploadConfigType{
    key: string;
    name: string;
    type: 'Upload';
}

// type alias
export type TColorDefaultType = string;

export type TNumberDefaultType = number;

export type TSelectDefaultType<KeyType> = KeyType;

export type TTextDefaultType = string;

export type TUploadDefaultType = Array<{
    uid: string;
    name: string;
    status: string;
    url: string;
}>;
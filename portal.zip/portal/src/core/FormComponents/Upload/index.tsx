import React, { useState, useMemo } from 'react';
import { UploadFile, UploadChangeParam, RcFile } from 'antd/lib/upload/interface';
import { Button, Upload, Modal, message } from 'antd';
import ImgCrop from 'antd-img-crop';
import API from '@/services/api';
import Cookie from "js-cookie";
const styles = require('./index.less');

const getBase64 = (file: File | Blob) => {
    return new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.readAsDataURL(file);
        reader.onload = () => resolve(reader.result as string);
    });
}

interface IPropType {
    isCrop?: boolean;
    maxLen?: number;
    cropRate?: number;
    fileList?: UploadFile<any>[];
    onChange?: (v: any) => void;
}

const Index = (props: IPropType) => {
    const {
        isCrop,
        maxLen = 1,
        cropRate = 375 / 158,
    } = props;
    const [fileList, handleFileList] = useState(props.fileList || []);
    const [previewVisible, handlePreviewVisible] = useState(false);
    const [previewImage, handlePreviewImage] = useState('');
    const [previewTitle, handlePreviewTitle] = useState('');
    const uploadButton = useMemo(() => {
        if (fileList.length >= maxLen) {
            return (<Button>更换图片</Button>)
        }
        return (<Button>上传图片</Button>)
    }, [fileList.length, maxLen]);
    const handlePreview = async (file: UploadFile<any>) => {
        if (!file.url && !file.preview) {
            file.preview = await getBase64(file.originFileObj!);
        }
        handlePreviewImage(file.url || file.preview!);
        handlePreviewVisible(true);
        handlePreviewTitle(file.name || file.url!.substring(file.url!.lastIndexOf('/') + 1));
    };
    const handleChange = ({ file, fileList }: UploadChangeParam<UploadFile<any>>) => {
        if (fileList.length > 1) fileList.splice(0, 1)
        handleFileList(fileList);
        if (file.status === 'done') {
            const files = fileList.map(item => {
                const { uid, name, status } = item;
                const url = item.url || item.response.data;
                return { uid, name, status, url };
            });
            props.onChange && props.onChange(files);
        }
    };
    const handleBeforeUpload = (file: RcFile) => {
        const isJpgOrPng = file.type === 'image/jpeg' ||
            file.type === 'image/png' ||
            file.type === 'image/jpg' ||
            file.type === 'image/gif';
        if (!isJpgOrPng) {
            message.error('只能上传格式为jpeg,png,gif的图片!');
        }
        const isLt2M = file.size / 1024 / 1024 < 2;
        if (!isLt2M) {
            message.error('图片大小必须小于2MB!');
        }
        return isJpgOrPng && isLt2M;
    }
    const handleCancel = () => handlePreviewVisible(false)

    return (
        <>
            {
                isCrop ? (
                    <ImgCrop
                        aspect={cropRate}
                        modalTitle="裁剪图片"
                        modalOk="确定"
                        modalCancel="取消"
                        rotate={true}
                    >
                        <Upload
                            action={API.HFMANAGE.UPLOAD}
                            name="file"
                            fileList={fileList}
                            listType={"picture-card"}
                            className={styles.avatarUploader}
                            beforeUpload={handleBeforeUpload}
                            onChange={handleChange}
                            onPreview={handlePreview}
                            headers={{
                                'X-XSRF-TOKEN': Cookie.get('XSRF-TOKEN')
                            }}
                        >
                            {uploadButton}
                        </Upload>
                    </ImgCrop>
                ) : (
                        <Upload
                            action={API.HFMANAGE.UPLOAD}
                            name="file"
                            fileList={fileList}
                            listType={"picture-card"}
                            className={styles.avatarUploader}
                            beforeUpload={handleBeforeUpload}
                            onChange={handleChange}
                            onPreview={handlePreview}
                            headers={{
                                'X-XSRF-TOKEN': Cookie.get('XSRF-TOKEN')
                            }}
                        >
                            {uploadButton}
                        </Upload>
                    )
            }
            <Modal
                visible={previewVisible}
                title={previewTitle}
                footer={null}
                onCancel={handleCancel}
            >
                <img alt="预览图片" style={{ width: '100%' }} src={previewImage} />
            </Modal>
        </>
    )
}

export default Index;

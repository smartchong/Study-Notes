import { dynamic } from 'umi';
import React,{ FC,memo,useMemo,useContext } from 'react';
import { context,contextType } from '@/layouts/H5Layout';
import Loading from '@/components/Loading';

export type componentsType = 'base' | 'option' | 'date' | 'readonly' | 'page' | 'template';

type DynamicType = {
    isTpl: boolean;
    config: {
        [key: string]: any 
    };
    type: string;
    componentsType: componentsType;
    category: string;
}

const DynamicFunc = (type: string, componentsType: string, context: contextType) => {
    const prefix = context === 'pc' ? 'PC' : '';
    return dynamic({
        loader: async function() {
            let Component: FC<{ isTpl: boolean }>;
            if (componentsType) {
                const { default: Graph } = await import(
                    `@/components/Basic${prefix}Shop/${componentsType.substr(0,1).toUpperCase()}${componentsType.substr(1)}Components/${type}`
                );  
                Component = Graph;
            }
            return (props: DynamicType) => {
                const { config,isTpl } = props;
                return <Component {...config} isTpl={isTpl} />
            };
        },
        loading: () => {
            return (
                <div 
                    style={{ paddingTop: 10, textAlign: 'center' }}
                >
                    <Loading />
                </div>
            )
        }
    })
}
const DynamicEngine = (props: DynamicType) => {
    const { type, config, category } = props;
    const ctx = useContext(context);
    const Dynamic = useMemo(() => {
      return (DynamicFunc(type, category, ctx.theme) as unknown) as FC<DynamicType>;
      // eslint-disable-next-line react-hooks/exhaustive-deps
    }, [config, ctx.theme]);
  
    return <Dynamic {...props} />;
};

export default memo(DynamicEngine);
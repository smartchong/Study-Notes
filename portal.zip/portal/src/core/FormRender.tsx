import React,{ memo,useEffect } from 'react';
import { Form,Input,InputNumber,Radio,Select,Button } from 'antd';
import { Store } from 'antd/lib/form/interface';
import Color from './FormComponents/Color';
import Upload from './FormComponents/Upload';
import { MinusCircleOutlined,PlusOutlined } from '@ant-design/icons';

interface FromEditorProps {
    uid: string;
    onSave: Function;
    onDel: Function;
    config: Array<any>;
    defaultValue: { [key: string]: any };
}

const normFile = (e: any) => {
    if (Array.isArray(e)) {
        return e;
    }
    return e && e.fileList;
}
const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 16 },
};

const formItemLayoutWithOutLabel = {
    wrapperCol: {
        span: 16,
        offset: 6,
    },
};
const { Option } = Select;

const FormEditor = (props: FromEditorProps) => {
    const { config, defaultValue, onSave, uid } = props;
    const [form] = Form.useForm();
    const onFinish = (values: Store) => {
        onSave && onSave(values);
    };
    const handlechange = () => {
        let values = form.getFieldsValue();
        if (values.hasOwnProperty('options')) {
            values.options = values.options.filter((item:any) => item !== undefined)
        }
        onFinish(values);
    };
    useEffect(() => {
        return () => {
            form.resetFields();
        }
    },[uid,form]);

    return (
        <Form
            form={form}
            onFinish={onFinish}
            onValuesChange={handlechange}
            initialValues={defaultValue}
            {...formItemLayout}
        >
            {
                config.map((item,i) => {
                    return (
                        <React.Fragment key={i}>
                            {
                                item.type === 'Color' && (
                                    <Form.Item label={item.name} name={item.key}>
                                      <Color open={item.open} />
                                    </Form.Item>
                                )
                            }
                            {
                                item.type === 'Number' && (
                                    <Form.Item label={item.name} name={item.key}>
                                        <InputNumber style={{ width:'100%' }} max={item.range && item.range[1]} />
                                    </Form.Item>
                                )
                            }
                            {
                                item.type === 'Select' && (
                                    <Form.Item label={item.name} name={item.key}>
                                        <Select placeholder="请选择">
                                            {
                                                item.range.map((v: any, i: number) => {
                                                    return (
                                                        <Option value={v.value} key={i}>
                                                            {v.key}
                                                        </Option>
                                                    );
                                                })
                                            }
                                        </Select>
                                    </Form.Item>
                                ) 
                            }
                            {
                                item.type === 'Cascade' && (
                                    <Form.Item
                                        noStyle
                                        shouldUpdate={(prevValues, curValues) => prevValues[item.associated] !== curValues[item.associated]}
                                    >
                                        {
                                            ({ getFieldValue }) => {
                                                const val = getFieldValue(item.associated);
                                                if (!val) return null
                                                return (
                                                    <Form.Item label={item.range.find((it: any)  => it.value === val).key} name={item.key}>
                                                        <Input />
                                                    </Form.Item>
                                                )
                                            }
                                        }        
                                    </Form.Item>
                                ) 
                            }
                            {
                                item.type === 'Text' && (
                                    <Form.Item label={item.name} name={item.key}>
                                      {
                                          item.maxLength ? (
                                            <Input maxLength={item.maxLength} />
                                          ) : (
                                            <Input />
                                          )
                                      }        
                                    </Form.Item>
                                )
                            }
                            {
                                item.type === 'Radio' && (
                                    <Form.Item label={item.name} name={item.key}>
                                        <Radio.Group>
                                            {
                                                item.range.map((v: any, i: number) => {
                                                    return (
                                                        <Radio value={v.value} key={i}>{v.key}</Radio>
                                                    )
                                                })
                                            }
                                        </Radio.Group>
                                    </Form.Item>
                                )
                            }
                            {
                                item.type === 'Upload' && (
                                    <Form.Item
                                        label={item.name}
                                        name={item.key}
                                        valuePropName={"fileList"}
                                        getValueFromEvent={normFile}
                                    >
                                        <Upload cropRate={item.cropRate} isCrop={item.isCrop} />
                                    </Form.Item>
                                ) 
                            }
                            {
                                item.type === 'Option' && (
                                    <Form.List
                                        name={item.key}
                                    > 
                                        {
                                            (fields,{ add, remove }) => (
                                                <>
                                                    {
                                                        fields.map((field,index) => {
                                                            return (
                                                                (
                                                                    <Form.Item
                                                                        {...(index === 0 ? formItemLayout : formItemLayoutWithOutLabel)}
                                                                        label={index === 0 ? item.name : ''}
                                                                        key={field.key}
                                                                    >
                                                                        <Form.Item
                                                                            {...field}
                                                                            noStyle
                                                                        >
                                                                            <Input maxLength={item.maxLength} style={{ width: '80%' }} />
                                                                        </Form.Item>
                                                                        {
                                                                           fields.length > 1 ? (
                                                                                <MinusCircleOutlined
                                                                                    style={{
                                                                                        position: 'relative',
                                                                                        top: 4,
                                                                                        fontSize: 24,
                                                                                        marginLeft: 10,
                                                                                    }}
                                                                                    onClick={() => {
                                                                                        remove(field.name);
                                                                                    }}
                                                                                />      
                                                                           ) : null  
                                                                        }
                                                                    </Form.Item>
                                                                )
                                                            )
                                                        })
                                                    }
                                                    {
                                                        fields.length > 0 && fields.length < 3 ? (
                                                            <Form.Item
                                                                {...formItemLayoutWithOutLabel} 
                                                            >
                                                                <Button
                                                                    type="dashed"
                                                                    style={{ width:'80%' }}
                                                                    onClick={() => add("")}
                                                                    icon={<PlusOutlined />}
                                                                >
                                                                    添加选项
                                                                </Button>
                                                            </Form.Item>
                                                        ) : null
                                                    }
                                                </>
                                            )
                                        }
                                    </Form.List>
                                )
                            }
                        </React.Fragment>
                    )
                })
            }
        </Form>
    )
}

export default memo(FormEditor);
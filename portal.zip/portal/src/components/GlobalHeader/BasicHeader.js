import React from 'react';
import { Layout, Space, Button, Divider, Popover } from 'antd';
import { connect, history } from 'umi';
import styles from './BasicHeader.less';
const BasicHeader = (props) => {
  const { currentUser, dispatch} = props;
  const content = (
    <div
      className={styles.popoverContent}
    >
      <p
        onClick={() => {
          currentUser && currentUser.name
            ? gotoPage('/layouts/app/list')
            : gotoPage('/user/login');
        }}
      >
        5G消息
      </p>
      <p
        onClick={() => {
          // const { currentUser } = props;
          if (currentUser?.name) {
            if (currentUser.verifyStatus === 1) {
              gotoPage('/cloudCard/vCard/my');
            } else {
              Modal.warning({
                title: '提示',
                content: '您还未完成认证信息审核，请先完成再使用该场景服务。',
                okText: '确定',
                onOk: () => {
                  gotoPage('/layouts/userCenter/authInfo');
                },
              });
            }
          } else {
            history.push({
              pathname: '/user/login',
              state: {
                to: 'cloudCard',
              },
            });
          }
        }}
      >
        云名片
      </p>
    </div>
  );
  const gotoPage = (href) => {
    if (href === 'signOut') {
      if (dispatch) {
        dispatch({
          type: 'user/signOut',
        });
      }
      return;
    }
    if (history.location.pathname !== href) {
      history.push({
        pathname: href,
      });
    }
    history.push({
      pathname: href,
      state: {},
    });
  };

  return (
    <Layout.Header className={styles.header}>
      <div className="wrap">
        <div onClick={() => gotoPage('/')}>
          <div className="logo" />
          <Divider type="vertical" />
          <h1>5G智慧家庭Chatbot服务平台</h1>
        </div>
        <div>
          <Space size={50}>
            <Popover className={styles.popover} content={content} placement="bottom" title="" trigger="hover">
              <Button className={styles.indexBtn} type="link">
                产品服务
              </Button>
            </Popover>  
            {currentUser && currentUser.name ? (
              <div>
                <Button
                  type="link"
                  className={styles.userName}
                  onClick={() => gotoPage('/layouts/app/list')}
                >
                  {localStorage.getItem('name')}
                </Button>
                <Button
                  type="link"
                  className={styles.logoutBtn}
                  onClick={() => gotoPage('signOut')}
                >
                  退出
                </Button>
              </div>
            ) : (
              <Space size={10}>
                <Button
                  className={styles.headerBtn}
                  type="primary"
                  onClick={() => gotoPage('/user/login')}
                >
                  登录
                </Button>
                <Button
                  className={styles.headerBtn}
                  type="primary"
                  onClick={() => gotoPage('/user/register')}
                >
                  注册
                </Button>
              </Space>
            )}
          </Space>
        </div>
      </div>
    </Layout.Header>
  );
};

export default connect(({ global, settings, user }) => ({
  collapsed: global.collapsed,
  settings,
  currentUser: user.currentUser,
}))(BasicHeader);

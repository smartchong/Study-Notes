const template = {
    type: 'Name',
    h: 23,
    displayName: '姓名', 
};

export default template;
import {
    ITitleConfigType,
    IRadioConfigType,
    IMaxLengthType,
} from '@/core/FormComponents/types';

export type TNameEditData = Array<
    ITitleConfigType | IRadioConfigType | IMaxLengthType
>;

export interface INameConfig {
    title: string;
    maxLength: number;
    required: boolean;
}

export interface INameSchema {
    editData: TNameEditData;
    config: INameConfig;
}

const Input: INameSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 30,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
        {
            key: 'maxLength',
            name: '最大长度',
            type: 'Number',
        },
    ],
    config:{
        title: '姓名',
        required: false,
        maxLength: 20,
    }
}

export default Input;
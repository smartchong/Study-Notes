import React,{ memo,useMemo } from 'react';
import { IInputConfig } from './schema';
import logo from '@/assets/input.svg';
import { List, InputItem } from 'antd-mobile';
import styles from './index.less';

const Input = memo((props: IInputConfig & { isTpl: boolean }) => {
    const { title,required,maxLength,isTpl } = props; 
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required]);

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List className={styles.inputWrapper}>
                        <InputItem 
                            maxLength={maxLength}
                        >
                            {title}
                            {requiredMark}
                        </InputItem>
                    </List>
                )   
            }
        </>
    );
});

export default Input;
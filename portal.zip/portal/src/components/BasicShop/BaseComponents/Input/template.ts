const template = {
    type: 'Input',
    h: 23,
    displayName: '文本输入框', 
};

export default template;
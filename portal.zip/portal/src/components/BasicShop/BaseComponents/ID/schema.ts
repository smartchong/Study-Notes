import {
    ITitleConfigType,
    IRadioConfigType,
} from '@/core/FormComponents/types';

export type TIDEditData = Array<
    ITitleConfigType | IRadioConfigType
>;

export interface IIDConfig {
    title: string;
    maxLength: number;
    required: boolean;
}

export interface IIDSchema {
    editData: TIDEditData;
    config: IIDConfig;
}

const ID: IIDSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 30,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
    ],
    config:{
        title: '身份证号',
        required: false,
        maxLength: 18,
    }
}

export default ID;
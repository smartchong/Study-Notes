import React,{ memo,useMemo } from 'react';
import { IIDConfig } from './schema';
import logo from '@/assets/id.svg';
import { List, InputItem } from 'antd-mobile';
import styles from './index.less';

const ID = memo((props: IIDConfig & { isTpl: boolean }) => {
    const { title,required,maxLength,isTpl } = props; 
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required])

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List className={styles.inputWrapper}>
                        <InputItem 
                            maxLength={maxLength}
                        >
                            {title}
                            {requiredMark}
                        </InputItem>
                    </List>
                )   
            }
        </>
    );
});

export default ID;
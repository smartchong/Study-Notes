const template = {
    type: 'ID',
    h: 23,
    displayName: '身份证号', 
};

export default template;
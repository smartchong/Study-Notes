/**
 * 基础类型：
 * （1）文本 Text    
 * （2）文本输入框 Input    
 * （3）多行文本框 Textarea 
 * （4）数字输入框 NumberInput 
 * （5）姓名 Name
 * （6）邮箱 Email 
 * （7）电话号码 Tel
 * （8）身份证号 ID    
 * （9）图片 Image
 */
import Text from './Text/template';
import Input from './Input/template';
import Textarea from './Textarea/template';
import NumberInput from './NumberInput/template';
import Name from './Name/template';
import Email from './Email/template';
import Tel from './Tel/template';
import ID from './ID/template';
import Image from './Image/template';

const basicTemplate = [
    Text,
    Input,
    Textarea,
    NumberInput,
    Name,
    Email,
    Tel,
    ID,
    Image,
];
const BasicTemplate = basicTemplate.map(v => {
    return { ...v, category: 'base' };
});

export default BasicTemplate;


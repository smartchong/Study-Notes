const template = {
    type: 'Text',
    h: 20,
    displayName: '文字', 
};

export default template;
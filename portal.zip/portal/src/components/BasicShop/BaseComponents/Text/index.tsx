import React, { memo } from 'react';
import { ITextConfig } from './schema';
import logo from '@/assets/text.svg';

const Text = memo((props: ITextConfig & { isTpl: boolean }) => {
  const { align, text, fontSize, color, lineHeight, isTpl } = props;

  return (
    <>
      {
        isTpl ? (
          <div>
            <img src={logo} />
          </div>
        ) : (
            <div
              style={{
                color,
                textAlign: align,
                fontSize,
                height: '40px',
                lineHeight: '40px',
                background: '#fff',
                borderBottom: '2px solid #f8f8f8',
              }}
            >
              {text}
            </div>
          )
      }
    </>
  );
});

export default Text;
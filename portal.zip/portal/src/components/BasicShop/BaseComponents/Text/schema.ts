import {
    IColorConfigType,
    INumberConfigType,
    ISelectConfigType,
    ITextConfigType,
    TColorDefaultType,
    TNumberDefaultType,
    TSelectDefaultType,
    TTextDefaultType,
} from '@/core/FormComponents/types';

// literal type of string
export type TTextSelectKeyType = 'left' | 'center' | 'right';

export type TTextEditData = Array<
    ITextConfigType | IColorConfigType | INumberConfigType | ISelectConfigType<string> | ISelectConfigType<number> 
>;

export interface ITextConfig {
    text: TTextDefaultType;
    color: TColorDefaultType;
    fontSize: TNumberDefaultType;
    align: TSelectDefaultType<TTextSelectKeyType>;
    lineHeight: TNumberDefaultType;
}

export interface ITextSchema {
    editData: TTextEditData;
    config: ITextConfig;
}

const Text: ITextSchema = {
    editData: [
        {
            key: 'text',
            name: '文字',
            type: 'Text',
            maxLength: 1000,
        },
        {
            key: 'fontSize',
            name: '字体大小',
            type: 'Select',
            range: [
                {
                  key: '10px',
                  value: 10,
                },
                {
                  key: '12px',
                  value: 12,
                },
                {
                  key: '13px',
                  value: 13,
                },
                {
                  key: '14px',
                  value: 14,
                },
                {
                  key: '16px',
                  value: 16,
                },
                {
                  key: '18px',
                  value: 18,
                },
                {
                  key: '20px',
                  value: 20,
                },
                {
                  key: '24px',
                  value: 24,
                },
                {
                  key: '36px',
                  value: 36,
                },
                // {
                //   key: '48px',
                //   value: 48,
                // },
                // {
                //   key: '64px',
                //   value: 64,
                // },
                // {
                //   key: '96px',
                //   value: 96,
                // }, 
            ],
        },
        {
            key: 'color',
            name: '颜色',
            type: 'Color',
            open: 'bottom',
        },
        {
            key: 'align',
            name: '对齐方式',
            type: 'Select',
            range: [
              {
                key: '左对齐',
                value: 'left',
              },
              {
                key: '居中对齐',
                value: 'center',
              },
              {
                key: '右对齐',
                value: 'right',
              },
            ],
        },
    ],
    config: {
        text: '文字',
        color: 'rgba(60,60,60,1)',
        fontSize: 12,
        align: 'center',
        lineHeight: 2,
    },
};

export default Text;

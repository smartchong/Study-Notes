const template = {
    type: 'Email',
    h: 23,
    displayName: '邮箱', 
};

export default template;
import {
    ITitleConfigType,
    IRadioConfigType,
    IMaxLengthType,
} from '@/core/FormComponents/types';

export type TEmailEditData = Array<
    ITitleConfigType | IRadioConfigType | IMaxLengthType
>;

export interface IEmailConfig {
    title: string;
    maxLength: number;
    required: boolean;
}

export interface IEmailSchema {
    editData: TEmailEditData;
    config: IEmailConfig;
}

const Email: IEmailSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 30,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
        {
            key: 'maxLength',
            name: '最大长度',
            type: 'Number',
        },
    ],
    config:{
        title: '邮箱',
        required: false,
        maxLength: 100,
    }
}

export default Email;
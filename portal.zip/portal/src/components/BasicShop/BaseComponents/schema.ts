import Text from './Text/schema';
import Input from './Input/schema';
import Textarea from './Textarea/schema';
import NumberInput from './NumberInput/schema';
import Name from './Name/schema';
import Email from './Email/schema';
import Tel from './Tel/schema';
import ID from './ID/schema';
import Image from './Image/schema';

const BasicSchema = {
    Text,
    Input,
    Textarea,
    NumberInput,
    Name,
    Email,
    Tel,
    ID,
    Image,
};

export default BasicSchema;
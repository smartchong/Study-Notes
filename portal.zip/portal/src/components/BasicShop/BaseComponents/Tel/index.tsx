import React,{ memo,useMemo } from 'react';
import { ITelConfig } from './schema';
import logo from '@/assets/tel.svg';
import { List, InputItem } from 'antd-mobile';
import styles from './index.less';

const Tel = memo((props: ITelConfig & { isTpl: boolean }) => {
    const { title,required,maxLength,isTpl } = props; 
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required])

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List className={styles.inputWrapper}>
                        <InputItem 
                            maxLength={maxLength}
                        >
                            {title}
                            {requiredMark}
                        </InputItem>
                    </List>
                )   
            }
        </>
    );
});

export default Tel;
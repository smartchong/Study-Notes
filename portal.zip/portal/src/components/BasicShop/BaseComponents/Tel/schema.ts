import {
    ITitleConfigType,
    IRadioConfigType,
} from '@/core/FormComponents/types';

export type TTelEditData = Array<
    ITitleConfigType | IRadioConfigType
>;

export interface ITelConfig {
    title: string;
    maxLength: number;
    required: boolean;
}

export interface ITelSchema {
    editData: TTelEditData;
    config: ITelConfig;
}

const Tel: ITelSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 30,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
    ],
    config:{
        title: '电话号码',
        required: false,
        maxLength: 11,
    }
}

export default Tel;
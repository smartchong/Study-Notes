const template = {
    type: 'Tel',
    h: 23,
    displayName: '电话号码', 
};

export default template;
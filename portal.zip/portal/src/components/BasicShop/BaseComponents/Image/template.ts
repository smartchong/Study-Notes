const template = {
    type: 'Image',
    h: 78,
    displayName: '图片', 
};
export default template;
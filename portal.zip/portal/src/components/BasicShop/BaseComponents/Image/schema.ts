import {
    IUploadConfigType,
    ICascadeConfigType,
    TUploadDefaultType
} from '@/core/FormComponents/types';

export type TImageEditData = Array<
    IUploadConfigType | ICascadeConfigType
>

export interface IImageConfig {
    imgUrl: TUploadDefaultType;
    actionType: string;
    actionContent: string;
}

export interface IImageSchema {
    editData: TImageEditData;
    config: IImageConfig;
}

const Image = {
    editData:[
        {
            key: 'imgUrl',
            name: '图片',
            type: 'Upload',
            isCrop: true,
        },
        {
            key: 'actionType',
            name: '点击跳转',
            type: 'Select',
            range: [
                {
                  key: '无',
                  value: '',  
                },
                {
                  key: '跳转链接',
                  value: 'link',
                },
                {
                  key: '拨打电话',
                  value: 'dial',
                }
            ], 
        },
        {
            key: 'actionContent',
            type: 'Cascade',
            associated: 'actionType',
            range: [
                {
                    key: '链接地址',
                    value: 'link'
                },
                {
                    key: '电话号码',
                    value: 'dial'
                }
            ]
        }
    ],
    config: {
        imgUrl: [
            {
              uid: '001',
              name: 'image.png',
              status: 'done',
              url: 'https://zos.alipayobjects.com/rmsportal/jkjgkEfvpUPVyRjUImniVslZfWPnJuuZ.png',
            },
        ],
        actionType:'',
        actionContent:'',
    },
};

export default Image;

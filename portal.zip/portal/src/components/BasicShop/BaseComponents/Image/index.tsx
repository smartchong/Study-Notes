import React,{ memo } from 'react';
import { IImageConfig } from './schema';
import logo from '@/assets/image.svg';

const Image = memo((props: IImageConfig & { isTpl: boolean }) => {
    const { isTpl,imgUrl,actionType,actionContent } = props; 

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <div
                        style={{
                            height: '100%',
                            textAlign: 'center',
                            objectFit: 'contain',
                        }}
                    >
                        <img
                            src={imgUrl?.[0]?.url} 
                            onTouchStart={() => {
                                if (actionType === 'link') {
                                    window.location.href = actionContent;
                                } else if(actionType === 'dial') {
                                    window.location.href = `tel://${actionContent}`;
                                }
                            }}
                            style={{
                                width: '100%',
                                height: '100%',
                            }}
                        />
                    </div>    
                )   
            }
        </>
    );
});

export default Image;
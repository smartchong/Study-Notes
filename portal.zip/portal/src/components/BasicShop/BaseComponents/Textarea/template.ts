const template = {
    type: 'Textarea',
    h: 55,
    displayName: '多行文本框',
};

export default template;
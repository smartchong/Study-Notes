import React,{ memo,useMemo } from 'react';
import { ITextareaConfig } from './schema';
import logo from '@/assets/textarea.svg';
import { List, TextareaItem } from 'antd-mobile';
import styles from './index.less';

const Textarea = memo((props: ITextareaConfig & { isTpl: boolean }) => {
    const { title,required,maxLength,isTpl } = props; 
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required])

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List className={styles.textareaWrapper}>
                        <TextareaItem 
                            count={maxLength}
                            rows={3}
                            title={<>{title}{requiredMark}</>}
                        />
                    </List>
                )   
            }
        </>
    );
});

export default Textarea;
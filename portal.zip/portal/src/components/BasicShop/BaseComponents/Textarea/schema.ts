import {
    ITitleConfigType,
    IRadioConfigType,
    IMaxLengthType,
} from '@/core/FormComponents/types';

export type TTextareaEditData = Array<
    ITitleConfigType | IRadioConfigType | IMaxLengthType
>;

export interface ITextareaConfig {
    title: string;
    required: boolean;
    maxLength: number;
}

export interface ITextareaSchema {
    editData: TTextareaEditData;
    config: ITextareaConfig;
}

const Textarea = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 30,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
        {
            key: 'maxLength',
            name: '最大长度',
            type: 'Number',
        },
    ],
    config:{
        title: '多行文本框',
        required: false,
        maxLength: 1000,
    }
}

export default Textarea;
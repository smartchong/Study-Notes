const template = {
    type: 'NumberInput',
    h: 23,
    displayName: '数字输入框',
};

export default template;
import {
    ITitleConfigType,
    IRadioConfigType,
    IMaxLengthType,
} from '@/core/FormComponents/types';

export type TNumberInputEditData = Array<
    ITitleConfigType | IRadioConfigType | IMaxLengthType
>;

export interface INumberInputConfig {
    title: string;
    maxLength: number;
    required: boolean;
}

export interface INumberInputSchema {
    editData: TNumberInputEditData;
    config: INumberInputConfig;
}

const NumberInput: INumberInputSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 30,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
        {
            key: 'maxLength',
            name: '最大长度',
            type: 'Number',
        },
    ],
    config:{
        title: '数字输入框',
        required: false,
        maxLength: 200,
    }
};

export default NumberInput;
import React,{ memo,useMemo } from 'react';
import { INumberInputConfig } from './schema';
import logo from '@/assets/numberinput.svg';
import { List, InputItem } from 'antd-mobile';
import styles from './index.less'; 

const NumberInput = memo((props: INumberInputConfig & { isTpl: boolean }) => {
    const { title,required,maxLength,isTpl } = props; 
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required])

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List className={styles.inputWrapper}>
                        <InputItem 
                            maxLength={maxLength}
                            type={"number"}
                        >
                            {title}
                            {requiredMark}
                        </InputItem>
                    </List>
                )   
            }
        </>
    );
});

export default NumberInput;
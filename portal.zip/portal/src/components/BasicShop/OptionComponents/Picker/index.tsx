import React, { memo, useMemo } from 'react';
import { IPickerConfig } from './schema';
import logo from '@/assets/picker.svg';
import { List, Picker } from 'antd-mobile';
import styles from './index.less';

const Index = memo((props: IPickerConfig & { isTpl: boolean }) => {
    const { title, required, isTpl, options } = props;

    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        }
        return null;
    }, [required])

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                        <List className={styles.inputWrapper}>
                            <Picker
                                cols={1}
                                extra="请选择"
                                data={options.map(it => ({ value: it, label: it }))}
                                title=""
                            >
                                <List.Item arrow="horizontal">{title}{requiredMark}</List.Item>
                            </Picker>
                        </List>
                    )
            }
        </>
    );
});

export default Index;
import {
    ITitleConfigType,
    IRadioConfigType,
    IOptionConfigType,
} from '@/core/FormComponents/types';

export type TPickerEditData = Array<
    ITitleConfigType | IRadioConfigType | IOptionConfigType   
>;

export interface IPickerConfig {
    title: string;
    required: boolean;
    options: string [];
}

export interface IPickerSchema {
    editData: TPickerEditData;
    config: IPickerConfig;
}

const Picker: IPickerSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 10,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
        {
            key: 'options',
            name: '选项内容',
            type: 'Option',
            options: [
                '选项一',
                '选项二',
                '选项三',
            ],
            maxLength: 30,
        }
    ],
    config:{
        title: '下拉菜单',
        required: false,
        options: [
            '选项一',
            '选项二',
            '选项三',
        ],
    }
}

export default Picker;
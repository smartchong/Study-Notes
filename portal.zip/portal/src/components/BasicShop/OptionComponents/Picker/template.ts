const template = {
    type: 'Picker',
    h: 23,
    displayName: '下拉菜单', 
};

export default template;
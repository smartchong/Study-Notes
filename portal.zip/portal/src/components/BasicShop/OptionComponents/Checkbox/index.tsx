import React,{ memo,useMemo } from 'react';
import { ICheckboxConfig } from './schema';
import logo from '@/assets/checkbox.svg';
import { Checkbox } from 'antd';
import { List } from 'antd-mobile';
import styles from './index.less';

const Index = memo((props: ICheckboxConfig & { isTpl: boolean }) => {
    const { title,required,isTpl,options } = props; 
    
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required])

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List renderHeader={<>{title}{requiredMark}</>}>
                        <Checkbox.Group className={styles.checkboxGroup}>
                            {
                                options.map((item,index) => (
                                    <Checkbox key={index} value={item}>{item}</Checkbox>
                                ))
                            }
                        </Checkbox.Group>
                    </List>
                )   
            }
        </>
    );
});

export default Index;
const template = {
    type: 'Checkbox',
    h: 50,
    displayName: '多选项', 
};

export default template;
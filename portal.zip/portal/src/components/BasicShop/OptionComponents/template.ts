/**
 * 选项类型：
 * （1）单选项 Radio    
 * （2）多选项 Checkbox    
 * （3）下拉菜单 Picker 
 * （4）图片单选项  
 * （5）图片多选项 
 */
import Radio from './Radio/template';
import Checkbox from './Checkbox/template';
import Picker from './Picker/template';

const optionTemplate = [
    Radio,
    Checkbox,
    Picker,
];
const OptionTemplate = optionTemplate.map(v => ({
    ...v,
    category: 'option',
}));

export default OptionTemplate;
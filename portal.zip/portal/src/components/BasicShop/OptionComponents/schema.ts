import Radio from './Radio/schema';
import Checkbox from './Checkbox/schema';
import Picker from './Picker/schema';

const OptionSchema = {
    Radio,
    Checkbox,
    Picker,
};

export default OptionSchema;
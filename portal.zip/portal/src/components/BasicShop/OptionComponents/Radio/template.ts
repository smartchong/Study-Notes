const template = {
    type: 'Radio',
    h: 50,
    displayName: '单选项', 
};

export default template;
import {
    ITitleConfigType,
    IRadioConfigType,
    IOptionConfigType,
} from '@/core/FormComponents/types';

export type TRadioEditData = Array<
    ITitleConfigType | IRadioConfigType | IOptionConfigType   
>;

export interface IRadioConfig {
    title: string;
    required: boolean;
    options: string [];
}

export interface IRadioSchema {
    editData: TRadioEditData;
    config: IRadioConfig;
}

const Radio: IRadioSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 30, 
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
        {
            key: 'options',
            name: '选项内容',
            type: 'Option',
            maxLength: 5, 
            options: [
                '选项一',
                '选项二',
                '选项三',
            ],
        }
    ],
    config:{
        title: '单选项',
        required: false,
        options: [
            '选项一',
            '选项二',
            '选项三',
        ],
    }
}

export default Radio;
import React,{ memo,useMemo } from 'react';
import { IRadioConfig } from './schema';
import logo from '@/assets/radio.svg';
import { Radio } from 'antd';
import { List } from 'antd-mobile';
import styles from './index.less';

const Index = memo((props: IRadioConfig & { isTpl: boolean }) => {
    const { title,required,isTpl,options } = props; 
    
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required])

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List renderHeader={<>{title}{requiredMark}</>}>
                        <Radio.Group className={styles.radioGroup}>
                            {
                                options.map((item,index) => (
                                    <Radio key={index} value={item}>{item}</Radio>
                                ))
                            }
                        </Radio.Group>
                    </List>
                )   
            }
        </>
    );
});

export default Index;
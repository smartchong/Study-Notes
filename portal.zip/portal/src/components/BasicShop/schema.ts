import BaseSchema from './BaseComponents/schema';
import OptionSchema from './OptionComponents/schema';
import DateSchema from './DateComponents/schema';
import ReadonlySchema from './ReadonlyComponents/schema';

const schema = {
    ...BaseSchema,
    ...OptionSchema,
    ...DateSchema,
    ...ReadonlySchema,
}

export default schema;
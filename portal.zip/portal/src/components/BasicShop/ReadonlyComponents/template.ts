/**
 * 只读类型：
 * （1）按钮 Button    
 */
import Button from './Button/template';

const readonlyTemplate = [
    Button,
];
const ReadonlyTemplate = readonlyTemplate.map(v => ({
    ...v,
    category: 'readonly',
}));

export default ReadonlyTemplate;
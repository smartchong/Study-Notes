import Button from './Button/schema';

const ReadonlySchema = {
    Button,
};

export default ReadonlySchema;
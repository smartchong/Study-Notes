import React,{ memo,useMemo } from 'react';
import { ITimeConfig } from './schema';
import logo from '@/assets/time.svg';
import { DatePicker,List } from 'antd-mobile';
import styles from './index.less';

const Index = memo((props: ITimeConfig & { isTpl: boolean }) => {
    const { title,required,isTpl } = props; 
    
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required])

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List className={styles.inputWrapper}>
                        <DatePicker 
                          mode="time"
                          format="HH:mm"
                          title="选择时间"
                          extra="请选择时间"
                        >
                            <List.Item arrow="horizontal">{title}{requiredMark}</List.Item>
                        </DatePicker>
                    </List>
                )   
            }
        </>
    );
});

export default Index;
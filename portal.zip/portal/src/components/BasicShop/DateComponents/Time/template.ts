const template = {
    type: 'Time',
    h: 23,
    displayName: '时间', 
};

export default template;
import {
    ITitleConfigType,
    IRadioConfigType,
} from '@/core/FormComponents/types';

export type TTimeEditData = Array<
    ITitleConfigType | IRadioConfigType   
>;

export interface ITimeConfig {
    title: string;
    required: boolean;
}

export interface ITimeSchema {
    editData: TTimeEditData;
    config: ITimeConfig;
}

const Time: ITimeSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 10,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
    ],
    config:{
        title: '时间',
        required: false,
    }
}

export default Time;
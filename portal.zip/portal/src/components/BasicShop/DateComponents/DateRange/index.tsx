import React,{ memo,useMemo,useState } from 'react';
import { IDateRangeConfig } from './schema';
import logo from '@/assets/daterange.svg';
import { Calendar,List,Modal } from 'antd-mobile';
import zhCN from 'antd-mobile/lib/calendar/locale/zh_CN';
import { format } from '@/utils/tool';
import styles from './index.less';

const Index = memo((props: IDateRangeConfig & { isTpl: boolean }) => {
    const { title,required,isTpl } = props; 
    const [show,handleShow] = useState(false);
    const [startTime,handleStartTime] = useState(undefined);
    const [endTime,handleEndTime] = useState(undefined);
    const originbodyScrollY = document.getElementsByTagName('body')[0].style.overflowY;
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required])
    const onCancel = () => {
        document.getElementsByTagName('body')[0].style.overflowY = originbodyScrollY;
        handleShow(false);
        handleStartTime(undefined);
        handleEndTime(undefined);
    }
    const onConfirm = (startTime: any, endTime: any) => {
        document.getElementsByTagName('body')[0].style.overflowY = originbodyScrollY;
        handleShow(false);
        handleStartTime(startTime);
        handleEndTime(endTime);
    }

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <>
                        <List className={styles.inputWrapper}>
                            <List.Item 
                                arrow="horizontal"
                                onClick={() => {
                                    document.getElementsByTagName('body')[0].style.overflowY = 'hidden';
                                    handleShow(true);
                                }}
                                extra={
                                    <> 
                                        {
                                            startTime && `${format((startTime as any),'YYYY-MM-dd')} - `
                                        }
                                        {
                                            endTime && format((endTime as any),'YYYY-MM-dd')
                                        }
                                    </>
                                }
                            >
                                {title}{requiredMark}
                            </List.Item>
                        </List>
                        <Modal
                            popup
                            visible={show}
                        >
                            <Calendar
                                locale={zhCN}
                                visible={show}
                                onCancel={onCancel}
                                onConfirm={onConfirm}
                            />
                        </Modal>   
                    </>
                )   
            }
        </>
    );
});

export default Index;
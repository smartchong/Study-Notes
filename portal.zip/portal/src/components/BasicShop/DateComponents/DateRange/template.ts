const template = {
    type: 'DateRange',
    h: 23,
    displayName: '日期区间', 
};

export default template;
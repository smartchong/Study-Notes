import {
    ITitleConfigType,
    IRadioConfigType,
} from '@/core/FormComponents/types';

export type TDateRangeEditData = Array<
    ITitleConfigType | IRadioConfigType   
>;

export interface IDateRangeConfig {
    title: string;
    required: boolean;
}

export interface IDateRangeSchema {
    editData: TDateRangeEditData;
    config: IDateRangeConfig;
}

const DateRange: IDateRangeSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 10,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
    ],
    config:{
        title: '日期区间',
        required: false,
    }
}

export default DateRange;
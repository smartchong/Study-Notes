import Date from './Date/schema';
import DateRange from './DateRange/schema';
import Time from './Time/schema';

const DateSchema = {
    Date,
    DateRange,
    Time,
};

export default DateSchema;
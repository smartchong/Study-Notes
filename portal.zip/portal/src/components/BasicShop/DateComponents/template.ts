/**
 * 日期类型：
 * （1）日期 Date    
 * （2）日期区间 DateRange    
 * （3）时间 Time 
 */
import Date from './Date/template';
import DateRange from './DateRange/template';
import Time from './Time/template';

const dateTemplate = [
    Date,
    DateRange,
    Time,
];
const DateTemplate = dateTemplate.map(v => ({
    ...v,
    category: 'date',
}));

export default DateTemplate;
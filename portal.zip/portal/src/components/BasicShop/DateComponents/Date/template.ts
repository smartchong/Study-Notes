const template = {
    type: 'Date',
    h: 23,
    displayName: '日期', 
};

export default template;
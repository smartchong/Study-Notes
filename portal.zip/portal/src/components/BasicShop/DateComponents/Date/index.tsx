import React,{ memo,useMemo,useState } from 'react';
import { IDateConfig } from './schema';
import logo from '@/assets/date.svg';
import { DatePicker,List } from 'antd-mobile';
import styles from './index.less';

const Index = memo((props: IDateConfig & { isTpl: boolean }) => {
    const { title,required,isTpl } = props; 
    const requiredMark = useMemo(() => {
        if (required) {
            return (
                <span style={{ color: 'red' }}>*</span>
            )
        } 
        return null;
    },[required]);

    return (
        <>
            {
                isTpl ? (
                    <div>
                        <img src={logo} />
                    </div>
                ) : (
                    <List className={styles.inputWrapper}>
                        <DatePicker 
                          mode="date"
                          format="YYYY-MM-DD"
                          title="选择日期"
                          extra="请选择日期"
                        >
                            <List.Item arrow="horizontal">{title}{requiredMark}</List.Item>
                        </DatePicker>
                    </List>
                )   
            }
        </>
    );
});

export default Index;
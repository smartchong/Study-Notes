import {
    ITitleConfigType,
    IRadioConfigType,
} from '@/core/FormComponents/types';

export type TDateEditData = Array<
    ITitleConfigType | IRadioConfigType   
>;

export interface IDateConfig {
    title: string;
    required: boolean;
}

export interface IDateSchema {
    editData: TDateEditData;
    config: IDateConfig;
}

const Date: IDateSchema = {
    editData:[
        {
            key: 'title',
            name: '标题',
            type: 'Text',
            maxLength: 10,
        },
        {
            key: 'required',
            name: '是否必填',
            type: 'Radio',
            range: [
                {
                  key: '是',
                  value: true,
                },
                {
                  key: '否',
                  value: false,
                }
            ],
        },
    ],
    config:{
        title: '日期',
        required: false,
    }
}

export default Date;
import React from 'react';
import ReactEchartsCore from 'echarts-for-react/lib/core';
import echarts from 'echarts/lib/echarts';
import 'echarts/lib/chart/line';
import 'echarts/lib/component/tooltip';
import 'echarts/lib/component/title';

class Chart extends React.Component {
    displayName = 'Chart';

    static defaultProps = {
        unit: '',
        title: '',
        height: 300,
        // color: '#57AFFF',
        series: [],
        dataZoom: null
    };

    getInstance() {
        return this.chart.getEchartsInstance();
    }

    getLoadOption() {
        
        return {
            title: {
                left: 'center',
                text: this.props.title
            },
            axisPointer: {
                lineStyle: {
                    color: '#eee',
                    type: 'dotted'
                }
            },
            tooltip: {
                trigger: 'axis',
                backgroundColor: 'rgba(255,255,255,0.9)',
                textStyle: {
                    color: '#000000'
                },
                axisPointer: {            // 坐标轴指示器，坐标轴触发有效
                    type: 'line'        // 默认为直线，可选为：'line' | 'shadow'
                },
            },
            legend: {
                // icon: "rect",   //  字段控制形状  类型包括 circle，rect,line，roundRect，triangle，diamond，pin，arrow，none
                // itemWidth: 10,  // 设置宽度
                // itemHeight: 10, // 设置高度
                // itemGap: 40, // 设置间距
                // right: 10,
                data: this.props.name
            },
            grid: {
                left: '3%',
                right: '4%',
                bottom: '3%',
                containLabel: true
            },
            xAxis: {
                type: 'category',
                boundaryGap: false,
                data: this.props.x,
                axisLabel: {
                    textStyle: {
                        fontSize: 10
                    },
                    offset: 5,
                    formatter(params) {
                        return params.replace(/.{14}(?!$)/g, (a) => a + '\n')
                    }
                },
                axisLine: {
                    show: true
                },
                axisTick: {
                    show: true
                }
            },
            yAxis: {
                name: this.props.unit,
                axisLine: {
                    show: true
                },
                axisTick: {
                    show: true
                },
                axisLabel: {
                    formatter: `{value}`
                }
            },
            series: this.props.y
        };
    }

    render() {
        return (
            <ReactEchartsCore
                echarts={echarts}
                ref={(e) => { this.chart = e; }}
                option={this.getLoadOption()}
                style={{ height: this.props.height, backgroundColor: 'white' }}
            />
        );
    }
}

export default Chart;
import { queryCurrent, query as queryUsers, signOut, ssoLogin } from '@/services/user';
import { history } from 'umi';

const UserModel = {
  namespace: 'user',
  state: {
    currentUser: {},
  },
  effects: {
    *fetch(_, { call, put }) {
      const response = yield call(queryUsers);
      yield put({
        type: 'save',
        payload: response,
      });
    },
    *login({ payload,callBack }, { call, put}) {
      const response = yield call(ssoLogin, payload);
      yield put({
        type: 'changeLoginStatus',
        payload: response,
      });
      if (response.success) {
        yield put({
          type:'user/fetchCurrent',
          callBack:() => {},
        });
      }
      callBack(response);
    },
    *fetchCurrent({callBack}, { call, put }) {
      const response = yield call(queryCurrent);
      try{
        if(response && response.success){
          yield put({
            type: 'saveCurrentUser',
            payload: response,
          });
          callBack && callBack(response);
        }else {
          localStorage.removeItem('name');
          if(history.location.pathname != '/' && history.location.pathname != '/user/login' && history.location.pathname){
            history.replace('/user/login')
          }
        }
      }catch (error){
        localStorage.removeItem('name');
        if(history.location.pathname != '/' && history.location.pathname != '/user/login' && history.location.pathname){
          history.replace('/user/login')
        }
      }
    },
    *signOut(_,{call,put}){
      const response = yield call(signOut);
      yield put({
        type: 'saveCurrentUser',
        payload: {},
      });
      localStorage.removeItem('name')
      if(response.success){
        history.replace('/')
      }
    }
  },
  reducers: {
    saveCurrentUser(state, action) {
      localStorage.setItem('name',action.payload && action.payload.data && action.payload.data.name || '')
      return { ...state, currentUser: action.payload.data || {} };
    },
    changeNotifyCount(
      state = {
        currentUser: {},
      },
      action,
    ) {
      return {
        ...state,
        currentUser: {
          ...state.currentUser,
          notifyCount: action.payload.totalCount,
          unreadCount: action.payload.unreadCount,
        },
      };
    },
    changeLoginStatus(state, { payload }) {
      return { ...state, status: payload.status, type: payload.type,userInfo:payload };
    },
  },
};
export default UserModel;

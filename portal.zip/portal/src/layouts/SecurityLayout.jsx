import React from 'react';
import { PageLoading } from '@ant-design/pro-layout';
import { Redirect, connect,history } from 'umi';
import { stringify } from 'querystring';

class SecurityLayout extends React.Component {
  state = {
    isReady: false,
  };

  componentDidMount() {
    this.setState({
      isReady: true,
    });
    const { dispatch,currentUser } = this.props;

    if (dispatch && localStorage.getItem('name')) {
      dispatch({
        type: 'user/fetchCurrent',
      });
    }
  }

  render() {
    const { isReady } = this.state;
    const { children, loading, currentUser } = this.props; // You can replace it to your authentication rule (such as check token exists)
    // 你可以把它替换成你自己的登录认证规则（比如判断 token 是否存在）

    const isLogin = currentUser && currentUser.name;
    const queryString = stringify({
      redirect: window.location.href,
    });

    if ((!isLogin && loading) || !isReady) {
    // if (!isReady) {
      return <PageLoading />;
    }

    if (
      !isLogin &&
      history.location.pathname.indexOf('/h5/') === -1 && 
      history.location.pathname.indexOf('/cloudCard/') === -1 &&
      history.location.pathname.indexOf('/nlzt/') === -1 &&
      history.location.pathname != '/user/retrieve-result' &&
      history.location.pathname != '/user/retrieve-reset' &&
      history.location.pathname != '/user/retrieve-validate' &&
      history.location.pathname != '/user/register-result' &&
      history.location.pathname != '/user/register' &&
      history.location.pathname != '/user/login' &&
      history.location.pathname != '/' &&
      history.location.pathname
    ) {
      return <Redirect to={`/user/login`} />;
    }

    return children;
  }
}

export default connect(({ user, loading }) => ({
  currentUser: user.currentUser,
  loading: loading.models.user,
}))(SecurityLayout);

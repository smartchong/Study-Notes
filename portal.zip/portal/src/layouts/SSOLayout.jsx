import ProLayout from '@ant-design/pro-layout';
import React, { useEffect,useState } from 'react';
import { Result } from 'antd';
import { useIntl, connect, FormattedMessage } from 'umi';
import { parse } from 'querystring';

const noMatch = (
    <Result
      status={403}
      title="403"
      subTitle={<FormattedMessage id='component.authorized.none'/>}
    />
);

const BasicLayout = props => {
    const {
        dispatch,
        children,
        currentUser,
        location = {
          pathname: '/',
        },
    } = props;
    const [auth,handleAuth] = useState(true);
    const { formatMessage } = useIntl();

    useEffect(() => {
        
        if (location.search) {
            const params = parse(location.search.substring(1));
            params.loginType = 99;
            if (dispatch && !currentUser.name) {
                dispatch({
                    type: 'user/login',
                    payload: { ...params },
                    callBack: (res) => {
                        if (res.success) {
                            handleAuth(true)
                        } else {
                            handleAuth(false)
                        }
                    }
                });
            }
        } else {
            handleAuth(false)
        }
    }, []);

    if (!currentUser.name || !auth) {
        return noMatch;
    }

    return (
        <ProLayout
            formatMessage={formatMessage}
            menuHeaderRender={() => (<></>)}
            breadcrumbRender={(routers = []) =>{
                return  [
                    {
                        path: '/',
                        breadcrumbName: formatMessage({
                            id: 'menu.me',
                        }),
                    },
                    ...routers,
                ]
            }}
            menuRender={() => <></>}
            headerRender={false}
            footerRender={false}
            {...props}
        >
            {children}
        </ProLayout>
    );
}

export default connect(({ user }) => ({
    currentUser: user.currentUser,
}))(BasicLayout);
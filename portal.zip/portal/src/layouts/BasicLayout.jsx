/**
 * Ant Design Pro v4 use `@ant-design/pro-layout` to handle Layout.
 * You can view component api by:
 * https://github.com/ant-design/ant-design-pro-layout
 */
import ProLayout, { DefaultFooter } from '@ant-design/pro-layout';
import React, { useEffect } from 'react';
import { Link, useIntl, connect } from 'umi';
import { MenuUnfoldOutlined, MenuFoldOutlined } from '@ant-design/icons';
import Authorized from '@/utils/Authorized';
import RightContent from '@/components/GlobalHeader/RightContent';
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
import { getAuthorityFromRouter } from '@/utils/utils';
import styles from './BasicLayout.less';

/**
 * use Authorized check all menu item
 */
const menuDataRender = (menuList) =>
  menuList.map((item) => {
    const localItem = { ...item, children: item.children ? menuDataRender(item.children) : [] };
    return Authorized.check(item.authority, localItem, null);
  });

const defaultFooterDom = (
  <DefaultFooter copyright={`${new Date().getFullYear()} 中移(杭州)信息技术有限公司`} links={[]} />
);

const BasicLayout = (props) => {
  const {
    dispatch,
    children,
    settings,
    currentUser,
    location = {
      pathname: '/',
    },
  } = props;
  /**
   * constructor
   */
  useEffect(() => {
    if (dispatch && !currentUser.name) {
      dispatch({
        type: 'user/fetchCurrent',
      });
    }
    if (dispatch) {
      dispatch({
        type: 'appAndTableList/queryAppSelectRule',
      });
    }
  }, []);
  /**
   * init variables
   */
  const handleMenuCollapse = (payload) => {
    if (dispatch) {
      dispatch({
        type: 'global/changeLayoutCollapsed',
        payload,
      });
    }
  }; // get children authority

  const authorized = getAuthorityFromRouter(props.route.routes, location.pathname || '/') || {
    authority: undefined,
  };
  const { formatMessage } = useIntl();
  return (
    <div className={styles.basicLayout}>
      <BasicHeader />
      <ProLayout
        formatMessage={formatMessage}
        menuHeaderRender={(logoDom, titleDom) => <></>}
        onCollapse={handleMenuCollapse}
        menuItemRender={(menuItemProps, defaultDom) => {
          if (menuItemProps.isUrl || menuItemProps.children || !menuItemProps.path) {
            return <Link to={menuItemProps.path}>{defaultDom}</Link>;
          }

          return <Link to={menuItemProps.path}>{defaultDom}</Link>;
        }}
        breadcrumbRender={(routers = []) => {
          return [
            {
              path: '/',
              breadcrumbName: formatMessage({
                id: 'menu.me',
              }),
            },
            ...routers,
          ];
        }}
        itemRender={(route, params, routes, paths) => {
          const first = routes.indexOf(route) === 0;
          return first ? (
            <Link to={paths.join('/')}>{route.breadcrumbName}</Link>
          ) : (
            <span>{route.breadcrumbName}</span>
          );
        }}
        headerRender={() => <></>}
        footerRender={() => defaultFooterDom}
        menuDataRender={menuDataRender}
        rightContentRender={() => <RightContent />}
        {...props}
        {...settings}
        links={[
          <a onClick={() => handleMenuCollapse(!props.collapsed)}>
            {React.createElement(props.collapsed ? MenuUnfoldOutlined : MenuFoldOutlined)}
            <span>{props.collapsed ? '展开' : ''}</span>
          </a>,
        ]}
      >
        {/*<Authorized authority={authorized.authority} noMatch={noMatch}>*/}
        {children}
        {/*</Authorized>*/}
      </ProLayout>
    </div>
  );
};

export default connect(({ global, settings, user }) => ({
  collapsed: global.collapsed,
  settings,
  currentUser: user.currentUser,
}))(BasicLayout);

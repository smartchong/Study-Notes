import React, { createContext,useState } from 'react';
import { IRouteComponentProps } from 'umi';
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
const styles = require('./BasicLayout.less');

// 字符串字面量类型
export type contextType = 'h5' | 'pc';

export interface IContextType {
    theme: contextType;
    setTheme: Function;
}

export const context = createContext<IContextType>({
    theme: 'h5',
    setTheme: () => {}
})

export default function Layout({ children }: IRouteComponentProps) {
    const [state,setState] = useState<contextType>('h5');
    
    return (
        <div className={styles.basicLayout}>
            <BasicHeader />
            <context.Provider
                value={{
                    theme: state,
                    setTheme: setState,
                }}
            >
                {children}
            </context.Provider>
        </div>
    )
}
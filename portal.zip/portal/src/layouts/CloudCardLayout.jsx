import ProLayout, { DefaultFooter } from '@ant-design/pro-layout';
import RightContent from '@/components/GlobalHeader/RightContent';
import { MenuUnfoldOutlined, MenuFoldOutlined } from '@ant-design/icons';
import React from 'react';
import { useIntl, connect, Link, history } from 'umi';
import logo from '../assets/logo.svg';
import Settings from '../../config/cloudCardSetting';
import styles from './CloudCardLayout.less';

const defaultFooterDom = (
    <DefaultFooter
        copyright={`${new Date().getFullYear()} 中移(杭州)信息技术有限公司`}
        links={[]}
    />
);

const Layout = props => {
    
    const {
        children,
        collapsed,
        currentUser,
        dispatch,
    } = props;
    const { formatMessage } = useIntl();

    if (!currentUser.name) {
        history.push({
            pathname: '/user/login',
            state: {
                to:'cloudCard'
            },
        });
    }

    const handleMenuCollapse = payload => {
        if (dispatch) {
          dispatch({
            type: 'global/changeCloudCardLayoutCollapsed',
            payload,
          });
        }
    };

    return (
        <ProLayout
            className={styles.cloudCardLayout}
            logo={logo}
            formatMessage={formatMessage}
            onCollapse={handleMenuCollapse}
            breadcrumbRender={(routers = []) =>{
                return  [
                    {
                        path: '/',
                        breadcrumbName: formatMessage({
                            id: 'menu.me',
                        }),
                    },
                    ...routers,
                ]
            }}
            itemRender={(route, params, routes, paths) => {
                const first = routes.indexOf(route) === 0;
                return first ? (
                  <Link to={paths.join('/')}>{route.breadcrumbName}</Link>
                ) : (
                    <span>{route.breadcrumbName}</span>
                );
            }}
            menuHeaderRender={(logo,title) => (
                <a>
                    {logo}
                    {title}
                </a>
            )}
            menuItemRender={(menuItemProps, defaultDom) => {
                if (menuItemProps.isUrl || !menuItemProps.path) {
                    return defaultDom;
                }
                return <Link to={menuItemProps.path}>{defaultDom}</Link>;
            }}
            rightContentRender={() => <RightContent />}
            footerRender={() => defaultFooterDom}
            links={[
                <a
                  onClick={() => handleMenuCollapse(!collapsed)}
                >
                  {React.createElement(collapsed ? MenuUnfoldOutlined : MenuFoldOutlined)}
                  <span>{collapsed ? '展开' : ''}</span>
                </a>,
              ]}
            {...props}
            {...Settings}
        >
            {children}
        </ProLayout>
    );
}

export default connect(({ global, user, }) => ({
    collapsed: global.cloudCardCollapsed,
    currentUser: user.currentUser,
}))(Layout);
import request from '@/utils/request';
import API from '@/services/api';

export async function query() {
  return request('/api/users');
}
export async function queryCurrent() {
  return request(API.USER.CURRENT);
}
export async function signOut() {
  return request(API.LOGIN.SIGNOUT);
}
export async function queryNotices() {
  return request('/api/notices');
}
export async function ssoLogin(params) {
  return request(API.LOGIN.ACCOUNT, {
    method: 'POST',
    data: params,
    requestType:'form'
  });
}
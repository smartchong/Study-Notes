const HOST = '/portal/';
export default {
  USER:{
    CURRENT:`${HOST}user/current`,
    CHANGEPHONE:`${HOST}user/modify/phone`,
    CHANGEPWD:`${HOST}user/modify/password`,
  },

  AUTH:{
    ADD:`${HOST}verify/add`,
    MODIFY:`${HOST}verify/modify`,
    DETAIL:`${HOST}verify/detail`,
    UPLOAD:`${HOST}verify/file/upload`,
    REPEATCHECK:`${HOST}verify/check/license`,
  },

  LOGIN:{
    SECRETKEY:`${HOST}login/key`,
    CAPTCHA_SMS:`${HOST}login/captcha`,
    CAPTCHA_IMG:`${HOST}login/codeimage`,
    ACCOUNT:`${HOST}login`,
    SIGNOUT:`${HOST}login/logout`,
    CAPTCHA:`${HOST}authcode/send`,
    SIMAUTH:`${HOST}sim/send`
  },

  REGISTER:{
    REPEATCHECK:`${HOST}register/repeat/check`,
    SUBMIT:`${HOST}register/submit`
  },

  RETRIEVE:{
    VALIDATE:`${HOST}password/find/validate`,
    RESET:`${HOST}password/find/reset`
  },

  APP:{
    TABLE_SELECT_LIST:`${HOST}app/all`,
    TABLE_LIST:`${HOST}app/list`,
    CREATE:`${HOST}app/add`,
    DETAIL:`${HOST}app/detail`,
    UPDATE:`${HOST}app/update`,
    CHECK_NAME:`${HOST}app/checkAppName`,
    UPLOAD_LOGO:`${HOST}app/file/upload`,
    TABLE_DELETE:`${HOST}app/delete`,
    TABLE_COUNT:`${HOST}app/count`,
  },

  MEDIA:{
    TABLE_LIST:`${HOST}media/fileList`,
    TABLE_TYPE_LIST:`${HOST}media/fileList/byType`,
    UPLOAD:`${HOST}media/uploadMediaFile`,
    MOCK_UPLOAD:'https://www.mocky.io/v2/5cc8019d300000980a055e76',
    RELOAD:`${HOST}media/reloadMediaFile`,
    REMOVE:`${HOST}media/deleteMediaFile`,
    BATCHREMOVE: `${HOST}media/deleteAllMediaFile`,
    GET_FILE:`${HOST}media/getFileResource`,
  },

  HFMANAGE: {
    QUERY_LIST:`${HOST}hfManage/list`,
    DELETE:`${HOST}hfManage/delete`,
    SAVE:`${HOST}hfManage/save`,
    UPDATE:`${HOST}hfManage/update`,
    UPLOAD:`${HOST}hfManage/file`,
    DETAIL:`${HOST}hfManage/detail`,
    SHORTLINK:`${HOST}hfManage/getByShortStr`,
  },

  TEMPLATE: {
    QUERY_SELECT_LIST:`${HOST}template/getByAppId`,
    QUERY_LIST:`${HOST}template/list`,
    QUERY_DETAIL:`${HOST}template/detail`,
    ADD:`${HOST}template/add`,
    DEL:`${HOST}template/delete`,
  },

  TESTSEND:{
    SEND:`${HOST}testsend/manage/sendTest`,
    DETAILS:`${HOST}testsend/manage/getAppList`,
    QUERY_TEMPLATES:`${HOST}testsend/manage/getTemplatesByAppId`,
    QUERY_H5_TEMPLATES:`${HOST}testsend/manage/getTemplatesBySmsAppTemp`,
  },

  MASSSEND:{
    SEND:`${HOST}sendmsg/manage/batchSend`,
    QUERY_GROUP_LIST:`${HOST}sendmsg/manage/getGroup`,
    QUERY_TEMPLATES:`${HOST}sendmsg/manage/getTemplatesByAppId`,
    QUERY_H5_TEMPLATES:`${HOST}sendmsg/manage/getTemplatesBySmsAppTemp`,
  },

  MSGRECORD:{
    QUERY_LIST:`${HOST}msg/sendList`,
    QUERY_DETAIL:`${HOST}msg/sendDetail`,
  },

  MSGSTATISTICS: {
    SEND: {
      STATISTICS: `${HOST}statistic/sendStatistic`,
      SENDFAILDETAIL: `${HOST}statistic/sendFailDetail`,
      DOWNLOADFILE: `${HOST}statistic/download`,
    },
    INTER: {
      INTERACT: `${HOST}statistic/interactStatistic`
    }
  },

  RECIPIENT:{
    QUERY_LIST:`${HOST}receiver/manage/list`,
    DELETE:`${HOST}receiver/manage/delete`,
    BATCHDELETE:`${HOST}receiver/manage/batchDelete`,
    GROUPLIST:`${HOST}receiver/manage/getGroups`,
    ADD:`${HOST}receiver/manage/addReceiver`,
    UPLOAD:`${HOST}receiver/manage/upload`,
    CHECKGROUPNAME:`${HOST}receiver/manage/checkGroupNameUnique`,
    DEL:`${HOST}receiver/manage/batchDelete`,
    DOWNLOAD:`${HOST}receiver/manage/download`,
  },

  BLACKLIST:{
    QUERY_LIST:`${HOST}userblacklist/list`,
    DEL:`${HOST}userblacklist/delete`,
    ADD:`${HOST}userblacklist/add`,
    IMPORT:`${HOST}userblacklist/import`,
    DOWNLOAD:`${HOST}userblacklist/downDemo`
  },

  CONFIG:{
    QUERY_LIST:`${HOST}moTemplate/list`,
    ADD:`${HOST}moTemplate/add`,
    DEL:`${HOST}moTemplate/delete`,
  },

  SMSAPPLET:{
    TEMPLATE:{
      LIST:`${HOST}smsAppTemp/list`,
      ADD:`${HOST}smsAppTemp/add`,
      AUTH:`${HOST}smsAppTemp/auth`,
      DELETE:`${HOST}smsAppTemp/delete`,
      DETAILS:`${HOST}smsAppTemp/detail`,
      UPDATE:`${HOST}smsAppTemp/update`,
      PASS:`${HOST}smsAppTemp/pass`,
    },
    SHORTLINK:{
      LIST:`${HOST}showlink/manage/list`,
      ADD:`${HOST}showlink/manage/submit`,
      DELETE:`${HOST}showlink/manage/delete`,
      UPDATE:`${HOST}showlink/manage/edit`,
      DETAILS:`${HOST}showlink/manage/detail`,
      PASS:`${HOST}showlink/manage/pass`,
    },
  },

  PRODUCT:{
    HARDWARE:{
      LIST:`${HOST}hardProd/list`,
      DETAILS:`${HOST}hardProd/detail`,
    },
    CONTENT:{
      LIST:`${HOST}contProd/list`,
      DETAILS:`${HOST}contProd/detail`,
    }
  },

  ORDER:{
    HARDWARE:{
      LIST:`${HOST}hardOrder/list`,
      DETAILS:`${HOST}hardOrder/detail`,
    },
    CONTENT:{
      LIST:`${HOST}contOrder/list`,
      DETAILS:`${HOST}contOrder/detail`,
    }
  },

  //云名片
  CLOUDCARD: {
    ELECTRONCARD: {
      MY: {
        DETAILS: `${HOST}cloudcard/my/detail`,
        GETLOGO: `${HOST}cloudcard/my/getLogo`,
        UPLOADLOGO: `${HOST}cloudcard/my/upload`,
        EDIT: `${HOST}cloudcard/my/saveEdit`,
      }
    },
    //成员管理
    MEMBERMANAGE: {
      //成员列表
      LIST: {
        ADD: `${HOST}cloudCard/memberManage/add`,
        BATCHADD: `${HOST}cloudCard/memberManage/upload`,
        ALL: `${HOST}cloudCard/memberManage/all`,
        DELETE: `${HOST}cloudCard/memberManage/delete`,
        DETAIL: `${HOST}cloudCard/memberManage/detail`,
        DOEWLOAD: `${HOST}cloudCard/memberManage/download`,
        LIST: `${HOST}cloudCard/memberManage/list`,
        MODIFY: `${HOST}cloudCard/memberManage/modify`,
        UNIQUE: `${HOST}cloudCard/memberManage/unique`
      }
    }
  }

};

export const result = {
  success:true,
  data:{},
  code:1,
  message:'成功'
};

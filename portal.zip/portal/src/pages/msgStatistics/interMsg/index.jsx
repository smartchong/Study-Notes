import { Card } from 'antd';
import React, { useState, useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { connect } from 'umi';
import CustomProForm from '../components/CustomProForm';
import StatisticsCard from '../components/InterStatisticsCard';
import LineChart from '../components/InterLineChart';
import styles from './style.less';

const Index = props => {
  const { appSelectList, dispatch, massSend, interMsg } = props;
  const [ fieldsValue, setFieldsValue ] = useState(null);
  useEffect(()=>{
    if (dispatch && fieldsValue) {
      dispatch({
        type:'interMsg/fetchStatistics',
        payload: fieldsValue
      })
    }
  }, [fieldsValue])
  return (
    <PageHeaderWrapper>
      <Card className={styles.msgStatitics} bordered={false} >
      <CustomProForm
          appSelectList={appSelectList.map((item) => {
            return {
              'value': item.appId,
              'label': item.appName
            }
          })}
          getTemplatesList={(fieldsValue)=>{
            dispatch({
              type:'massSend/queryTemSelectList',
              payload:fieldsValue
            })
          }}
          onReset={() => {
            dispatch({
              type:'massSend/setTemSelectList',
              payload:{data: []}
            })
          }}
          templatesList={ massSend.temSelectList.map(item => {
            return {
              label: item.name,
              value: item.id
            }
          }) }
          onSubmit={(fieldsValue)=>{
            setFieldsValue(fieldsValue);
          }}
        />
        <StatisticsCard
          data={interMsg.statistics}
        />
        <div className='mt-20'>
          <LineChart
            data={interMsg.chartData}
          />
        </div>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(
  ({ interMsg, appAndTableList, massSend, loading }) =>
    ({
      interMsg,
      appSelectList: appAndTableList.appSelectList,
      massSend,
      loadingStatistics: loading.effects['sendMsg/fetchStatistics'],
      loadingFailDetail: loading.effects['sendMsg/fetchFailDetail']
    })
)(Index);

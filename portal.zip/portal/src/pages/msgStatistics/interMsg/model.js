import { message, notification } from 'antd';
import { statistics } from './service';
import moment from 'moment';

const Model = {
  namespace: 'interMsg',
  state: {
    statistics: {
      sumMsgReadCount: '--',
      sumUpCount: '--',
      sumLinkClickCount: '--',
    },
    chartData: {
      x: [],
      y: []
    }
  },
  effects: {
    *fetchStatistics({ payload, callback }, { call, put }) {
      const response = yield call(statistics, payload);
      if (response && response.success) {
        yield put({
          type: 'setData',
          payload: {
            statistics: {
              sumMsgReadCount: response.data.sumMsgReadCount,
              sumUpCount: response.data.sumUpCount,
              sumLinkClickCount: response.data.sumLinkClickCount
            }
          },
        });
        yield put({
          type: 'setData',
          payload: {
            chartData: {
              x: response.data.list.map(item => moment(item.statisticDate).format('YYYY-MM-DD')),
              y: [
                {
                  name: '消息点击量',
                  data: response.data.list.map(item => item.msgReadCount),
                  type: 'line',
                },
                {
                  name: '上行交互量',
                  data: response.data.list.map(item => item.upCount),
                  type: 'line',
                },
                // {
                //   name: '外部链接点击量',
                //   data: response.data.list.map(item => item.linkClickCount),
                //   type: 'line',
                // }
              ],
            }
          },
        });
      } else {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
  },
  reducers: {
    setData(state, { payload }) {
      return { ...state, ...payload };
    }
  },
};
export default Model;

import request from '@/utils/request';
import API from '../../../services/api';

export async function statistics(params) {
  return request(API.MSGSTATISTICS.INTER.INTERACT, {
    method: 'POST',
    data: { ...params },
  });
}
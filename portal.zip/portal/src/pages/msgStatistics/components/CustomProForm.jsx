import React, { useRef, useState } from 'react';
import { message, Form, Select, Radio, DatePicker, Button } from 'antd';
import moment from 'moment';
import ProTable from '@ant-design/pro-table';
import styles from './style.less';
export default (props) => {
  const { getTemplatesList, templatesList, onSubmit } = props;
  const [timeRange, setTimeRange] = useState(false);
  const [sendTime, setSendTime] = useState('1');

  const actionRef = useRef();

  const [form] = Form.useForm();

  const [dates, setDates] = useState([]);
  const [hackValue, setHackValue] = useState();
  const [value, setValue] = useState();
  const [appId, setAppId] = useState('');
  const [sendType, setSendType] = useState('');
  const [templateId, setTemplateId] = useState('');
  const disabledDate = current => {
    if (dates) {
      const tooLate = dates[0] && current.diff(dates[0], 'days') > 30 || current && current > moment().subtract(1, "days").endOf('day');
      const tooEarly = dates[1] && dates[1].diff(current, 'days') > 30;
      return tooEarly || tooLate;
    }
  };
  const onOpenChange = open => {
    if (open) {
      setHackValue([]);
      setDates([]);
    } else {
      setHackValue(undefined);
    }
  };

  const columns = [
    {
      title: '所属应用',
      dataIndex: 'appId',
      key: 'appId',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <Select
            options={[
              {
                value: '',
                label: '全部',
              },
              ...props.appSelectList
            ]}
            label="所属应用"
            onSelect={(e) => {
              setAppId(e);
            }}
            value={appId}
          />
        );
      },
    },
    {
      title: '发送方式',
      dataIndex: 'sendType',
      key: 'sendType',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <Select
            options={[
              {
                value: '',
                label: '全部',
              },
              {
                value: '0',
                label: '5G消息',
              },
              {
                value: '1',
                label: '短信小程序',
              },
              {
                value: '2',
                label: 'H5 chatbot',
              }
            ]}
            onSelect={(e) => {
              setSendType(e);
              setTemplateId('');
              getTemplatesList({
                appId,
                sendType: e
              });
            }}
            value={sendType}
          />
        );
      },
    },
    {
      title: '发送模板',
      dataIndex: 'templateId',
      key: 'templateId',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <Select
            options={templatesList}
            onSelect={(e) => {
              setTemplateId(e);
            }}
            value={templateId}
          />
        );
      },
    },
    {
      title: '发送时间',
      dataIndex: 'sendTime',
      key: 'sendTime',
      colSize: 4,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <>
            <Radio.Group
              options={[
                {
                  label: '近7天',
                  value: '1',
                },
                {
                  label: '近30天',
                  value: '2',
                },
                {
                  label: '时间区间',
                  value: '3',
                },
              ]}
              value={sendTime}
              onChange={
                (e) => {
                  setSendTime(e.target.value)
                  setTimeRange(e.target.value === '3');
                }
              }
            />
            {
              timeRange ? <DatePicker.RangePicker
                value={hackValue || value}
                disabledDate={disabledDate}
                onCalendarChange={val => setDates(val)}
                onChange={val => setValue(val)}
                onOpenChange={onOpenChange}
                style={{
                  position: 'absolute',
                  width: 250,
                  top: 0
                }}
              /> : null
            }
          </>
        );
      },
    },
  ];

  const onReset = () => {
    setSendTime('1');
          setDates([]);
          setHackValue(undefined);
          setValue();
          setTimeRange(false);
          setAppId('');
          setSendType('');
          setTemplateId('');
          props.onReset();
  }

  return (
    <div className='custom-proform'>
      <ProTable
        columns={columns}
        actionRef={actionRef}
        dataSource={[]}
        options={false}
        rowKey="id"
        form={form}
        // search={{
        //   collapsed: false,
        //   span: 8,
        //   collapseRender: ()=>null,
        // }}
        search={{
          searchText: '查询',
          resetText: '重置',
          collapsed: false,
          span: 8,
          optionRender: ({ searchText, resetText }, { form }) => {
            return (
              <>
                <Button
                  type={'primary'}
                  onClick={() => {
                    form.submit();
                  }}
                >
                  {searchText}
                </Button>
                <Button
                  id={'resetBtn'}
                  type={'link'}
                  onClick={() => {
                    onReset();
                    form.resetFields();
                    form.submit();
                  }}
                >
                  {resetText}
                </Button>
              </>
            );
          },
        }}
        onReset={onReset}
        request={
          params => {
            let values = {};
            if (sendTime === '1') {
              values.endTime = moment().subtract(1, "days");
              values.startTime = moment().subtract(7, "days");
            } else if (sendTime === '2') {
              values.endTime = moment().subtract(1, "days");
              values.startTime = moment().subtract(30, "days");
            } else {
              if (dates && dates.length < 2) {
                values.endTime = moment().subtract(1, "days");
                values.startTime = moment().subtract(7, "days");
              } else {
                values.startTime = dates[0];
                values.endTime = dates[1];//前一天
              }
            }
            values.appId = appId;
            values.sendType = sendType;
            values.templateId = templateId;
            onSubmit(values);
          }
        }
      />
    </div>
  )

};
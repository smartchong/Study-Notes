import React, { useRef, useState } from 'react';
import { Statistic, Card, Row, Col } from 'antd';
import msgSuccessImg from '@/assets/msg_success.png';
import msgSendImg from '@/assets/msg_send.png';
import styles from './style.less';

export default (props) => {
    const { data } = props;

    return (
        <div className={styles.statisticsCard}>
            <div className='statisticsCard-title'>总量数据</div>
            <div className='statisticsCard-content'>
                <Row gutter={16} >
                    <Col span={12}>
                        <Card>
                            <Statistic
                                title="消息发送总量"
                                value={data.totalSendCount}
                                // precision={2}
                                // valueStyle={{ color: '#3f8600' }}
                                prefix={<img src={msgSendImg} />}
                                suffix="条"
                                
                            />
                        </Card>
                    </Col>
                    <Col span={12}>
                        <Card>
                            <Statistic
                                title="消息发送成功量"
                                value={data.successSendCOunt}
                                // precision={2}
                                // valueStyle={{ color: '#cf1322' }}
                                prefix={<img src={msgSuccessImg} style={{width: 54}}/>}
                                suffix="条"
                            />
                        </Card>
                    </Col>
                </Row>
            </div>
        </div>
    )

};
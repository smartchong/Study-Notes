import React, { useRef, useState } from 'react';
import { Statistic, Card, Row, Col } from 'antd';
import Chart from '@/components/Chart';
import styles from './style.less';

export default (props) => {
    const { data } = props;
    return (
        <div className={styles.statisticsCard}>
            <div className='statisticsCard-title'>图形数据</div>
            <div className='statisticsCard-content'>
                <Chart
                    title=''
                    // color={['red', 'green', 'blue']} 
                    // name={['消息点击量', '上行交互量', '外部链接点击量']} 
                    color={['red', 'green']} 
                    name={['消息点击量', '上行交互量']} 
                    x={data.x}
                    y={data.y}
                    unit='条'
                />
            </div>
        </div>
    )

};
import React, { useRef, useState } from 'react';
import { Statistic, Card, Row, Col } from 'antd';
import styles from './style.less';
import up_inter_count from '@/assets/up_inter_count.png';
import msg_click_count from '@/assets/msg_click_count.png';
import link_click_count from '@/assets/link_click_count.png';



export default (props) => {
    const { data } = props;

    return (
        <div className={styles.statisticsCard}>
            <div className='statisticsCard-title'>总量数据</div>
            <div className='statisticsCard-content'>
                <Row gutter={16} >
                    <Col span={12}>
                        <Card>
                            <Statistic
                                title="消息点击量"
                                value={data.sumMsgReadCount}
                                // precision={2}
                                // valueStyle={{ color: '#3f8600' }}
                                prefix={<img src={msg_click_count} />}
                                suffix="条"
                                
                            />
                        </Card>
                    </Col>
                    <Col span={12}>
                        <Card>
                            <Statistic
                                title="上行交互量"
                                value={data.sumUpCount}
                                // precision={2}
                                // valueStyle={{ color: '#cf1322' }}
                                prefix={<img src={up_inter_count} style={{width: 54}}/>}
                                suffix="条"
                            />
                        </Card>
                    </Col>
                    {/* <Col span={8}>
                        <Card>
                            <Statistic
                                title="外部链接点击量"
                                value={data.sumLinkClickCount}
                                // precision={2}
                                // valueStyle={{ color: '#cf1322' }}
                                prefix={<img src={link_click_count} style={{width: 54}}/>}
                                suffix="条"
                            />
                        </Card>
                    </Col> */}
                </Row>
            </div>
        </div>
    )

};
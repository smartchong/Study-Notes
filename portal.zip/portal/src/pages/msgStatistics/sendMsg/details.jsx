import React, { useState, useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Card, Table, Descriptions, Button } from 'antd';
import ProTable from '@ant-design/pro-table';
import styles from './style.less';
import { sendFailDetail, downloadUrl, download } from './service';
import { connect } from 'umi';
import Cookie from "js-cookie";
import moment from 'moment';

const Index = props => {

  const columns = [
    {
      title: '接收号码',
      dataIndex: 'mobile',
    },
    {
      title: '发送时间',
      dataIndex: 'createTime',
    },
    {
      title: '模板ID',
      dataIndex: 'templateId',
    },
    {
      title: '模板名称',
      dataIndex: 'templateName',
    },
    {
      title: '失败原因',
      dataIndex: 'resultDesc',
    }
  ];
  const fieldParams = JSON.parse(localStorage.getItem('failDetailParams'));

  return (
    <PageHeaderWrapper title={`发送数据详情${moment(localStorage.getItem('statisticDate')).format('YYYY-MM-DD')}`}>
      <Card className={styles.msgStatiticsDetail} bordered={false}>
        {/* <Descriptions title="提示:" column={1}>
          <Descriptions.Item>
            错误码XXX表示消息发送失败可能为XXXX、XXXXXXXX、XXXXXXXX。
          </Descriptions.Item>
          <Descriptions.Item>
            错误码XXX表示消息发送失败可能为XXXX、XXXXXXXX、XXXXXXXX。
          </Descriptions.Item>
          <Descriptions.Item>
            错误码XXX表示消息发送失败可能为XXXX、XXXXXXXX、XXXXXXXX。
          </Descriptions.Item>
          <Descriptions.Item>
            错误码XXX表示消息发送失败可能为XXXX、XXXXXXXX、XXXXXXXX。
          </Descriptions.Item>
        </Descriptions> */}
        <Button
          type="primary"
          className='export-btn'
          onClick={
            () => {
              let dataStr = ''; // 数据拼接字符串
              Object.keys(fieldParams).forEach(key => {
                  dataStr += `${key}=${fieldParams[key] || ''}&`;
              });
              dataStr = dataStr.substr(0, dataStr.lastIndexOf('&'));
              let url = downloadUrl + '?' + dataStr;
              // window.open(url);
              const link = document.createElement('a');
              link.style.display = 'none';
              link.href = url;
              document.body.appendChild(link);
              link.click();
              // 释放的 URL 对象以及移除 a 标签
              document.body.removeChild(link);

              
              // fetch(url, {
              //   method: 'GET',
              //   // body: JSON.stringify(fieldParams),
              //   headers: {
              //     'Content-Type': 'application/json;charset=UTF-8',
              //     'X-XSRF-TOKEN': Cookie.get('XSRF-TOKEN')
              //   }
              // }).then(function (response) {
              //   const filename = response.headers.get('content-disposition').split(';')[1].split('=')[1];
              //   response.blob().then(blob => {
              //     const link = document.createElement('a')
              //     link.style.display = 'none'
              //     // a 标签的 download 属性就是下载下来的文件名
              //     link.download = filename;
              //     link.href = URL.createObjectURL(blob)
              //     document.body.appendChild(link)
              //     link.click()
              //     // 释放的 URL 对象以及移除 a 标签
              //     URL.revokeObjectURL(link.href)
              //     document.body.removeChild(link)
              //   })
              // })
            }
          }
        >导出数据</Button>
        <ProTable
          // actionRef={actionRef}
          className='mt-40'
          columns={columns}
          rowKey="id"
          search={false}
          // options={false}
          toolBarRender={false}
          request={
            params => {
              params.pageNum = params.current;
              delete params.current;
              return sendFailDetail({ ...params, ...fieldParams });
            }
          }
        />
        {/* <Table
          columns={columns}
          dataSource={data}
          pagination={{ pageSize: 20, showSizeChanger: true, showQuickJumper: true }}
          bordered={true}
          className='mt-10'
        /> */}
        <div className='goBack-btn'>
          <Button
            type="primary"
            onClick={() => {
              props.history.goBack();
            }}
          >
            返回
          </Button>
        </div>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(
  ({ appAndTableList, testSend, loading }) =>
  ({

  })
)(Index);

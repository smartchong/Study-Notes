import request from '@/utils/request';
import API from '../../../services/api';

export async function statistics(params) {
  return request(API.MSGSTATISTICS.SEND.STATISTICS, {
    method: 'POST',
    data: { ...params },
  });
}

export async function sendFailDetail(params) {
  return request(API.MSGSTATISTICS.SEND.SENDFAILDETAIL, {
    method: 'POST',
    data: { ...params },
  });
}

export async function download(params) {
  return request(API.MSGSTATISTICS.SEND.DOWNLOADFILE, {
    method: 'POST',
    data: { ...params },
    headers: {
      'Accept': '*'
    }
  });
}

export const downloadUrl = API.MSGSTATISTICS.SEND.DOWNLOADFILE;
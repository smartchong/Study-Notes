import { message, notification } from 'antd';
import moment from 'moment';
import { statistics, sendFailDetail } from './service';

const Model = {
  namespace: 'sendMsg',
  state: {
    statistics: {
      totalSendCount: '--',
      successSendCOunt: '--'
    },
    chartData: {
      x: [],
      y: []
    },
    list: [],
    failDetail: [],
    //记录上次请求参数
    params: null
  },
  effects: {
    *fetchStatistics({ payload, callback }, { call, put }) {
      const response = yield call(statistics, payload);
      if (response && response.success) {
        yield put({
          type: 'setData',
          payload: {
            statistics: {
              totalSendCount: response.data.sumTotalCount,
              successSendCOunt: response.data.sumSuccessCount
            },
            list: response.data.list.slice().reverse(),
            chartData: {
              x: response.data.list.map(item => moment(item.statisticDate).format('YYYY-MM-DD')),
              y: [
                {
                  name: '消息发送总量',
                  data: response.data.list.map(item => item.totalCount),
                  type: 'line',
                },
                {
                  name: '消息发送成功量',
                  data: response.data.list.map(item => item.successCount),
                  type: 'line',
                }
              ],
            },
            params: payload
          },
        });
      } else {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
    *fetchFailDetail({ payload, callback }, { call, put }) {
      const response = yield call(sendFailDetail, payload);
      if (response && response.success) {
        yield put({
          type: 'setData',
          payload: response.data.content,
        });
      } else {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
  },
  reducers: {
    setData(state, { payload }) {
      return { ...state, ...payload };
    },
  },
};
export default Model;

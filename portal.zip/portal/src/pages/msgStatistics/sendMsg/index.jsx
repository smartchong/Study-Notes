import React, { useState, useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Card, Table } from 'antd';
import CustomProForm from '../components/CustomProForm';
import StatisticsCard from '../components/StatisticsCard';
import LineChart from '../components/LineChart';
import styles from '../style.less';
import { connect } from 'umi';
import moment from 'moment';

const Index = props => {

  const { appSelectList, dispatch, massSend, sendMsg } = props;
  const [ fieldsValue, setFieldsValue ] = useState(null);

  useEffect(()=>{
    if (dispatch && fieldsValue) {
      dispatch({
        type:'sendMsg/fetchStatistics',
        payload: fieldsValue
      })
    }
  }, [fieldsValue])

  const columns = [
    {
      title: '日期',
      dataIndex: 'statisticDate',
      render: (_, record) => moment(_).format('YYYY-MM-DD')
    },
    {
      title: '消息发送总量（条）',
      dataIndex: 'totalCount',
    },
    {
      title: '消息发送成功量（条）',
      dataIndex: 'successCount',
    },
    {
      title: '操作',
      dataIndex: 'op',
      render: (_, record) => {
        return <a
          onClick={() => {
            const params = {};
            params.appId = fieldsValue.appId || null;
            params.sendType = fieldsValue.sendType || null;
            params.templateId = fieldsValue.templateId || null;
            params.statisticDate = record.statisticDate;
            localStorage.setItem('failDetailParams', JSON.stringify(params));
            localStorage.setItem('statisticDate', record.statisticDate);
            props.history.push({
              pathname: `/layouts/msgStatistics/sendMsg/details`,
              state: {},
            });
          }}
        >失败详情</a>
      }
    },
  ];

  return (
    <PageHeaderWrapper>
      <Card className={styles.msgStatitics} bordered={false}>
        <CustomProForm
          appSelectList={appSelectList.map((item) => {
            return {
              'value': item.appId,
              'label': item.appName
            }
          })}
          getTemplatesList={(fieldsValue)=>{
            dispatch({
              type:'massSend/queryTemSelectList',
              payload:fieldsValue
            })
          }}
          onReset={() => {
            dispatch({
              type:'massSend/setTemSelectList',
              payload:{data: []}
            })
          }}
          templatesList={ massSend.temSelectList.map(item => {
            return {
              label: item.name,
              value: item.id
            }
          }) }
          onSubmit={(fieldsValue)=>{
            setFieldsValue(fieldsValue);
          }}
        />
        <StatisticsCard
          data={sendMsg.statistics}
        />
        <div className='mt-20'>
          <LineChart
            data={sendMsg.chartData}
          />
        </div>
        <div className='msgStatitics-table'>
          <div className='msgStatitics-table-title'>列表数据</div>
          <Table
            columns={columns}
            dataSource={sendMsg.list}
            pagination={false}
            bordered={true}
            style={{
              padding: '10px 20px 20px 20px'
            }}
          />
        </div>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(
  ({ sendMsg, appAndTableList, massSend, loading }) =>
    ({
      sendMsg,
      appSelectList: appAndTableList.appSelectList,
      massSend,
      loadingStatistics: loading.effects['sendMsg/fetchStatistics'],
      loadingFailDetail: loading.effects['sendMsg/fetchFailDetail']
    })
)(Index);

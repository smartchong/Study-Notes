import React from 'react';
import { Typography } from 'antd';
import styles from './component.less';
const { Text } = Typography;

const Msg = (props)=>{

  const { content } = props;

  return (
    <div className={styles.wrap}>
      <Text>
        {content}
      </Text>
    </div>
  )
}
export default Msg;

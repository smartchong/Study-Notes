import React, { useState } from 'react';
import moment from 'moment';
import { DatePicker } from 'antd';
const { RangePicker } = DatePicker;

const Index = props => {
  const [dates, setDates] = useState([]);
  const { onChange,range } = props;
  const disabledDate = current => {
    if (!dates || dates.length === 0) {
      return current && current > moment().endOf('day');
    }
    const tooLate = dates[0] && ((current.diff(dates[0], 'days') > range));
    const tooEarly = dates[1] && ((dates[1].diff(current, 'days') > range));
    if (dates[0]) {
      return tooLate || current > moment().endOf('day');
    }
    if (dates[1]) {
      return tooEarly || current > moment().endOf('day');
    }
  };
  return (
    <RangePicker
      {...props}
      style={{width:'100%'}}
      disabledDate={disabledDate}
      onCalendarChange={value => {
        setDates(value);
      }}
    />
  )
}

Index.defaultProps = {
  range: 1000
};

export default Index;


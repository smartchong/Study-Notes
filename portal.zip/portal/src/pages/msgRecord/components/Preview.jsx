import React from 'react';
import { Typography } from 'antd';
import classnames from 'classnames';
import styles from './component.less';
const { Text } = Typography;

const Preview  = (props)=>{
  const {templates,type,upOrDown} = props;
  const {text='',media={},generalPurposeCard={},generalPurposeCardCarousel={},menu=[]} = templates[type];

  const renderMedia = ()=>{
    let content = null;
    switch (type){
      case 1 :
        return (
          <div className="previewBg">
            {text}
          </div>
        )
        break;
      case 2 :
        return (
          <div className="previewBg">
            {renderCardMedia(media)}
          </div>
        )
        break;
      case 3 :
        return (
          <div className="previewBg">
            {renderCardMedia(media)}
          </div>
        )
        break;
      case 4 :
        return (
          <div className="previewBg">
            {renderCardMedia(media)}
          </div>
        )
        break;
      case 5 :
        content = generalPurposeCard['content'];
        const bgStyle = {
          backgroundColor:content['style']['message']['background-color'],
        };
        const titleStyle = {
          fontSize:content['style']['messageTitle']['font-size'],
          color:content['style']['messageTitle']['color'],
          fontWeight:content['style']['messageTitle']['font-weight'],
          textAlign:content['style']['messageTitle']['text-align'],
        };
        const descStyle = {
          fontSize:content['style']['messageDescription']['font-size'],
          color:content['style']['messageDescription']['color'],
          fontWeight:content['style']['messageDescription']['font-weight'],
          textAlign:content['style']['messageDescription']['text-align'],
        };
        return (
          <div
            style={{...bgStyle}}
          >
            {renderCardMedia(content['media'])}
            {/* 标题 */}
            <Text
              style={{...titleStyle}}
            >
              {content['title']}
            </Text>
            <br />
            {/* 描述 */}
            <Text
              style={{...descStyle}}
            >
              {content['description']}
            </Text>
            <br />
            {/* 按钮 */}
            <div className="cardBtn">
              {renderCardBtn(content['suggestions'],content["style"]["messageSuggestion"])}
            </div>
          </div>
        )
        break;
      case 6 :
        content = generalPurposeCardCarousel['content'];
        const bgStyles = {
          backgroundColor:content[0]['style']['message']['background-color'],
        };
        const titleStyles = {
          fontSize:content[0]['style']['messageTitle']['font-size'],
          color:content[0]['style']['messageTitle']['color'],
          fontWeight:content[0]['style']['messageTitle']['font-weight'],
          textAlign:content[0]['style']['messageTitle']['text-align'],
        };
        const descStyles = {
          fontSize:content[0]['style']['messageDescription']['font-size'],
          color:content[0]['style']['messageDescription']['color'],
          fontWeight:content[0]['style']['messageDescription']['font-weight'],
          textAlign:content[0]['style']['messageDescription']['text-align'],
        };
        return (
          <div className="cardsView">
            {
              content && content.map((item,index)=>{
                return (
                  <div
                    style={index === 0 ? {...bgStyles} : {}}
                    className="cardsViewItem"
                    key={index}
                  >
                    {renderCardMedia(item['media'])}
                    {/* 标题 */}
                    <Text
                      style={index === 0 ? {...titleStyles} : {}}
                    >{item['title']}</Text><br />
                    {/* 描述 */}
                    <Text
                      style={index === 0 ? {...descStyles} : {}}
                    >{item['description']}</Text><br />
                    {/* 按钮 */}
                    <div className="cardBtn">
                      {renderCardBtn(item['suggestions'],content[0]["style"]["messageSuggestion"],index)}
                    </div>
                  </div>
                )
              })
            }
          </div>
        )
        break;
      default:
        break;
    }
  }

  const renderCardMedia = (media) =>{
    const {mediaUrl,mediaContentType} = media;
    switch (mediaContentType){
      case 'audio/amr':
        return (
          <>
            <audio src={mediaUrl} controls /><br/>
          </>
        )
        break;
      case 'video/mp4':
        return (
          <>
            <video src={mediaUrl} controls /><br />
          </>
        )
        break;
      default:
        return (
          <>
            <img src={mediaUrl} alt=""/><br />
          </>
        )
        break;
    }
  }

  const renderCardBtn = (content,styles,serial = 0)=>{
    const isArray = Array.prototype.isPrototypeOf(content);
    const style = {
      color:styles["color"],
      fontWeight:styles["font-weight"],
      textAlign:styles["text-align"]
    };
    if(!content){
      return;
    }
    const dom = (item,index = 0)=>{
      if(item.hasOwnProperty('action')){
        return (
            <a
              style={serial === 0 ? {...style} : {}}
              key={index}
            >
              {item['action']['displayText']}
            </a>
        )
      }else if(item.hasOwnProperty('reply')){
        return (
            <a
              style={serial === 0 ? {...style} : {}}
              key={index}
            >
              {item['reply']['displayText']}
            </a>
        )
      }
    }

    if(isArray){
      return content.map((item,index)=>{
        return dom(item,index);
      })
    }
    return dom(content);
  }

  const renderBottomBtn = ()=>{
    return menu.map((item,index)=>{
      if(item.hasOwnProperty('action')){
        return (
          <a key={index}>{item['action']['displayText']}</a>
        )
      }else if(item.hasOwnProperty('reply')){
        return (
          <a key={index}>{item['reply']['displayText']}</a>
        )
      }
    })
  }

  return (
    <div className={styles.wrap}>
      {
        upOrDown === 1 ? (
          <div className={classnames(styles.box,styles.reverse)}>
            <div className={styles.avatar}></div>
            <div className={styles.content}>
              <div className={styles.media}>
                {renderMedia()}
              </div>
            </div>
          </div>
        ) : (
          <div className={styles.box}>
            <div className={styles.avatar}></div>
            <div className={styles.content}>
              <div className={styles.media}>
                {renderMedia()}
              </div>
            </div>
          </div>
        )
      }
      <div className={styles.btn}>
        {renderBottomBtn()}
      </div>
    </div>
  )
}
export default Preview;

import React from 'react';
import { Input } from 'antd';

const Index = props => {
    const { onChange,regex,maxLength } = props;
    return (
      <Input
        {...props}
        onChange={(e) => {
          const { value } = e.target;
          onChange(value.replace(regex,'').substring(0,maxLength));
        }}
      />
    )
}

export default Index;


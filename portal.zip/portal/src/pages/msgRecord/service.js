import request from '@/utils/request';
import API from '@/services/api';

export async function queryList(params) {
  return request(API.MSGRECORD.QUERY_LIST,{
    params
  });
}

export async function queryDetail(params) {
  return request(API.MSGRECORD.QUERY_DETAIL,{
    params
  });
}

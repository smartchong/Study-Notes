import API from '../../services/api';
const result = {
  code:1,
  success:true,
  data:[],
  message:'失败',
}
const data = {
  key: '2',
  time: '2017-10-01 14:05',
  app: '魔百合',
  status: 'success',
  operator: '18867109999',
  content: 'hello 百合',
  channel: 0,
  direction: 'ao',
};
const list = [];
for(var i = 0;i<100;i++){
  list.push({
    ...data,
    id:i,
  })
}

export default {
  [`GET  ${API.MSGRECORD.QUERY_LIST}`]: {
    ...result,
    data:list
  },
  [`GET ${RegExp(/msgRecord\/detail/)}`]:{
    ...result,
    data
  },
};

import React, { useEffect } from 'react';
import { Button, Card, Tabs, Row, Col } from 'antd';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import Preview from './components/Preview';
import Msg from './components/Msg';
import { connect,history,useParams } from 'umi';
import _ from 'lodash';
import styles from './style.less';
const { TabPane } = Tabs;
const baseUrl = location.href.split('/#/')[0];
const mediaUrl = '';
const GETMEGIAURL = (type)=>{
  let url = baseUrl + mediaUrl + '?id=';
  if(type === 'video'){
    url+= '64491a2245214ae58a1987b0504ee1f7'
  }else if (type === 'audio'){
    url+= 'c606a05831864f3abbc69016dbf6ff66';
  }else {
    url += '277aa40921b84837b7888a103f2c51c0';
  }
  return url;
};
const defaultTemplates = [

  //占位
  {

  },

  // Text
  {
    "text": "",
    "menu": []
  },

  // File : Image
  {
    "media": {
      "thumbnailContentType": "image/jpeg",
      "thumbnailUrl": GETMEGIAURL(),
      "mediaContentType": "image/jpeg",
      "mediaUrl": GETMEGIAURL(),
      "fileId": '',
      "thumbnailId":'',
    },
    "menu": []
  },

  // File : Audio
  {
    "media": {
      "thumbnailContentType": "",
      "thumbnailUrl": GETMEGIAURL(),
      "mediaContentType": "audio/amr",
      "mediaUrl": GETMEGIAURL('audio'),
      "fileId": '',
      "thumbnailId":'',
    },
    "menu": []
  },

  // File : Video
  {
    "media": {
      "thumbnailContentType": "image/jpeg",
      "thumbnailUrl": GETMEGIAURL(),
      "mediaContentType": "video/mp4",
      "mediaUrl": GETMEGIAURL('video'),
      "fileId": '',
      "thumbnailId":'',
    },
    "menu": []
  },

  // Card
  {
    "generalPurposeCard": {
      "content": {
        "title": "",
        "description": "",
        "media": {
          "height": "MEDIUM_HEIGHT",
          "thumbnailContentType": "image/jpeg",
          "thumbnailUrl": GETMEGIAURL(),
          "mediaContentType": "image/jpeg",
          "mediaUrl": GETMEGIAURL(),
          "fileId": '',
          "thumbnailId":'',
        },
        "suggestions": [],
        "style": {
          "message":{
            "background-color": "#ffffff",
          },
          "messageTitle": {
            "font-size": "16px",
            "color": "#000000",
            "font-weight": 400,
            "text-align": "left"
          },
          "messageDescription": {
            "font-size": "14px",
            "color": "#000000",
            "font-weight": 400,
            "text-align": "left"
          },
          "messageSuggestion": {
            "color": "#0000ff",
            "font-weight": 400,
            "text-align": "left"
          },
        }
      },
      "layout": {
        "cardOrientation": "VERTICAL",
        "cardWidth": "MEDIUM_WIDTH",
        "imageAlignment": "LEFT"
      }
    },
    "menu": [

    ]
  },

  // Card Carousel
  {
    "generalPurposeCardCarousel": {
      "content": [
        {
          "title": "",
          "description": "",
          "media": {
            "height": "MEDIUM_HEIGHT",
            "thumbnailContentType": "image/jpeg",
            "thumbnailUrl": GETMEGIAURL(),
            "mediaContentType": "image/jpeg",
            "mediaUrl": GETMEGIAURL(),
            "fileId": '',
            "thumbnailId":'',
          },
          "suggestions": [],
          "style": {
            "message":{
              "background-color": "#ffffff",
            },
            "messageTitle": {
              "font-size": "16px",
              "color": "#000000",
              "font-weight": 400,
              "text-align": "left"
            },
            "messageDescription": {
              "font-size": "14px",
              "color": "#000000",
              "font-weight": 400,
              "text-align": "left"
            },
            "messageSuggestion": {
              "color": "#0000ff",
              "font-weight": 400,
              "text-align": "left"
            },
          }
        },
        /*{
          "title": "",
          "description": "",
          "media": {
            "height": "MEDIUM_HEIGHT",
            "thumbnailContentType": "image/jpeg",
            "thumbnailUrl": GETMEGIAURL(),
            "mediaContentType": "image/jpeg",
            "mediaUrl": GETMEGIAURL(),
            "fileId": '',
            "thumbnailId":'',
          },
          "suggestions": [],
        }*/
      ],
      "layout": {
        "cardOrientation": "VERTICAL",
        "cardWidth": "MEDIUM_WIDTH",
        "imageAlignment": "LEFT"
      }
    },
    "menu": []
  },

];
const upOrDownList = [
  {
    label:'上行',
    value:1,
  },
  {
    label:'下行',
    value:0,
  },
];
const statusList = [
  {
    label:'发送中',
    value:'100',
  },
  {
    label:'已送达',
    value:'200',
  },
  {
    label:'已查看',
    value:'300',
  },
  {
    label:'发送失败',
    value:'400',
  },
  {
    label:'转短信',
    value:'500',
  },
  {
    label:'接收成功',
    value:'600',
  },
];
const sendTypeList = [
  {
    label:'5G消息',
    value:0,
  },
  {
    label:'短信小程序',
    value:1,
  },
  {
    label:'H5 Chatbot',
    value:2,
  },
];

const Detail =(props)=> {

  const params = useParams();
  const { dispatch,loading,msgRecord } = props;
  const { detailsData } = msgRecord;
  const defineTemplate = (param,type,upOrDown) => {
    let data;
    if (upOrDown === 1) {
      data = {
        text:param,
      };
    } else {
      data = JSON.parse(param);
    }
    const template = JSON.parse(JSON.stringify(defaultTemplates));
    template[type] = _.merge(template[type],data);
    return template;
  }
  useEffect(()=>{
    if(dispatch && !loading){
      dispatch({
        type:'msgRecord/fetchDetail',
        payload:{
          id:params.id
        }
      })
    }
  },[])
  if (!detailsData || detailsData.id !== Number(params.id)) {
    return null;
  }
  return (
    <PageHeaderWrapper
      content={
        <Button
          style={{float:'right'}}
          onClick={() => history.go(-1)}
        >
          返回
        </Button>
      }
    >
      <Card>
        <Row>
          <Col span={12}>
            <Card
              bordered={false}
              headStyle={{borderBottom:0}}
              title={"基本信息："}
            >
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>消息ID：</span>
                  <span className={styles.text}>{detailsData.messageId}</span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>模板名称：</span>
                  <span className={styles.text}>{detailsData.templateName}</span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>所属应用：</span>
                  <span className={styles.text}>{detailsData.appName}</span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>所属业务：</span>
                  <span className={styles.text}>{detailsData.chatbotName}</span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>发送方式：</span>
                  <span className={styles.text}>
                    {sendTypeList.find(item => item.value === detailsData.sendType) ? sendTypeList.find(item => item.value === detailsData.sendType).label : '-'}
                  </span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>发送方向：</span>
                  <span className={styles.text}>
                    {upOrDownList.find(item => item.value === detailsData.upOrDown) ? upOrDownList.find(item => item.value === detailsData.upOrDown).label : '-'}
                  </span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>手机号码：</span>
                  <span className={styles.text}>{detailsData.mobile}</span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>所属群组：</span>
                  <span className={styles.text}>{detailsData.groupName}</span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>状态：</span>
                  <span className={styles.text}>
                    {statusList.find(item => item.value === detailsData.resultCode) ? statusList.find(item => item.value === detailsData.resultCode).label : '-'}
                  </span>
                </Col>
              </Row>
              <Row gutter={[24,24]}>
                <Col span={24}>
                  <span>发送时间：</span>
                  <span className={styles.text}>{detailsData.createTime}</span>
                </Col>
              </Row>
            </Card>
          </Col>
          <Col span={12}>
            <Card
              bordered={false}
              headStyle={{borderBottom:0}}
              bodyStyle={{padding:0}}
              title={"消息内容："}
            >
              {
                detailsData.sendType === 0 ? (
                  !detailsData.msgText ? (
                    <Preview
                      templates={defineTemplate(detailsData.bodyText,detailsData.contentType,detailsData.upOrDown)}
                      type={detailsData.contentType}
                      upOrDown={detailsData.upOrDown}
                    />
                  ) : (
                    <Tabs type={'card'} tabPosition={'top'}>
                        <TabPane tab="短信内容预览" key="1">
                          <Msg
                            content={detailsData.msgText}
                          />
                        </TabPane>
                        <TabPane tab="聊天窗口消息预览" key="2">
                          <Preview
                            templates={defineTemplate(detailsData.bodyText,detailsData.contentType,detailsData.upOrDown)}
                            type={detailsData.contentType}
                            upOrDown={detailsData.upOrDown}
                          />
                        </TabPane>
                      </Tabs>
                  )                 
                ) : (
                  detailsData.sendType === 1 ? (
                    <Msg
                      content={detailsData.msgText}
                    />
                  ) : (
                    detailsData.sendType === 2 ? (
                      !detailsData.msgText ? (
                        <Preview
                          templates={defineTemplate(detailsData.bodyText,detailsData.contentType,detailsData.upOrDown)}
                          type={detailsData.contentType}
                          upOrDown={detailsData.upOrDown}
                        />
                      ) : (
                        <Tabs type={'card'} tabPosition={'top'}>
                          <TabPane tab="短信内容预览" key="1">
                            <Msg
                              content={detailsData.msgText}
                            />
                          </TabPane>
                          <TabPane tab="聊天窗口消息预览" key="2">
                            <Preview
                              templates={defineTemplate(detailsData.bodyText,detailsData.contentType,detailsData.upOrDown)}
                              type={detailsData.contentType}
                              upOrDown={detailsData.upOrDown}
                            />
                          </TabPane>
                        </Tabs>
                      )
                    ) : null
                  )
                )
              }
            </Card>
          </Col>
        </Row>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ msgRecord, loading }) => ({
  msgRecord,
  loading: loading.effects['msgRecord/fetchDetail'],
}))(Detail);

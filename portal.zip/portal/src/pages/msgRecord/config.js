export default {
  msgStatus: {
    100: '发送中',
    200: '已送达',
    300: '已查看',
    400: '发送失败',
    500: '转短信',
    600: '接收成功',
  },
  msgUpOrDown: {
    0: '发出',
    1: '收到',
  },
  fallbackSupported: [
    { label:'5G消息',value:0 },
    { label:'短信小程序',value:1 },
  ],
};

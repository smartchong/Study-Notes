import { queryDetail } from './service';

const Model = {
  namespace: 'msgRecord',
  state: {
    detailsData:null,
  },
  effects: {
    *fetchDetail({payload}, { call, put }) {
      const response = yield call(queryDetail,payload);
      yield put({
        type: 'setDetail',
        payload: response,
      });
    },
  },
  reducers: {
    show(state, { payload }) {
      return { ...state, ...payload };
    },
    setDetail(state, { payload }) {
      return { ...state, detailsData:payload.data };
    },
  },
};
export default Model;

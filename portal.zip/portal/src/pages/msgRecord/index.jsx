import React, { useRef } from 'react';
import { Card, Button, Select } from 'antd';
import ProTable from '@ant-design/pro-table';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ControledInput from './components/Input';
import ControledRangePicker from './components/RangePicker';
import { connect,history } from 'umi';
import API from '@/services/api';
import { queryList } from './service';
import styles from './style.less';
const { Option } = Select;
const prepend = (arr,item) => {
  const temp = arr.slice(0);
  temp.unshift(item);
  return temp;
}
const sendTypeList = [
  { label:'全部',value:'' },
  { label:'5G消息',value:0 },
  { label:'短信小程序',value:1 },
  { label:'H5 Chatbot',value:2 },
];
const upOrDownList = [
  { label:'全部',value:'' },
  { label:'下行',value:0 },
  { label:'上行',value:1 },
];
const resultCodeList = [
  { label:'全部',value:'' },
  { label:'发送中',value:'100' },
  { label:'已送达',value:'200' },
  { label:'已查看',value:'300' },
  { label:'发送失败',value:'400' },
  { label:'转短信',value:'500' },
  { label:'接收成功',value:'600' },
];

const Index =(props)=> {

  const {
    dispatch,
    currentUser,
  } = props;
  const { chatbotType } = currentUser;
  const actionRef = useRef();
  const columns = [
    {
      title: '消息ID',
      dataIndex: 'messageId',
      width: 100,
      ellipsis:true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入消息ID"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '模板名称',
      dataIndex: 'templateName',
      ellipsis:true,
      width: 180,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入模板名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属应用',
      dataIndex: 'appName',
      width:180,
      ellipsis:true,
      textWrap: 'word-break',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入所属应用"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotType',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              prepend(chatbotType,{label:'全部', value:''}).map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{chatbotType.find(item => item.value === _) ? chatbotType.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '发送方式',
      dataIndex: 'sendType',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              sendTypeList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{sendTypeList.find(item => item.value === _) ? sendTypeList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '发送方向',
      dataIndex: 'upOrDown',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              upOrDownList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{upOrDownList.find(item => item.value === _) ? upOrDownList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '手机号码',
      dataIndex: 'mobile',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={11}
            regex={/[^\d]/g}
            placeholder="请输入手机号码"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属群组',
      dataIndex: 'groupName',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入所属群组"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '状态',
      dataIndex: 'resultCode',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              resultCodeList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{resultCodeList.find(item => item.value === _) ? resultCodeList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '发送时间',
      dataIndex: 'createTime',
      valueType: 'date',
      renderFormItem: (_, { type, defaultRender,...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
        <a
          onClick={() => {
            history.push(`/layouts/msgRecord/details/${record.id}`)
          }}
        >
          查看
        </a>
        </>
      ),
    },
  ];

  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <ProTable
          headerTitle=""
          actionRef={actionRef}
          rowKey="id"
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          rowSelection={false}
          options={false}
          tableAlertRender={false}
          toolBarRender={false}
          request={params => {
              params.status = params.resultCode;
              params.startTime = params.createTime && params.createTime.length ? params.createTime[0] + ' 00:00:00': '';
              params.endTime = params.createTime && params.createTime.length ? params.createTime[1] + ' 23:59:59': '';
              return queryList({...params,pageNum:params.current})
            }
          }
          columns={columns}
        />
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ msgRecord, loading, user }) => ({
  msgRecord,
  loading: loading.effects[API.MSGRECORD.QUERY_LIST],
  currentUser:user.currentUser,
}))(Index);

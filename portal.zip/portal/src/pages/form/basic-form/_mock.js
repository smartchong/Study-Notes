// eslint-disable-next-line import/no-extraneous-dependencies
export default {
  'POST  /api/forms': (_, res) => {
    res.send({
      message: 'Ok',
    });
  },
};

import { notification } from 'antd';
import { authAdd,authModify,authDetail } from './service';

const Model = {
  namespace: 'userAuthInfo',
  state: {
    data: undefined,
  },
  effects: {
    *submit({ payload }, { call, put }) {
      const response = yield call(payload.status === 0 ? authAdd : authModify, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      }
      return response;
    },
    *fetchDetail({ payload }, { call, put }) {
      const response = yield call(authDetail, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      } else {
        yield put({
          type: 'changeData',
          payload: response.data,
        });
      }
    }
  },
  reducers: {
    changeData(state, { payload }) {
      return { ...state, data: payload };
    }
  },
};
export default Model;

import styles from './style.less';
import React, { useState,useEffect } from 'react';
import { connect } from "umi";
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button,Card,Form,Typography,Row,Col,Space } from 'antd';
import CITYS from '@/utils/city';
import CompanyForm from './components/CompanyForm';
import AdminForm from './components/AdminForm';
import CompanyDetail from './components/CompanyDetail';
import AdminDetail from './components/AdminDetail';
import AuditDetail from './components/AuditDetail';
const { Text } = Typography;
const statusList = [
  {
    label:'待认证',
    value:0
  },
  {
    label:'审核通过',
    value:1
  },
  {
    label:'审核不通过',
    value:2
  },
  {
    label:'待审核',
    value:3
  },
];
const findCityCode = (CityJSON,cityArr) => {
  let province,city,county;
  switch(cityArr.length) {
    case 3:
      province = CityJSON.find(item => item.value === cityArr[0]);
      city = cityArr[1] ? province.children.find(item => item.value === cityArr[1]) : '';
      county = cityArr[2] ? city.children.find(item => item.value === cityArr[2]) : '';
      break;
    case 2:
      province = CityJSON.find(item => item.value === cityArr[0]);
      city = cityArr[1] ? province.children.find(item => item.value === cityArr[1]) : '';
      county = '';
      break;
    case 1:
      province = CityJSON.find(item => item.value === cityArr[0]);
      city = '';
      county = '';
      break;
    default:
  }
  return (type) => {
    switch(type){
      case 'province':
        return province.code;
      case 'city':
        return city ? city.code : '';
      case 'county':
        return county ? county.code : '';
      default:
    }
  }
}

const AuthInfo = ({ loading, dispatch, userAuthInfo, currentUser }) => {
  const [isEdit,setIsEdit] = useState(false);
  const [form] = Form.useForm();
  useEffect(() => {
    if (currentUser.verifyStatus !== 0) {
      dispatch({
        type: 'userAuthInfo/fetchDetail'
      });
    }
  }, [currentUser]);
  const submit = async (name,{ values,forms }) => {
    const { companyForm,adminForm } = forms;
    Promise.all([companyForm.validateFields(), adminForm.validateFields()]).then((params) => {
      params = {
        ...params[0],
        ...params[1],
      }
      console.log(params.companyLocation);
      params.provinceCode = findCityCode(CITYS,params.companyLocation)('province');
      params.provinceName = params.companyLocation[0];
      params.cityCode = findCityCode(CITYS,params.companyLocation)('city');
      params.cityName = params.companyLocation.length > 1 ? params.companyLocation[1] : '';
      params.countyCode = findCityCode(CITYS,params.companyLocation)('county');
      params.countyName = params.companyLocation.length > 2 ? params.companyLocation[2] : '';
      params.status = currentUser.verifyStatus;
      if (data && data.id) {
        params.id = data.id;
      }
      delete params.companyLocation;
      dispatch({
        type: 'userAuthInfo/submit',
        payload: params,
      }).then(res => {
        if (
          res
          && res.success
        ) {
          if (isEdit) {
            setIsEdit(false);
          }
          dispatch({
            type: 'user/fetchCurrent',
          });
        }
      })
    });
  }
  const { data } = userAuthInfo;
  const { verifyStatus } = currentUser;
  return (
    <PageHeaderWrapper
      className={styles.header}
      content={
        isEdit ? null : (
          <div style={{float:'right'}}>
            <Text>认证状态：</Text>
            {
              verifyStatus === 1 ? (
                <Text type="success">审核通过</Text>
              ) : (
                verifyStatus === 3 ? (
                  <Text type="warning">待审核</Text>
                ) : (
                  <Text type="danger">{statusList.find(_ => _.value === verifyStatus) ? statusList.find(_ => _.value === verifyStatus).label : '-'}</Text>
                )
              )
            }
          </div>
        )}
    >
      {
        verifyStatus === 0 || isEdit ? (
          <Form.Provider
            onFormFinish={submit}
          >
            <Card
              title={"公司信息"}
              bordered={false}
            >
              <CompanyForm
                CITYS={CITYS}
                data={data}
                status={verifyStatus}
              />
            </Card>
            <Card
              title={"管理员信息"}
              bordered={false}
            >
              <AdminForm
                data={data}
                status={verifyStatus}
              />
            </Card>
            <Card
              bordered={false}
            >
              <Form
                form={form}
                name={"submitForm"}
              >
                <Form.Item
                  wrapperCol={{
                    offset:8,
                    span:8,
                  }}
                >
                  {
                    verifyStatus === 0 ? (
                      <Button
                        htmlType="submit"
                        type={"primary"}
                        style={{width:100}}
                        loading={loading}
                      >
                        提交
                      </Button>
                    ) : (
                      isEdit ? (
                        <Space size={"large"}>
                          <Button
                            style={{width:100}}
                            onClick={() => {
                              setIsEdit(false)
                            }}
                          >
                            取消
                          </Button>
                          <Button
                            htmlType="submit"
                            type={"primary"}
                            style={{width:100}}
                            loading={loading}
                          >
                            确定修改
                          </Button>
                        </Space>
                      ) : null
                    )
                  }
                </Form.Item>
              </Form>
            </Card>
          </Form.Provider>
        ) : (verifyStatus === 1 || verifyStatus === 2 || verifyStatus === 3) && !isEdit ? (
          <>
            <Card
              title={"公司信息"}
              bordered={false}
            >
              {
                data ? (
                  <CompanyDetail
                    data={data}
                  />
                ) : null
              }
            </Card>
            <Card
              title={"管理员信息"}
              bordered={false}
            >
              {
                data ? (
                  <AdminDetail
                    data={data}
                  />
                ) : null
              }
            </Card>
            {
              verifyStatus === 1 || verifyStatus === 2 ? (
                <Card
                  title={"审核信息"}
                  bordered={false}
                >
                  {
                    data ? (
                      <AuditDetail
                        data={data}
                      />
                    ) : null
                  }
                </Card>
              ) : null
            }
            {
              verifyStatus === 2 ? (
                <Card
                  bordered={false}
                >
                  <Row>
                    <Col span={8} offset={8}>
                      <Button
                        type={"primary"}
                        style={{width:100}}
                        onClick={() => { setIsEdit(true) }}
                      >修改</Button>
                    </Col>
                  </Row>
                </Card>
              ) : null
            }
          </>
        ) : null
      }
    </PageHeaderWrapper>
  )
}

export default connect(
  ({ userAuthInfo, loading, user }) => ({
    userAuthInfo,
    loading: loading.effects['userAuthInfo/submit'],
    currentUser:user.currentUser,
  })
)(AuthInfo);

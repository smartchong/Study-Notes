import request from '@/utils/request';
import API from '../../../services/api';

export async function authAdd(params) {
  return request(API.AUTH.ADD, {
    method: 'POST',
    data: { ...params },
  });
}

export async function authModify(params) {
  return request(API.AUTH.MODIFY, {
    method: 'POST',
    data: { ...params },
  });
}

export async function authDetail(params) {
  return request(API.AUTH.DETAIL, {
    params,
  });
}

export async function repeatCheck(params) {
  return request(API.AUTH.REPEATCHECK, {
    method: 'POST',
    data: { ...params },
  });
}

export function getUploadAction() {
  return API.AUTH.UPLOAD;
}

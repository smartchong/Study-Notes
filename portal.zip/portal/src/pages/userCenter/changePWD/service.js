import request from '@/utils/request';
import API from '../../../services/api';

export function getImgCaptcha() {
  return `${API.LOGIN.CAPTCHA_IMG}?_=${new Date().getTime()}`
}

export async function getCaptcha(params) {
  return request(API.LOGIN.CAPTCHA, {
    method: 'POST',
    data: params,
  });
}

export async function changePassword(params) {
  return request(API.USER.CHANGEPWD, {
    method: 'POST',
    data: params,
  });
}

import React, { useState,useEffect,useCallback } from 'react';
import { Button,Card,Form,Input,Row,Col,Modal,message,notification } from 'antd';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { connect } from "umi";
import JSEncrypt from 'jsencrypt';
import { getCaptcha, getImgCaptcha, changePassword } from "./service";
import styles from './style.less';

const FormItem = Form.Item;
const encrypt = new JSEncrypt();
const PUBLICKEY = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCTUmOz914THaM/pFuuOvFu2Sm2Vxw35aiuZkwIezmAgJ0rAM1oAGrDKoLiBGjca7bZYHpX5u3yBnLTf6ypXLWfrETDDdCnVt7RKOyaeewu5aNLV6MYZMGos63ItvWra+B1qBM4eiSxJRQwZY5GbBGzOPQGZ2FcQa6EjMEwMRhwoQIDAQAB';

const ChangePWD = ({ loading, dispatch, userCenterAndChangePWD, currentUser }) => {
  const [form] = Form.useForm();
  const [count, setCount] = useState(60);
  const [timing, setTiming] = useState(false);
  const [imgCaptcha, setImgCaptcha] = useState(getImgCaptcha());

  useEffect(() => {
    if (!userCenterAndChangePWD) {
        return;
    }
    if (userCenterAndChangePWD.status === true) {
        dispatch({
          type: 'userCenterAndChangePWD/changePWDHandle',
          payload: {
            success: undefined
          },
        });
        Modal.success({
          title: '提示',
          content: '恭喜您修改密码成功！',
          okText: '确认',
        });
        form.resetFields();
        window.location.reload();
    }
  }, [userCenterAndChangePWD]);

  useEffect(() => {
    let interval = 0;

    if (timing) {
      interval = window.setInterval(() => {
        setCount(preSecond => {
          if (preSecond <= 1) {
            setTiming(false);
            clearInterval(interval); // 重置秒数

            return 60;
          }

          return preSecond - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [timing]);

  const onFinish = values => {
    encrypt.setPublicKey(PUBLICKEY);
    values.oldPassword = encrypt.encrypt(values.oldPassword);
    values.newPassword = encrypt.encrypt(values.newPassword);
    values.rePassword = values.newPassword;
    dispatch({
      type: 'userCenterAndChangePWD/submit',
      payload: { ...values },
    });
  };
  // 获取短信验证码
  const onGetCaptcha = useCallback(async params => {
    const result = await getCaptcha(params);
    if (result.success === false) {
      notification.error({
        message: result.message,
      });
      return;
    }
    message.success('获取验证码成功！');
    setTiming(true);
  }, []);
  // 校验两次密码是否一致
  const checkConfirm = (_, value) => {
    const promise = Promise;
    if (value && value !== form.getFieldValue('newPassword')) {
      return promise.reject('密码不一致！');
    }
    return promise.resolve();
  };

  return (
    <PageHeaderWrapper>
      <Card
        hoverable={true}
      >
        <Form
          form={form}
          name="ChangePWD"
          onFinish={onFinish}
          hideRequiredMark={true}
        >
          {/* 手机号码 */}
          <Form.Item
            label={'手机号码'}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 8 }}
          >
            {currentUser.mobile && currentUser.mobile.replace(/(\d{3})\d{4}(\d{4})/, "$1****$2")}
          </Form.Item>
          {/* 图形验证码 */}
          <FormItem
            style={{marginBottom:0}}
            shouldUpdate
          >
            {({ getFieldValue }) => (
              <FormItem
                name="imageCode"
                label={'图形验证码'}
                labelCol={{ span: 8 }}
                wrapperCol={{ span: 8 }}
                rules={[
                  {
                    required: true,
                    message: '请输入图形验证码！',
                    whitespace: true,
                  },
                  {
                    pattern: /^\d{4}$/,
                    message: '图形验证码错误！',
                  }
                ]}
              >
                <Input
                  maxLength={4}
                  suffix={<img className={styles.captchaImage} src={imgCaptcha} id='img_c'/>}
                  addonAfter={
                    <div
                      style={{ cursor: 'pointer'}}
                      onClick={()=>{
                        setImgCaptcha(getImgCaptcha())
                      }}
                    >
                      刷新
                    </div>
                  }
                />
              </FormItem>
            )}
          </FormItem>
          {/* 短信验证码 */}
          <FormItem
            style={{marginBottom:0}}
            shouldUpdate
          >
            {({ getFieldValue,validateFields }) => (
              <Row gutter={8}>
                <Col span={12}>
                  <FormItem
                    name={'smsCode'}
                    label={'短信验证码'}
                    extra={'请输入您获取到的验证码'}
                    labelCol={{ span: 16 }}
                    wrapperCol={{ span: 8 }}
                    rules={[
                      {
                        required: true,
                        message: '请输入短信验证码！',
                        whitespace: true,
                      },
                      {
                        pattern: /^\d{6}$/,
                        message: '短信验证码错误！',
                      }
                    ]}
                  >
                    <Input
                      maxLength={6}
                    />
                  </FormItem>
                </Col>
                <Col span={4}>
                  <Button
                    disabled={timing}
                    className={styles.getCaptcha}
                    onClick={() => {
                      validateFields(['imageCode']).then(() => {
                        const mobile = currentUser.mobile;
                        const imageCode = getFieldValue('imageCode');
                        onGetCaptcha({
                          mobile,
                          imageCode,
                          operation: 5
                        });
                      });
                    }}
                  >
                    {timing ? `${count} 秒后重新获取` : '获取短信验证码'}
                  </Button>
                </Col>
              </Row>
            )}
          </FormItem>
          {/* 原密码 */}
          <FormItem
            name="oldPassword"
            label={'原密码'}
            extra={'请输入您现在使用的密码'}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 8 }}
            rules={[
              {
                required: true,
                message: '请输入原密码！',
                whitespace: true,
              },
              {
                pattern: /^((?=.*?\d)(?=.*?[A-Za-z])|(?=.*?\d)(?=.*?[$#@^&_=+%<>{}?~!])|(?=.*?[A-Za-z])(?=.*?[$#@^&_=+%<>{}?~!]))[\dA-Za-z$#@^&_=+%<>{}?~!]{8,20}$/,
                message: '原密码错误！',
              },
            ]}
          >
            <Input.Password
              maxLength={20}
            />
          </FormItem>
          {/* 新密码 */}
          <FormItem
            name="newPassword"
            label={'新密码'}
            extra={'请输入新的密码，如放弃修改请直接离开此界面'}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 8 }}
            rules={[
              {
                required: true,
                message: '请输入新密码！',
                whitespace: true,
              },
              {
                pattern: /^((?=.*?\d)(?=.*?[A-Za-z])|(?=.*?\d)(?=.*?[$#@^&_=+%<>{}?~!])|(?=.*?[A-Za-z])(?=.*?[$#@^&_=+%<>{}?~!]))[\dA-Za-z$#@^&_=+%<>{}?~!]{8,20}$/,
                message: '密码格式不正确！',
              },
            ]}
          >
            <Input.Password
              maxLength={20}
            />
          </FormItem>
          {/* 再次输入密码 */}
          <FormItem
            name="rePassword"
            label={'再次输入密码'}
            extra={'请再次输入新密码'}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 8 }}
            rules={[
              {
                required: true,
                message: '请再次输入密码！',
                whitespace: true,
              },
              {
                validator: checkConfirm,
              },
            ]}
          >
            <Input.Password
              maxLength={20}
            />
          </FormItem>
          <FormItem
            wrapperCol={{ span: 8, offset: 8 }}
            shouldUpdate
          >
            {() => {
              return (
                <Button
                  loading={loading}
                  className={styles.submit}
                  type="primary"
                  htmlType="submit"
                >
                  确定
                </Button>
              )
            }}
          </FormItem>
        </Form>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ userCenterAndChangePWD, loading , user }) => ({
  userCenterAndChangePWD,
  loading: loading.effects['userCenterAndChangePWD/submit'],
  currentUser:user.currentUser,
}))(ChangePWD);

import { notification } from 'antd';
import { changePassword } from './service';

const Model = {
  namespace: 'userCenterAndChangePWD',
  state: {
    status: undefined,
  },
  effects: {
    *submit({ payload }, { call, put }) {
      const response = yield call(changePassword, payload);
      yield put({
        type: 'changePWDHandle',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      }
    },
  },
  reducers: {
    changePWDHandle(state, { payload }) {
      return { ...state, status: payload.success };
    },
  },
};
export default Model;

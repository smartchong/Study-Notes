const Model = {
  namespace: 'userCenterAndAccount',
  state: {

  },
  effects: {
    *submit({ payload }, { call, put }) {

    },
  },
  reducers: {

  },
};
export default Model;

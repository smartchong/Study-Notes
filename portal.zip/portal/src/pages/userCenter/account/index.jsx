import React, { useState } from 'react';
import { Button,Card,notification } from 'antd';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ModifyForm from './components/ModifyForm';
import { changePhone } from "./service";
import { connect } from "umi";
import styles from './style.less';

const Account = ({ currentUser,dispatch }) => {
  const [visible, handleVisible] = useState(false);

  return (
    <PageHeaderWrapper>
      <Card
        hoverable={true}
      >
        <div className={styles.account}>
          <div>
            <div className={styles.row}>
              <span className={styles.title}>用户名：</span>
              <span>{currentUser.name}</span>
            </div>
            <div className={styles.row}>
              <span className={styles.title}>手机号码：</span>
              <span>{currentUser.mobile}</span>
              <Button
                onClick={() => handleVisible(true)}
                className={styles.modifyBtn}
              >修改</Button>
            </div>
            <div className={styles.row}>
              <span className={styles.title}>邮箱：</span>
              <span>{currentUser.email}</span>
            </div>
          </div>
        </div>
      </Card>
      <ModifyForm
        onSubmit={async (value,callBack) => {
          console.log(value);
          value.newMobile = value.mobilePhone;
          const response = await changePhone(value);

          if (response.success) {
            callBack && callBack();
            handleVisible(false);
            if (dispatch) {
              dispatch({
                type: 'user/fetchCurrent',
              });
            }
          } else {
            notification.error({
              message: response.message,
            });
          }

        }}
        onCancel={() => handleVisible(false)}
        modalVisible={visible}
      />
    </PageHeaderWrapper>
  )
}

export default connect(({ userCenterAndAccount, loading, user}) => ({
  userCenterAndAccount,
  loading: loading.effects['userCenterAndAccount/submit'],
  currentUser:user.currentUser,
}))(Account);

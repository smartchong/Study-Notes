import request from '@/utils/request';
import API from '../../../services/api';

export function getImgCaptcha() {
  return `${API.LOGIN.CAPTCHA_IMG}?_=${new Date().getTime()}`
}

export async function getCaptcha(params) {
  return request(API.LOGIN.CAPTCHA, {
    method: 'POST',
    data: params,
  });
}

export async function repeatCheck(params) {
  return request(API.REGISTER.REPEATCHECK, {
    method: 'POST',
    data: params,
  })
}

export async function changePhone(params) {
  return request(API.USER.CHANGEPHONE, {
    method: 'POST',
    data: params,
  })
}

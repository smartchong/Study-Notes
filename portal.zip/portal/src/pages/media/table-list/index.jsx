import React, { useState, useRef, useEffect } from 'react';
import { Button, Divider, message, Card, Modal, Select, Pagination, Empty } from 'antd';
import { PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import ControledInput from './components/Input';
import ControledRangePicker from './components/RangePicker';
import CreateForm from './components/CreateForm';
import DetailForm from './components/DetailForm';
import UpdateForm from './components/UpdateForm';
import UploadForm from './components/UploadForm';
import { connect } from 'umi';
import { queryRule, queryModalRule, updateRule, addRule, removeRule } from './service';
import CardList from './components/CardList';
import styles from './style.less';
const { Option } = Select;
/**
 * 添加节点
 * @param fields
 */
const uploadAdd = async fields => {
  const hide = message.loading('正在添加');

  try {
    await addRule({
      desc: fields.desc,
    });
    hide();
    message.success('添加成功');
    return true;
  } catch (error) {
    hide();
    message.error('添加失败请重试！');
    return false;
  }
}
const handleAdd = async fields => {
  const hide = message.loading('正在添加');

  try {
    const ret = await addRule({
      desc: fields.desc,
    });
    hide();
    if (ret && ret.success) {
      message.success('添加成功');
      return true;
    } else {
      message.success(ret.message || '添加失败请重试!');
      return false;
    }

  } catch (error) {
    hide();
    message.error('添加失败请重试！');
    return false;
  }
};
/**
 * 更新节点
 * @param fields
 */
const handleUpdate = async fields => {
  const hide = message.loading('正在配置');

  try {
    await updateRule({
      name: fields.name,
      desc: fields.desc,
      key: fields.key,
    });
    hide();
    message.success('配置成功');
    return true;
  } catch (error) {
    hide();
    message.error('配置失败请重试！');
    return false;
  }
};
const prepend = (arr, item) => {
  const temp = arr.slice(0);
  temp.unshift(item);
  return temp;
}
const statusList = [
  {
    label: '全部',
    value: '',
  },
  {
    label: '待审核',
    value: 1,
  },
  {
    label: '审核通过',
    value: 2,
  },
  {
    label: '审核不通过',
    value: 3,
  },
];

const TableList = (props) => {

  const {
    dispatch,
    appLoading,
    appSelectList,
    isHeader = true,
    isUploadBtn = true,
    isUseBtn = false,
    modalParams = null,
    onOkBtn = () => { },
    currentUser,
  } = props;

  const [createModalVisible, handleModalVisible] = useState(false);
  const [updateModalVisible, handleUpdateModalVisible] = useState(false);
  const [uploadModalVisible, handleUploadModalVisible] = useState(false);
  const [detailModalVisible, setDetailModalVisible] = useState(false);
  const [stepFormValues, setStepFormValues] = useState({});
  const [selectedItems, setSelectedItems] = useState([]);
  const [list, setList] = useState({});
  const [checkAllBtnTxt, setCheckAllBtnTxt] = useState('全选');
  const [pageNum, setPageNum] = useState(1);
  /**
   *  删除节点
   * @param selectedRows
   */
  const handleRemove = async selectedRows => {
    const hide = message.loading('正在删除');
    try {
      const ret = await removeRule({
        ids: selectedRows,
      });
      hide();
      if (ret && ret.success) {
        message.success('删除成功');
        if (actionRef.current) {
          actionRef.current.reload();
        }
        return true;
      } else {
        message.error('删除失败，请重试');
      }

    } catch (error) {
      hide();
      message.error('操作失败，请重试');
      return false;
    }
  };
  const actionRef = useRef();
  const { verifyStatus, chatbotType } = currentUser;
  const columns = [
    {
      title: '媒体名称',
      dataIndex: 'mediaName',
      // hideInTable: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={128}
            // regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入媒体名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '媒体名称',
      dataIndex: 'fileName',
      hideInTable: true,
      ellipsis: true,
      width: 300,
      textWrap: 'word-break',
      hideInSearch: true,
    },
    {
      title: '类型',
      dataIndex: 'fileType',
      filters: false,
      initialValue: '0',
      // hideInTable: true,
      valueEnum: {
        0: { text: '全部' },
        1: { text: '图片' },
        2: { text: '音频' },
        3: { text: '视频' },
      },
    },
    {
      title: '所属应用',
      dataIndex: 'appName',
      ellipsis: true,
      width: 200,
      // hideInTable: true,
      textWrap: 'word-break',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入所属应用"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotName',
      width: 100,
      ellipsis: true,
      // hideInTable: true,
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              prepend(chatbotType, { label: '全部', value: '' }).map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
    },
    {
      title: '文件大小',
      dataIndex: 'fileSize',
      textWrap: 'word-break',
      hideInSearch: true,
      // hideInTable: true,
    },
    {
      title: '状态',
      dataIndex: 'status',
      // hideInTable: true,
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              statusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{statusList.find(item => item.value === _) ? statusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '是否使用',
      dataIndex: 'used',
      hideInTable: true,
      initialValue: '0',
      valueEnum: {
        0: { text: '全部' },
        1: { text: '是' },
        2: { text: '否' },
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTimeStr',
      textWrap: 'word-break',
      // hideInTable: true,
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      hideInTable: true,
      render: (_, record) => (
        <>
          <Button
            type='link'
            size='small'
            onClick={() => {
              setDetailModalVisible(true);
              setStepFormValues(record);
            }}
          >
            查看
          </Button>
          {
            record.status === 3 ? (
              <>
                <Divider type="vertical" />
                <Button
                  type='link'
                  size='small'
                  disabled={record.used}
                  onClick={
                    () => {
                      Modal.confirm({
                        title: '操作提示',
                        icon: <QuestionCircleOutlined />,
                        content: '是否确定删除选定的条目及所有相关数据？删除后内容将不可恢复。',
                        onOk: () => handleRemove([record])
                      })
                    }
                  }
                >
                  删除
                </Button>
              </>
            ) : null
          }
        </>
      ),
    },
  ];
  const renderContent = (
    <div>
      <Card>
        <ProTable
          className={'media-table'}
          headerTitle=""
          actionRef={actionRef}
          rowKey="fileId"
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      setPageNum(1);
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    id={'resetBtn'}
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      setPageNum(1);
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          rowSelection={false}
          options={false}
          tableAlertRender={false}
          headerTitle={list.data?.length > 0 ? [
            <Button
              className='ml-10 default-btn'
              key='checkall'
              onClick={() => {
                if (checkAllBtnTxt === '全选') {
                  const arr = list.data.filter((item) => (item.status === 3 || (item.status === 2 && !item.used)))
                  setSelectedItems(arr.map((item) => (item.fileId)));
                  if (arr.length > 0) {
                    setCheckAllBtnTxt('取消全选');
                  }else {
                    message.warn('没有可操作的对象！');
                  }
                }else {
                  setSelectedItems([]);
                  setCheckAllBtnTxt('全选');
                }
              }}
              style={{
                width: 88
              }}
            >
              {checkAllBtnTxt}
            </Button>,
            <Button
              className='ml-10'
              key='del'
              onClick={() => {
                if (selectedItems.length > 0) {
                  Modal.confirm({
                    title: '操作提示',
                    icon: <QuestionCircleOutlined />,
                    content: '是否确定删除选定的条目及所有相关数据？删除后内容将不可恢复。',
                    okText: '确定',
                    cancelText: '取消',
                    onOk: () => handleRemove(selectedItems)
                  })
                }else {
                  Modal.warning({
                    title: '操作提示',
                    content: '没有可操作的对象，请先在列表中勾选需要操作的对象后再进行操作',
                    okText: '确定'
                  });
                }
              }}
            >
              批量删除
          </Button>
          ]: false}
          toolBarRender={isUploadBtn ? (action, { selectedRows }) => [
            <Button
              icon={<PlusOutlined />}
              key='primary'
              type="primary"
              className='mr-10'
              onClick={() => {
                if (verifyStatus !== 1) {
                  Modal.warning({
                    title: '提示',
                    content: '您还未完成信息认证！',
                  });
                } else {
                  handleUploadModalVisible(true);
                }
              }}
            >
              上传文件
            </Button>
          ] : false}
          request={
            params => {
              params.fileType = params.fileType === '0' ? '' : params.fileType;
              params.usedFlag = params.used;
              params.startTime = params.createTimeStr && params.createTimeStr.length ? params.createTimeStr[0] : '';
              params.endTime = params.createTimeStr && params.createTimeStr.length ? params.createTimeStr[1] : '';
              params.pageNum = pageNum;
              delete params.used;
              delete params.current;
              delete params.createTimeStr;
              const data = modalParams ? queryModalRule({ ...params, ...modalParams }) : queryRule(params);
              data.then((res) => {
                setList(res);
                setCheckAllBtnTxt('全选');
                setSelectedItems([]);
              })
              return data;
            }
          }
          columns={columns}
        />
        {
          list.data?.length > 0 ? <React.Fragment>
            <CardList
              handleSelect={(id, isAdd) => {
                if (isAdd) {
                  setSelectedItems([...selectedItems, id]);
                } else {
                  const arr = _.pull(selectedItems, id);
                  setSelectedItems([...arr]);
                }
                setCheckAllBtnTxt('全选');
              }}
              data={list.data || []}
              selectedItems={selectedItems}
              handleDetail={(data) => {
                setDetailModalVisible(true);
                setStepFormValues(data);
              }}
              handleDelete={
                (selectedItem) => {
                  Modal.confirm({
                    title: '操作提示',
                    icon: <QuestionCircleOutlined />,
                    content: '是否确定删除选定的条目及所有相关数据？删除后内容将不可恢复。',
                    onOk: () => {
                      handleRemove(selectedItem)
                    }
                  })
                }
              }
            />
            <Pagination
              className='pull-right mr-20'
              defaultCurrent={1}
              current={pageNum}
              pageSize={20}
              total={list?.total || 0}
              showTotal={(total) => {
                return `共 ${total} 条`;
              }}
              onChange={(pageN) => {
                setPageNum(pageN);
                if (actionRef.current) {
                  actionRef.current.reload();
                }
              }}
            />
          </React.Fragment> : <Empty />
        }

      </Card>

      <UploadForm
        onSubmit={async value => {
          const success = await uploadAdd(value);

          if (success) {
            handleUploadModalVisible(false);

            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
        onCancel={() => {
          handleUploadModalVisible(false)
          if (actionRef.current) {
            actionRef.current.reload();
          }
        }}
        modalVisible={uploadModalVisible}
        appList={appSelectList}
      />
      {stepFormValues && Object.keys(stepFormValues).length ? (
        <DetailForm
          onCancel={() => {
            setDetailModalVisible(false);
            setStepFormValues({});
          }}
          modalVisible={detailModalVisible}
          values={stepFormValues}
          isUseBtn={isUseBtn}
          onOkBtn={onOkBtn}
        />
      ) : null}
      <CreateForm
        onSubmit={async value => {
          const success = await handleAdd(value);

          if (success) {
            handleModalVisible(false);

            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
        onCancel={() => handleModalVisible(false)}
        modalVisible={createModalVisible}
      />
      {stepFormValues && Object.keys(stepFormValues).length ? (
        <UpdateForm
          onSubmit={async value => {
            const success = await handleUpdate(value);

            if (success) {
              handleModalVisible(false);
              setStepFormValues({});

              if (actionRef.current) {
                actionRef.current.reload();
              }
            }
          }}
          onCancel={() => {
            handleUpdateModalVisible(false);

            setStepFormValues({});
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }}
          updateModalVisible={updateModalVisible}
          values={stepFormValues}
        />
      ) : null}
    </div>
  )
  useEffect(() => {
    if (dispatch && !appLoading) {
      dispatch({
        type: 'appAndTableList/queryAppSelectRule'
      })
    }
  }, [])

  return (
    <>
      {
        isHeader ? (
          <PageHeaderWrapper>
            {renderContent}
          </PageHeaderWrapper>
        ) : renderContent
      }
    </>
  );
};

export default connect(({ appAndTableList, mediaAndTableList, loading, user }) => ({
  appSelectList: appAndTableList.appSelectList,
  mediaAndTableList,
  appLoading: loading.effects['appAndTableList/queryAppSelectRule'],
  currentUser: user.currentUser,
}))(TableList);

import { queryRule, queryChatbotTypes } from './service';

const Model = {
  namespace: 'mediaAndTableList',
  state: {
    list:[],
    appSelectList:[],
    searchParam:null,
  },
  effects: {
    *queryList(_, { call, put }) {
      const response = yield call();
      yield put({
        type: 'setList',
        payload: response,
      });
    }
  },
  reducers: {
    setList(state, { payload }) {
      return { ...state, list:payload.data };
    },
    setParam(state, { payload }) {
      return { ...state, searchParam: payload };
    }
  },
};
export default Model;

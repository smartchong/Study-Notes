import request from '@/utils/request';
import API from '@/services/api';

export async function queryRule(params) {
  return request(API.MEDIA.TABLE_LIST,{
    method: 'POST',
    data: params,
  });
}
export async function queryModalRule(params) {
  return request(API.MEDIA.TABLE_TYPE_LIST,{
    params,
  });
}
export async function removeRule(params) {
  return request(API.MEDIA.BATCHREMOVE, {
    method: 'POST',
    data: params,
  });
}
export async function reload(params) {
  return request(API.MEDIA.RELOAD, {
    method: 'POST',
    data: { ...params, method: 'post' },
  });
}
export async function addRule(params) {
  return request('/api/media', {
    method: 'POST',
    data: { ...params, method: 'post' },
  });
}
export async function updateRule(params) {
  return request('/api/media', {
    method: 'POST',
    data: { ...params, method: 'update' },
  });
}

export async function queryAppSelectList() {
  return request(API.APP.TABLE_SELECT_LIST);
}

export async function queryChatbotTypes() {
  return request(`${API.DEVELOPERMANAGE.DEVELOPERAUDIT.CHATBOTTYPES}`);
}


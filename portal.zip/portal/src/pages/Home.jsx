import React, { useRef } from 'react';
import { Layout, Carousel, Button, Card, Row, Col, Typography, Modal } from 'antd';
import { LeftOutlined, RightOutlined } from '@ant-design/icons';
import { connect } from 'umi';
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
import styles from './Home.less';
const { Meta } = Card;
const { Title } = Typography;
import banner1 from '../assets/home/bj_1.jpg';
import banner2 from '../assets/home/banner.png';
import bannericon1 from '../assets/home/bannericon2.png';
import bannericon2 from '../assets/home/bannericon3.png';
import bannericon3 from '../assets/home/bannericon1.png';
import bannericon4 from '../assets/home/bannericon4.png';
import trait1 from '../assets/home/trait1.png';
import trait2 from '../assets/home/trait2.png';
import trait3 from '../assets/home/trait3.png';
import trait4 from '../assets/home/trait4.png';
import trait1s from '../assets/home/trait1s.png';
import trait2s from '../assets/home/trait2s.png';
import trait3s from '../assets/home/trait3s.png';
import trait4s from '../assets/home/trait4s.png';
import out1 from '../assets/home/out1.png';
import out2 from '../assets/home/out2.png';
import out3 from '../assets/home/out3.png';
import out4 from '../assets/home/out4.png';
import app1 from '../assets/home/app1.png';
import app1s from '../assets/home/app1s.png';
import app2 from '../assets/home/app2.png';
import app2s from '../assets/home/app2s.png';
import app2ss from '../assets/home/app2ss.png';
import app3 from '../assets/home/app3s.png';
import app4 from '../assets/home/app4.png';
const imgList = [
  {
    img: banner1,
  },
  {
    img: banner2,
    big: '5G消息：开启企业服务新入口',
    small: '5G消息，基于全球移动通信协会RCS和UP标准构建，实现消息的多媒',
    smalls: '体化、轻量化、交互化。',
    small1: '5G消息以聊天机器人Chatbot的形态，使用户在消息窗口内就能完成',
    small2: '服务搜索、咨询、发现、交互、支付等一站式业务体验，形成服务场',
    small3: '景闭环，构建了全新的信息服务新入口。',
    img1: bannericon1,
    img2: bannericon2,
    img3: bannericon3,
    img4: bannericon4,
    p1: '新营销',
    p2: '新交互',
    p3: '新服务',
    p4: '新生态',
  },
];
const imgLists = [
  {
    img1: app1,
    img2: app1s,
    p: '商务社交',
    l1: '名片制作',
    l2: '成员导入',
    l3: '名片发送',
    l4: '商机转化',
    p1: '借助5G消息的富媒体、原生应用、信息可扩展(支持跳转H5)等',
    p2: ' 优势，可搭建智能云名片定制、发送、管理综合服务平台，服务于',
    p3: '家庭办公及中小微企业办公、商务拓展等场景，提升商机转化、企',
    p4: '业宣传效率，沉淀商机数据。',
    button: '即刻体验',
  },
  {
    img: app2,
    img1: app2s,
    img2: app2ss,
    p: '旅游出行',
    l1: '机票预订',
    l2: '门票预订',
    l3: '酒店预订',
    l4: '旅游攻略',
    p1: '通过5G消息的智能会话与服务扩展，为用户提供航班/列车动态信',
    p2: '息、票务/酒店预订、专车接送、旅游出行攻略内容等在内的一站式',
    p3: '出行服务，用户可通过文本、语音等多种形式在5G消息应用内实现',
    p4: '实现订购、支付、出单、使用等的全流程。',
  },
  {
    img1: app3,
    p: '餐饮消费',
    l1: '座位预订',
    l2: '排号提醒',
    l3: '在线点餐',
    l4: '订单支付',
    p1: '可为餐饮行业提供集“预订、排队、点菜、服务、支付”等功能于一',
    p2: '体的解决方案，带给用户全新的用餐体验，降低人力、物力及其它',
    p3: '资源投入，提升餐厅的经营效率。',
  },
  {
    img1: app4,
    p: '金融理财',
    l1: '账单推送',
    l2: '产品推荐',
    l3: '常见问题',
    l4: '售后服务',
    p1: '覆盖银行/基金公司/保险公司等的动账提醒、资讯传递、产品推',
    p2: '荐、售后服务等业务场景，一键启动业务办理直达通道，可快速、',
    p3: '地帮助客户完成各类业务办理。',
  },
];
const Home = (props) => {
  const { history } = props;
  const goToPage = (href) => {
    history.push({
      pathname: href,
      state: {},
    });
  };
  const ref = useRef();
  const res = useRef();
  return (
    <Layout className={styles.home}>
      <BasicHeader />
      <div className={styles.carousel}>
        <Carousel ref={ref}>
          {imgList &&
            imgList.map((item, index) => (
              <div key={index} style={{ position: 'relative' }}>
                <div style={{ position: 'relative' }} className="banner-title">
                  <img src={item.img} alt="" className="img" />
                  <div className="div1">{item.big}</div>
                  <div className="div2">{item.small}</div>
                  <div className="div3">{item.smalls}</div>
                  <div className="div4">{item.small1}</div>
                  <div className="div5">{item.small2}</div>
                  <div className="div6">{item.small3}</div>
                  <img src={item.img1} alt="" className="img1_banner" />
                  <img src={item.img2} alt="" className="img2_banner" />
                  <img src={item.img3} alt="" className="img3_banner" />
                  <img src={item.img4} alt="" className="img4_banner" />
                  <p className="p1">{item.p1}</p>
                  <p className="p2">{item.p2}</p>
                  <p className="p3">{item.p3}</p>
                  <p className="p4">{item.p4}</p>
                </div>
              </div>
            ))}
        </Carousel>
        <span className="icon-btn" onClick={(e) => ref.current.prev()}>
          <LeftOutlined />
        </span>
        <span className="icon-btn" onClick={() => ref.current.next()}>
          <RightOutlined />
        </span>
      </div>
      <div className={styles.trait} style={{ background: 'white' }}>
        <h3>产品特点</h3>
        <p className="trait_q">PRODUCT FEATURES</p>
        <ul className="uls">
          <li>
            <img src={trait1} alt="" className="uls_img" />
            <img src={trait1s} alt="" className="uls_img1" />
            <p className="uls_p">强入口</p>
            <p className="uis_p1">免安装</p>
            <p className="uis_p1">轻量化</p>
            <p className="uis_p1">消息直达</p>
          </li>
          <li>
            <img src={trait2} alt="" className="uls_img" />
            <img src={trait2s} alt="" className="uls_img1" />
            <p className="uls_p">一站式</p>
            <p className="uis_p1">低门槛</p>
            <p className="uis_p1">场景化</p>
            <p className="uis_p1">服务直达</p>
          </li>
          <li>
            <img src={trait3} alt="" className="uls_img" />
            <img src={trait3s} alt="" className="uls_img1" />
            <p className="uls_p">智能化</p>
            <p className="uis_p1">聊天室交互</p>
            <p className="uis_p1">意图识别</p>
            <p className="uis_p1">精准服务匹配</p>
          </li>
          <li>
            <img src={trait4} alt="" className="uls_img" />
            <img src={trait4s} alt="" className="uls_img1" />
            <p className="uls_p">品牌赋能</p>
            <p className="uis_p1">实名认证</p>
            <p className="uis_p1">品牌宣传</p>
            <p className="uis_p1">私域流量</p>
          </li>
        </ul>
      </div>

      <Layout className={styles.content}>
        <div className="w1280 cp">
          <h3>产品功能</h3>
          <Title level={4}>PRODUCT FUNCTION</Title>
          <Row gutter={20}>
            <Col span={12}>
              <Card
                hoverable
                cover={
                  <div>
                    <img alt="example" src={require('../assets/home/title1.png')} />
                  </div>
                }
              >
                <Meta
                  title="富媒体消息下发"
                  description="支持将文本、图片、音频、视频、卡片、文件、位置、红包、卡券等多种富媒体消息推送至用户终端。"
                />
              </Card>
            </Col>
            <Col span={12}>
              <Card
                hoverable
                cover={
                  <div>
                    <img alt="example" src={require('../assets/home/title2.png')} />
                  </div>
                }
              >
                <Meta
                  title="卡片样式灵活定义"
                  description="卡片样式直观、重点突出，支持自定义单卡片或多卡片、卡片按钮及底部悬浮菜单，卡片内容支持高清图片、音频、视频。"
                />
              </Card>
            </Col>
            <Col span={12}>
              <Card
                hoverable
                cover={
                  <div>
                    <img alt="example" src={require('../assets/home/title3.png')} />
                  </div>
                }
              >
                <Meta
                  title="服务延伸及扩展"
                  description="支持通过消息中的按钮及菜单，跳转至关联的快应用、H5页面、APP页面等完成业务查询与办理，同时也支持拨打客服电话、查看地图、查看日历等。"
                />
              </Card>
            </Col>
            <Col span={12}>
              <Card
                hoverable
                cover={
                  <div>
                    <img alt="example" src={require('../assets/home/title4.png')} />
                  </div>
                }
              >
                <Meta
                  title="智能会话交互"
                  description="智能交互问答：支持文字或者语音输入，降低用户使用门槛；精准意图识别：基于Al深度学习，chatbot机器人能够有效理解用户的意图和信息，智能推荐相关服务。"
                />
              </Card>
            </Col>
          </Row>
        </div>
        <div className={styles.scene}>
          <h3>应用场景</h3>
          <p className="scene_p">APPLICATION SCENARIOS</p>
          <Carousel ref={res} >
            {imgLists &&
              imgLists.map((item, index) => (
                <div key={index} style={{ position: 'relative' }}>
                  <div style={{ position: 'relative' }} className="scene_div">
                    <img src={item.img} alt="" className="scene_img1" />
                    <img src={item.img1} alt="" className="scene_img2" style={{ width: 196, height: 430 }} />
                    <img src={item.img2} alt="" className="imgs3" style={{ height: 430 }} />
                    <div className="scene_divs">
                      <p className="scenes_p">{item.p}</p>
                      <ul>
                        <li>{item.l1}</li>
                        <li>{item.l2}</li>
                        <li>{item.l3}</li>
                        <li>{item.l4}</li>
                      </ul>
                      <p className="scenes_p1">{item.p1}</p>
                      <p className="scenes_p1">{item.p2}</p>
                      <p className="scenes_p1">{item.p3}</p>
                      <p className="scenes_p1">{item.p4}</p>
                      <Button
                        type="primary"
                        onClick={() => {
                          const { currentUser } = props;
                          if (currentUser?.name) {
                            if (currentUser.verifyStatus === 1) {
                              goToPage('/cloudCard/vCard/my');
                            } else {
                              Modal.warning({
                                title: '提示',
                                content: '您还未完成认证信息审核，请先完成再使用该场景服务。',
                                okText: '确定',
                                onOk: () => {
                                  goToPage('/layouts/userCenter/authInfo');
                                },
                              });
                            }
                          } else {
                            history.push({
                              pathname: '/user/login',
                              state: {
                                to: 'cloudCard',
                              },
                            });
                          }
                        }}
                        className="scenes_button"
                      >
                        {item.button}
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
          </Carousel>
          <span className="icon-btn1" onClick={(e) => res.current.prev()}>
            <LeftOutlined />
          </span>
          <span className="icon-btn2" onClick={() => res.current.next()}>
            <RightOutlined />
          </span>
        </div>
        <div className={styles.advantage}>
          <h3>我们的优势</h3>
          <p className="advantage_p">OUR STRENGTHS</p>
          <ul className="advantage_ul">
            <li>
              <img src={out1} alt="" />
              <div>接入方便</div>
              <p>. 接入零难度，可快速创建chatbot</p>
              <p>. 操作便捷，配置模板可视化</p>
              <p>. 支持API调用</p>
            </li>
            <li>
              <img src={out2} alt="" />
              <div>覆盖全面</div>
              <p>. 支持5G消息回落为短信小程序或H5chatbot，让非5G手机也能体验5G消息和聊天机器人的全部特性和功能</p>
            </li>
            <li>
              <img src={out3} alt="" style={{ width: 302, height: 200 }} />
              <div>稳定性高</div>
              <p>. 自研监控系统，自动分流</p>
              <p>. 分布式部署，稳如磐石</p>
              <p>. 业内领先的技术保障</p>
            </li>
            <li>
              <img src={out4} alt="" />
              <div>专业服务</div>
              <p>. 7X24小时服务</p>
              <p>. 1分钟完成注册认证</p>
              <p>. 1分钟完成认证审核</p>
              <p>. VIP 客户 1v1 专属服务</p>
            </li>
          </ul>
        </div>
      </Layout>
      <Layout.Footer className={styles.footer}>
        <Row>
          <Col span={8}>
            <span className="icon_tel"></span>联系我们：188********
          </Col>
          <Col span={8}>
            <span className="icon_email"></span>邮箱：zhongyinengkai@cmhi.chinamobile.com
          </Col>
          <Col span={8}>
            <span className="icon_gp"></span>地址：浙江省杭州市余杭区余杭塘路1600号
          </Col>
        </Row>
        <div className="copyright">
          版权所有 © 中移（杭州）信息技术有限公司 | 备案号：浙ICP备14035550号-1
        </div>
      </Layout.Footer>
    </Layout>
  );
};

export default connect(({ user }) => ({
  currentUser: user.currentUser,
}))(Home);

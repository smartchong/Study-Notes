import React, { useState,useEffect,useRef } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import { connect,history } from 'umi';
import { queryList,saveGroup,removeRule } from './service';
import styles from './style.less';
import { Button, message, notification, Card, Modal, Radio, Select } from 'antd';
import ControledRangePicker from './components/RangePicker';
import ControledInput from './components/Input';
import HandAddForm from './components/HandAddForm';
import BatchImportForm from './components/BatchImportForm';
import { DownOutlined, PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';

const Index = props => {
  const actionRef = useRef();
  const { dispatch, recipient, loading } = props;
  const [selectedRow,handleSelectedRow] = useState([]);
  const [handAddModal,handleHandAddModal] = useState(false);
  const [batchImportModal,handleBatchImportModal] = useState(false);
  const [selectedRowKeys,handleSelectedRowKeys] = useState([]);
  const columns = [
    {
      title: '所属群组',
      dataIndex: 'groupName',
      hideInTable: true,
      renderFormItem: (_, { onChange, type, defaultRender,...rest }, form) => {
        return (
          <ControledInput
            maxLength={20}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入所属群组"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '收信人手机号码',
      dataIndex: 'mobile',
      renderFormItem: (_, { onChange, type, defaultRender,...rest }, form) => {
        return (
          <ControledInput
            maxLength={11}
            regex={/[^\d]/g}
            placeholder="请输入收信人手机号码"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属群组',
      dataIndex: 'groupName',
      textWrap: 'word-break',
      hideInSearch: true,
    },
    {
      title: '添加时间',
      dataIndex: 'createTime',
      renderFormItem: (_, { type, defaultRender,...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
          <a onClick={()=>{
              Modal.confirm({
                title: '是否确定删除:',
                icon: <QuestionCircleOutlined />,
                content: '选定的收信人？删除后内容将不可恢复。',
                onOk:()=>handleRemove([record])
              })
            }}>删除</a>
        </>
      ),
    },
  ];

  /**
   *  删除节点
   * @param selectedRows
   */
  const handleRemove = async selectedRows => {
    const hide = message.loading('正在删除');
    if (!selectedRows) return true;

    try {
      const ret = await removeRule({
        ids: selectedRows.map(row => row.id),
      });
      hide();
      if(ret && ret.success){
        message.success('删除成功');

        if (dispatch && !loading) {
          dispatch({
            type:'recipient/queryRecipientGroupRule',
          })
        }

        if (actionRef.current) {
          actionRef.current.reload();
        }
        return true;
      }else {
        return false;
      }
    } catch (error) {
      hide();
      message.error('删除失败，请重试');
      return false;
    }
  };

  useEffect(() => {
    if (dispatch && !loading) {
      dispatch({
        type:'recipient/queryRecipientGroupRule',
      })
    }
  },[]);
  const { recipientGroupList } = recipient;

  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <ProTable
          actionRef={actionRef}
          columns={columns}
          rowKey="id"
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          rowSelection={{
            selectedRowKeys,
            onChange: (selectedRowKeys,selectedRow) => {
              handleSelectedRow(selectedRow);
              handleSelectedRowKeys(selectedRowKeys);
            },
          }}
          options={false}
          request={
            (params, sorter, filter) => {
              params.startTime = params.createTime && params.createTime.length ? params.createTime[0] : '';
              params.endTime = params.createTime && params.createTime.length ? params.createTime[1] : '';
              params.pageNum = params.current;
              delete params.current;
              delete params.createTime;
              return queryList(params);
            }
          }
          tableAlertRender={({selectedRowKeys}) => (<div>已选中{selectedRowKeys.length}条</div>)}
          toolBarRender={(action, { selectedRows }) => [
            <Button
              type="primary"
              style={{
                position: 'absolute',
                left: 24,
                top: 16,
              }}
              onClick={() => {
                if (selectedRowKeys.length) {
                  Modal.confirm({
                    title: '是否确定删除:',
                    icon: <QuestionCircleOutlined />,
                    content: '选定的收信人？删除后内容将不可恢复。',
                    onOk:()=>handleRemove(selectedRows)
                  })

                } else {
                  Modal.warning({
                    title: '操作提示',
                    content: '没有可操作的对象，请先在列表中勾选需要操作的对象后再进行操作。',
                  });
                }
              }}
            >
              批量删除
            </Button>,
            <Button
              type="primary"
              onClick={() => {
                handleHandAddModal(true)
              }}
            >
              手动添加
            </Button>,
            <Button
              type="primary"
              onClick={() => {
                handleBatchImportModal(true)
              }}
            >
              批量导入
            </Button>,
          ]}
        />
      </Card>
      {/* 手动添加 */}
      <HandAddForm
        recipientGroupList={recipientGroupList}
        onSubmit={async (value,callBack) => {
           console.log(value);
          console.log(value.mobiles);
          value.mobiles = value.mobiles.split(';').filter(val => val !== '');
          const response = await saveGroup(value);
          console.log(response)
          if (response.success) {
            message.success("添加成功！");
            callBack && callBack();
            handleHandAddModal(false);
            if (actionRef.current) {
              actionRef.current.reload();
            }
            if (dispatch && !loading) {
              dispatch({
                type:'recipient/queryRecipientGroupRule',
              })
            }
          } else {
            notification.error({
              message: response.message || '操作失败',
            });
          }
        }}
        onCancel={() => handleHandAddModal(false)}
        modalVisible={handAddModal}
      />
      {/* 批量导入 */}
      <BatchImportForm
        recipientGroupList={recipientGroupList}
        onCancel={() => {
          handleBatchImportModal(false);
          if (actionRef.current) {
            actionRef.current.reload();
          }
        }}
        onSuccess={() => {
          handleBatchImportModal(false);
          if (actionRef.current) {
            actionRef.current.reload();
          }
          if (dispatch && !loading) {
            dispatch({
              type:'recipient/queryRecipientGroupRule',
            })
          }
        }}
        modalVisible={batchImportModal}
      />
    </PageHeaderWrapper>
  )
}

export default connect(({ recipient, loading }) => ({
  recipient,
  loading: loading.effects['recipient/queryList'],
}))(Index);

import { queryList,queryGroupList } from './service';
import { notification } from 'antd';

const Model = {
  namespace: 'recipient',
  state: {
    tableData:{},
    recipientGroupList:[],
  },
  effects: {
    *queryList({ payload }, { call, put }) {
      const response = yield call(queryList, payload);
      yield put({
        type: 'setList',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
    *queryRecipientGroupRule({ payload }, { call, put }) {
      const response = yield call(queryGroupList, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      } else {
        yield put({
          type: 'setRecipientGroupList',
          payload: response,
        });
      }
    }
  },
  reducers: {
    setList(state, { payload }) {
      return { ...state,tableData: payload };
    },
    setRecipientGroupList(state, { payload }) {
      return { ...state,recipientGroupList: payload.data };
    },
  },
};
export default Model;

import { queryList,saveGroup} from './service';
import { notification } from 'antd';

const Model = {
  namespace: 'blacklist',
  state: {
    tableData:{},
    recipientGroupList:[],
  },
  effects: {
    *queryList({ payload }, { call, put }) {
      const response = yield call(queryList, payload);
      yield put({
        type: 'setList',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
  },
  reducers: {
    setList(state, { payload }) {
      return { ...state,tableData: payload };
    },
  },
};
export default Model;

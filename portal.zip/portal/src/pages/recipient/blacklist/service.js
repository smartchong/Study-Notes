import request from '@/utils/request';
import API from '@/services/api';

// 列表查询
export async function queryList(params) {
  return request(`${API.BLACKLIST.QUERY_LIST}`, {
    method: 'POST',
    data: params,
  });
}

// 保存群组
export async function saveGroup(params) {
  return request(`${API.BLACKLIST.ADD}`, {
    method: 'POST',
    data: params,
  });
}

// 开始导入
export async function startUpload(params) {
  return request(`${API.BLACKLIST.IMPORT}`, {
    method: 'POST',
    data: params,
  });
}
// export async function checkGroupName(params) {
//   return request(`${API.BLACKLIST.IMPORT}`,{
//     params
//   })
// }
//删除
export async function removeRule(params) {
  return request(`${API.BLACKLIST.DEL}`, {
    method: 'POST',
    data: params,
  });
}

//下载
// export async function download() {
//   return request(`${API.RECIPIENT.DOWNLOAD}`, {
//     method: 'GET',
//   });
// }


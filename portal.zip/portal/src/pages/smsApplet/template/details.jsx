import React, { useState,useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Card, Row, Col } from 'antd';
import PreviewModal from './components/PreviewModal';
import { connect,useParams,history } from "umi";
import styles from './style.less';
const templateTypeList = [
  { label:'短信小程序',value:1 },
  { label:'H5 Chatbot',value:2 },
];

const Details = props => {

  const { dispatch,smsAppletTemplate,loading } = props;
  const [ modal,handleModal ] = useState(false);
  const params = useParams();
  const { detailsData } = smsAppletTemplate;
  const statusList = [
    {
      label:'待审核',
      value:3,
    },
    {
      label:'审核通过',
      value:1,
    },
    {
      label:'审核不通过',
      value:2,
    },
  ];

  useEffect(() => {
    if(dispatch && !loading){
      dispatch({
        type:'smsAppletTemplate/queryDetails',
        payload:{
          id:Number(params.id)
        },
        callback:() => {},
      })
    }
  },[]);

  if (!detailsData || detailsData.id !== Number(params.id)) {
    return null;
  }
  return (
    <PageHeaderWrapper
      title={"模板详情"}
      content={
        <Button
          style={{float:'right'}}
          onClick={() => history.go(-1)}
        >
          返回
        </Button>
      }
    >
      <Card>
        <Row gutter={[24,24]}>
          <Col span={8}>
            <span>模板ID：</span>
            <span className={styles.text}>{detailsData.id}</span>
          </Col>
          <Col span={8}>
            <span>模板名称：</span>
            <span className={styles.text}>{detailsData.templateName}</span>
          </Col>
          <Col span={8}>
            <span>模板状态：</span>
            <span className={styles.text}>
              {
                statusList.find(item => item.value === detailsData.status) ?
                  statusList.find(item => item.value === detailsData.status).label :
                  ''
              }
            </span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={8}>
            <span>短信签名：</span>
            <span className={styles.text}>{detailsData.smsSign}</span>
          </Col>
          <Col span={8}>
            <span>所属应用：</span>
            <span className={styles.text}>{detailsData.appName}</span>
          </Col>
          <Col span={8}>
            <span>模板类型：</span>
            <span className={styles.text}>
              {
                templateTypeList.find(item => item.value === detailsData.templateType) ?
                  templateTypeList.find(item => item.value === detailsData.templateType).label :
                    ''
              }
            </span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={8}>
            <span>提交时间：</span>
            <span className={styles.text}>{detailsData.createTime}</span>
          </Col>
          <Col span={8}>
            <span>审核时间：</span>
            <span className={styles.text}>{detailsData.auditTime}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={24}>
            <span>模板内容：</span>
            <span className={styles.text}>{detailsData.templateContent}</span>
          </Col>
        </Row>
        {
          detailsData.templateType === 1 ? (
            <Row gutter={[24,24]}>
              <Col span={24}>
                <span>短信链接：</span>
                <span className={styles.text}>{detailsData.smsLink}</span>
                <Button
                  style={{marginLeft:20}}
                  onClick={() => handleModal(true)}
                >
                  预览
                </Button>
              </Col>
            </Row>
          ) : null
        }
        <Row gutter={[24,24]}>
          <Col span={24}>
            <span>备注说明：</span>
            <span className={styles.text}>{detailsData.remarks}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={24}>
            <span>审核意见：</span>
            <span className={styles.text}>{detailsData.auditOpinion}</span>
          </Col>
        </Row>
      </Card>
      <PreviewModal
        onCancel={() => handleModal(false)}
        modalVisible={modal}
      >
        <div className={styles.iframeWrap}>
          <iframe
            className={styles.iframe}
            src={detailsData.sourceLink}
            frameBorder="0"
            scrolling="no"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
          />
        </div>
      </PreviewModal>
    </PageHeaderWrapper>
  )
}

export default connect(({ smsAppletTemplate,loading }) => ({
  smsAppletTemplate,
  loading: loading.effects['smsAppletTemplate/queryDetails'],
}))(Details);

import request from '@/utils/request';
import API from '../../../services/api';

// 列表查询
export async function queryList(params) {
  return request(`${API.SMSAPPLET.TEMPLATE.LIST}`, {
    method: 'POST',
    data: params,
  });
}

// 创建模板
export async function addList(params) {
  return request(`${API.SMSAPPLET.TEMPLATE.ADD}`, {
    method: 'POST',
    data: params,
  });
}

// 删除模板
export async function deleteList(params) {
  return request(`${API.SMSAPPLET.TEMPLATE.DELETE}`, {
    params,
  });
}

// 更新模板
export async function updateList(params) {
  return request(`${API.SMSAPPLET.TEMPLATE.UPDATE}`, {
    method: 'POST',
    data: params,
  });
}

// 模板详情
export async function queryDetails(params) {
  return request(`${API.SMSAPPLET.TEMPLATE.DETAILS}`, {
    params,
  });
}

// 模板唯一性校验
export async function queryUnique(params) {
  return request(`${API.SMSAPPLET.TEMPLATE.AUTH}`, {
    method: 'POST',
    data: params,
  });
}

// 获取审核通过的模板
export async function queryPass(params) {
  return request(`${API.SMSAPPLET.SHORTLINK.PASS}`, {
    params,
  });
}

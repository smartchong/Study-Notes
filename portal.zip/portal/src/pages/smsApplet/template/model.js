import { notification } from 'antd';
import { queryList,queryDetails,addList,updateList,deleteList,queryPass } from './service';

const Model = {
  namespace: 'smsAppletTemplate',
  state: {
    tableData:{},
    searchParam:null,
    detailsData:null,
    smsLinkList:[],
  },
  effects: {
    *queryList({ payload }, { call, put }) {
      const response = yield call(queryList, payload);
      yield put({
        type: 'setList',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
    *queryDetails({ payload,callback }, { call, put }) {
      const response = yield call(queryDetails, payload);
      yield put({
        type: 'setDetails',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      } else {
        callback(response.data);
      }
    },
    *addList({ payload }, { call, put }) {
      const response = yield call(addList, payload);
      return response;
    },
    *modifyList({ payload }, { call, put }) {
      const response = yield call(updateList, payload);
      return response;
    },
    *deleteList({ payload }, { call, put }) {
      const response = yield call(deleteList, payload);
      return response;
    },
    *querySmsLinkList({ payload }, { call, put }) {
      const response = yield call(queryPass, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      } else {
        yield put({
          type: 'setSmsLinkList',
          payload: response,
        });
      }
    }
  },
  reducers: {
    setList(state, { payload }) {
      return { ...state,tableData: payload };
    },
    setDetails(state, { payload }) {
      return { ...state, detailsData:payload.data };
    },
    setSmsLinkList(state, { payload }) {
      return { ...state, smsLinkList:payload.data };
    },
    setParam(state, { payload }) {
      return { ...state,searchParam: payload };
    },
  },
};

export default Model;

import React, { useState,useEffect,useRef } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Card, Form, Input, Select, Radio, Row, Col, Space, message, notification } from 'antd';
import { connect,useParams,history } from "umi";
import { queryUnique } from './service';
import Preview from './components/Preview';
import styles from './style.less';
const { TextArea } = Input;
const { Option } = Select;
const templateTypeList = [
  { label:'短信小程序',value:1 },
  { label:'H5 Chatbot',value:2 },
];

const Modify = props => {

  const {
    dispatch,
    loading,
    appLoading,
    smsLoading,
    smsAppletTemplate,
    appAndTableList,
  } = props;
  const params = useParams();
  const [form] = Form.useForm();
  const mouseRef = useRef(null);
  const [msg,handleMsg] = useState('');
  const [shortLink,handleShortLink] = useState('');
  const [disable,handleDisable] = useState(true);
  const { appSelectList } = appAndTableList;
  const { smsLinkList,detailsData } = smsAppletTemplate;
  useEffect(() => {
    if (dispatch) {
      dispatch({
        type:'smsAppletTemplate/queryDetails',
        payload:{
          id:Number(params.id)
        },
        callback:(response)=>{
          if (dispatch && !smsLoading) {
            dispatch({
              type:'smsAppletTemplate/querySmsLinkList',
              payload:{
                appId:response.appId,
              }
            })
          }
          if (dispatch && !appLoading) {
            dispatch({
              type:'appAndTableList/queryAppSelectRule',
            })
          }
        },
      })
    }
  },[]);

  useEffect(() => {
    if (detailsData && detailsData.id === Number(params.id)) {
      if (detailsData.templateType === 2) {
        const value = appSelectList.find(_ => _.appId === detailsData.appId).shortLink;
        handleShortLink(value);
        handleMsg(`${detailsData.templateContent}【H5 Chatbot：${value}】`);
      } else {
        handleMsg(`${detailsData.templateContent}`);
      }
    }
  },[appSelectList]);

  const layout = {
    labelCol: {
      span: 4,
    },
    wrapperCol: {
      span: 16,
    },
  };

  const checkRepeat = async(type,value)=>{
    let param = {};
    param['id'] = params.id;
    param[type] = value;
    const ret = await queryUnique(param);
    if(ret && ret.success) {
      return true;
    }else {
      return false;
    }
  }

  const checkName = async (_, value) => {
    const promise = Promise;
    if (value) {
      if(!/^[\S]{1,30}$/.test(value)) {
        return promise.reject('请输入正确的模板名称！');
      } else {
        if (
          await checkRepeat('templateName',value)
        ) {
          return promise.resolve();
        }
        return promise.reject('模板名称已存在，请重新输入！');
      }
    }
  }

  const checkTemplate = async (_, value) => {
    handleMsg(value);
    const promise = Promise;
    if (value) {
      if (
        value.length <= 400 &&
        value.match(/(?<=【短信小程序：).*?(?=】)/g) &&
        value.match(/(?<=【短信小程序：).*?(?=】)/g).length === 1 &&
        /(((http|ftp|https)\:\/\/)?(([a-zA-Z0-9\._-]+\.[a-zA-Z]{2,6})|(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})|([a-fA-F0-9]{1,4}(:[a-fA-F0-9]{1,4}){7}|[a-fA-F0-9]{1,4}(:[a-fA-F0-9]{1,4}){0,7}::[a-fA-F0-9]{0,4}(:[a-fA-F0-9]{1,4}){0,7}))(\:\d{1,6})?){1,300}/.test(value.match(/(?<=【短信小程序：).*?(?=】)/g)[0]) &&
        value.match(/(?<=【短信小程序：).*?(?=】)/g)[0] === form.getFieldsValue().smsLink
      ) {
        if (!disable) {
          handleDisable(true);
        }
        return promise.resolve();
      } else {
        if (disable && !value.match(/(?<=【短信小程序：).*?(?=】)/g)) {
          handleDisable(false);
        }
        return promise.reject('请输入正确的短信内容！');
      }
    } else {
      if (disable) {
        handleDisable(false);
      }
    }
  }

  const insert = () => {
    // 1.获取输入框原来的值
    const values = form.getFieldsValue();
    const prevValue = typeof values.templateContent === 'undefined' ? '' : values.templateContent;
    // 2.获取光标位置
    const position = getPosition(mouseRef.current.resizableTextArea.textArea);
    // 3.设置插入内容
    let placeholder = '';
    if (!values.smsLink) {
      placeholder = `${prevValue.substring(0,position.start)}【短信小程序：{[placeholder:url]}】${prevValue.substring(position.end)}`;
    } else {
      placeholder = `${prevValue.substring(0,position.start)}【短信小程序：${values.smsLink}】${prevValue.substring(position.end)}`;
    }
    // 4.插入并校验
    form.setFieldsValue({
      templateContent:placeholder,
    });
    form.validateFields(["templateContent"]);
    handleDisable(true);
  }

  const getPosition = (ctrl) => {
    let CaretPos = {
      start:0,
      end:0
    };
    if (ctrl.selectionStart) {
      CaretPos.start = ctrl.selectionStart;
    }
    if(ctrl.selectionEnd){
      CaretPos.end = ctrl.selectionEnd
    }
    return (CaretPos);
  }

  const onFinish = values => {
    values.id = Number(params.id);
    values.smsLinkId = smsLinkList.find(item => item.smsLink === values.smsLink) ? smsLinkList.find(item => item.smsLink === values.smsLink).smsLinkId : '';
    dispatch({
      type:'smsAppletTemplate/modifyList',
      payload:{
        ...values
      }
    }).then(response => {
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      } else {
        if (dispatch) {
          dispatch({
            type:'smsAppletTemplate/setDetails',
            payload:{
              data:null
            }
          })
        }
        message.success('模板提交成功！');
        history.go(-1);
      }
    })
  }

  const getTemplateList = (v)=>{
    const templateType = form.getFieldValue('templateType');
    if (templateType === 1) {
      form.setFieldsValue({
        smsLink:undefined
      });
    }
    if (appSelectList && appSelectList.length) {
      const value = appSelectList.find(_ => _.appId === v).shortLink;
      handleShortLink(value);
      if (templateType === 2) {
        const templateContent = `${form.getFieldsValue().templateContent}【H5 Chatbot：${value}】`;
        handleMsg(templateContent);
      }
    }
    if (dispatch && !smsLoading) {
      dispatch({
        type:'smsAppletTemplate/querySmsLinkList',
        payload:{
          appId:v,
        }
      })
    }
  }

  const onTemplateTypeChange = (e) => {
    form.setFieldsValue({
      templateContent:''
    })
    handleMsg('');
  }

  const onTemplateContentChange = (e) => {
    const templateContent = `${form.getFieldsValue().templateContent}【H5 Chatbot：${shortLink}】`;
    handleMsg(templateContent);
  }

  if (!detailsData || detailsData.id !== Number(params.id)) {
    return null;
  }
  return (
    <PageHeaderWrapper
      title={"修改模板"}
    >
      <Card>
        <Row gutter={[24,24]}>
          <Col span={14}>
            <Form
              {...layout}
              form={form}
              name="template"
              onFinish={onFinish}
              hideRequiredMark={true}
              initialValues={
                {
                  appId:detailsData.appId,
                  templateName:detailsData.templateName,
                  smsSign:detailsData.smsSign,
                  templateType:detailsData.templateType,
                  smsLink:detailsData.templateType === 1 ? detailsData.smsLink : undefined,
                  templateContent:detailsData.templateContent,
                  remarks:detailsData.remarks,
                }
              }
            >
              {/* 应用 */}
              {
                appSelectList && appSelectList.length ? (
                  <Form.Item
                    label="应用"
                    name="appId"
                    rules={[
                      {
                        required: true,
                        message: '请选择1个应用！',
                      },
                    ]}
                  >
                    <Select
                      placeholder='请选择'
                      onSelect={(v)=>{
                        getTemplateList(v);
                      }}
                    >
                      {
                        appSelectList && appSelectList.map((item,index)=>(
                          <Select.Option key={item.appId}>{item.appName}</Select.Option>
                        ))
                      }
                    </Select>
                  </Form.Item>
                ) : (
                  <Form.Item
                    label="应用"
                    name="appId"
                    hasFeedback
                    validateStatus="error"
                    help="请先创建应用！"
                  >
                    <Select
                      placeholder='请选择'
                    >
                      {
                        appSelectList && appSelectList.map((item,index)=>(
                          <Select.Option key={item.appId}>{item.appName}</Select.Option>
                        ))
                      }
                    </Select>
                  </Form.Item>
                )
              }
              {/* 模板名称 */}
              <Form.Item
                label={'模板名称'}
                name={'templateName'}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入模板名称！',
                  },
                  {
                    validator: checkName,
                  },
                ]}
              >
                <Input
                  maxLength={30}
                  placeholder={'请输入模板名称，30个字符数以内。'}
                />
              </Form.Item>
              {/* 短信签名 */}
              <Form.Item
                label={'短信签名'}
                name={'smsSign'}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入短信签名！',
                  },
                  {
                    pattern: /^[\S]{1,8}$/,
                    message: '请输入正确的短信签名！',
                  },
                ]}
              >
                <Input
                  maxLength={8}
                  placeholder={'请输入短信签名，8个字符数以内。'}
                />
              </Form.Item>
              {/* 模板类型 */}
              <Form.Item
                label={'模板类型'}
                name={'templateType'}
                rules={[
                  {
                    required: true,
                    message: '请选择模板类型！',
                  },
                ]}
              >
                <Radio.Group onChange={(e) => {
                  onTemplateTypeChange(e);
                }}>
                  {
                    templateTypeList.map(item => (
                      <Radio key={item.value} value={item.value}>{item.label}</Radio>
                    ))
                  }
                </Radio.Group>
              </Form.Item>
              <Form.Item
                noStyle
                shouldUpdate={(prevValue, curValue) => {
                  return prevValue.templateType !== curValue.templateType;
                }}
              >
                {({ getFieldValue }) => {
                  const templateType = getFieldValue('templateType');
                  if (templateType === 1) {
                    {/* 短信链接 */}
                    return (
                      <Form.Item
                        label={'短信链接'}
                        name={'smsLink'}
                        rules={[
                          {
                            required: true,
                            message: '请选择短信链接！',
                          },
                        ]}
                      >
                        <Select placeholder='请选择'>
                          {
                            smsLinkList.map(item => (
                              <Option
                                key={item.smsLinkId}
                                value={item.smsLink}
                              >
                                {item.smsLink}
                              </Option>
                            ))
                          }
                        </Select>
                      </Form.Item>
                    )
                  }
                }}
              </Form.Item>
              {/* 模板内容 */}
              <Form.Item
                noStyle
                shouldUpdate={(prevValue, curValue) => {
                  return prevValue.templateType !== curValue.templateType;
                }}
              >
                {({ getFieldValue }) => {
                  const templateType = getFieldValue('templateType');
                  if (templateType === 1) {
                      return (
                        <Form.Item
                          shouldUpdate={(prevValue, curValue) => prevValue.templateContent !== curValue.templateContent}
                          label={'模板内容'}
                          name={'templateContent'}
                          className={styles.customer}
                          rules={[
                            {
                              required: true,
                              message: '请输入模板内容！',
                            },
                            {
                              validator: checkTemplate,
                            },
                          ]}
                          extra={
                            <div className={styles.extra}>
                              <span>请插入占位符：</span>
                              {
                                <Button
                                  disabled={disable}
                                  onClick={insert}
                                >
                                  链接URL（必填）
                                </Button>
                              }
                            </div>
                          }
                        >
                          <TextArea
                            ref={mouseRef}
                            maxLength={400}
                            rows={4}
                            placeholder={'请输入短信内容，400个字符数以内，短信模板中必须包含URL。'}
                          />
                        </Form.Item>
                      )
                  } else if (templateType === 2) {
                      return (
                        <Form.Item
                          shouldUpdate={(prevValue, curValue) => prevValue.templateContent !== curValue.templateContent}
                          label={'模板内容'}
                          name={'templateContent'}
                          rules={[
                            {
                              required: true,
                              message: '请输入模板内容！',
                            },
                          ]}
                        >
                          <TextArea
                            onChange={(e) => {
                              onTemplateContentChange(e);
                            }}
                            maxLength={400}
                            rows={4}
                            placeholder={'请输入短信内容，400个字符以内；短信下发时会自动在短信末尾填充H5 Chatbot链接信息。'}
                          />
                        </Form.Item>
                      )
                  }
                }}
              </Form.Item>
              {/* 备注说明 */}
              <Form.Item
                label={'备注说明'}
                name={'remarks'}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: false,
                  },
                  {
                    pattern: /^[\S]{0,200}$/,
                    message: '请输入正确的备注信息！',
                  },
                ]}
              >
                  <TextArea
                    maxLength={200}
                    rows={4}
                    placeholder={'请输入备注说明，200个字符以内。'}
                  />
              </Form.Item>
              {/* 操作 */}
              <Form.Item
                wrapperCol={{
                  offset: 4
                }}
              >
                <Space
                  size={'large'}
                >
                  <Button
                    onClick={() => {
                      form.resetFields();
                      history.go(-1);
                    }}
                  >
                    取消
                  </Button>
                  <Button
                    loading={loading}
                    htmlType={'submit'}
                  >
                    提交
                  </Button>
                </Space>
              </Form.Item>
            </Form>
          </Col>
          <Col span={10}>
            <Preview 
              msg={msg}
            />
          </Col>
        </Row>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ appAndTableList,smsAppletTemplate,loading }) => ({
  appAndTableList,
  smsAppletTemplate,
  loading: loading.effects['smsAppletTemplate/modifyList'],
  appLoading: loading.effects['appAndTableList/queryAppSelectRule'],
  smsLoading: loading.effects['smsAppletTemplate/querySmsLinkList'],
}))(Modify);

import React, { useRef } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { Button, Card, Divider, Input, Select, message, Modal, notification } from 'antd';
import ControledInput from './components/Input';
import { connect,history } from 'umi';
import { queryList } from './service';
import styles from './style.less';
const { Option } = Select;
let defaultCurrent = 1;
let defaultPageSize = 20;

const Index = props => {

  const { dispatch,smsAppletTemplate,currentUser } = props;
  const { verifyStatus } = currentUser;
  const { searchParam } = smsAppletTemplate;
  const actionRef = useRef();
  const formRef = useRef(null);
  const statusList = [
    {
      label:'全部',
      value:'',
    },
    {
      label:'待审核',
      value:3,
    },
    {
      label:'审核通过',
      value:1,
    },
    {
      label:'审核不通过',
      value:2,
    },
  ];
  const templateTypeList = [
    {
      label:'全部',
      value:'',
    },
    {
      label:'短信小程序',
      value:1,
    },
    {
      label:'H5 Chatbot',
      value:2,
    },
  ];
  const columns = [
    {
      title: '模板ID',
      dataIndex: 'id',
      renderFormItem: (_, { onChange, type, defaultRender,...rest }, form) => {
        return (
          <ControledInput
            maxLength={32}
            regex={/[^\dA-Za-z\u4e00-\u9fa5]/g}
            placeholder="请输入模板ID"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '模板名称',
      dataIndex: 'templateName',
      width: 200,
      ellipsis:true,
      renderFormItem: (_, { onChange, type, defaultRender,...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5]/g}
            placeholder="请输入模板名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '模板类型',
      dataIndex: 'templateType',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              templateTypeList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{templateTypeList.find(item => item.value === _) ? templateTypeList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '模板内容',
      dataIndex: 'templateContent',
      width: 200,
      ellipsis:true,
      hideInSearch:true,
    },
    {
      title: '所属应用',
      dataIndex: 'appName',
      ellipsis:true,
      width: 200,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入应用名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              statusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{statusList.find(item => item.value === _) ? statusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      hideInSearch:true,
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
          {
            record.status === 2 ? (
              <>
                <a
                  onClick={() => {
                    history.push(`/layouts/smsApplet/template/modify/${record.id}`)
                  }}
                >
                  修改
                </a>
                <Divider type="vertical" />
              </>
            ) : null
          }
          <a
            onClick={() => {
              if (dispatch) {
                dispatch({
                  type:'smsAppletTemplate/setParam',
                  payload:{
                    ...formRef.current.getFieldsValue(),
                    current:defaultCurrent,
                    pageSize:defaultPageSize,
                  },
                })
              }
              history.push(`/layouts/smsApplet/template/details/${record.id}`)
            }}
          >
            查看
          </a>
          {
            record.status === 2 ? (
              <>
                <Divider type="vertical" />
                <a
                  onClick={
                    () => {
                      Modal.confirm({
                        title: '是否确定删除:',
                        icon: <QuestionCircleOutlined />,
                        content: `模板删除后将无法正常使用，确定删除${record.templateName}模板？`,
                        onOk:()=>{
                          if (dispatch) {
                            dispatch({
                              type:'smsAppletTemplate/deleteList',
                              payload:{
                                id:record.id
                              }
                            }).then(response => {
                              if (!response.success) {
                                notification.error({
                                  message: response.message || '操作失败！',
                                });
                              } else {
                                message.success('删除成功！');
                                if (actionRef.current) {
                                  actionRef.current.reload();
                                }
                              }
                            })
                          }
                        }
                      })
                    }
                  }
                >
                  删除
                </a>
              </>
            ) : null
          }
        </>
      ),
    },
  ];

  return (
    <PageHeaderWrapper
      title={"模板列表"}
    >
      <Card>
        <ProTable
          actionRef={actionRef}
          columns={columns}
          formRef={formRef}
          options={false}
          pagination={{
            defaultCurrent:searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize:searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          rowKey="id"
          request={
            (params, sorter, filter) => {
              if (searchParam) {
                params.id = searchParam.id || '';
                params.templateName = searchParam.templateName || '';
                params.templateType = searchParam.templateType || '';
                params.appName = searchParam.appName || '';
                params.status = searchParam.status || '';
                if (dispatch) {
                  dispatch({
                    type:'smsAppletTemplate/setParam',
                    payload:null,
                  })
                }
              }
              params.pageNum = params.current;
              defaultCurrent = params.current;
              defaultPageSize = params.pageSize;
              delete params.current;
              delete params.createTime;
              return queryList(params)
            }
          }
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              if (searchParam) {
                form.setFieldsValue({
                  id : searchParam.id || '',
                  templateName : searchParam.templateName || '',
                  templateType : searchParam.templateType || '',
                  appName : searchParam.appName || '',
                  status : searchParam.status || '',
                });
              }
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          toolBarRender={
            () => [
              <Button
                icon={<PlusOutlined />}
                type="primary"
                onClick={() => {
                  if (verifyStatus !== 1) {
                    Modal.warning({
                      title: '提示',
                      content: '您还未完成信息认证！',
                    });
                  } else {
                    history.push(`/layouts/smsApplet/template/add`);
                  }
                }}
              >
                创建模板
              </Button>
            ]
          }
        />
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ user, smsAppletTemplate, loading }) => ({
  currentUser:user.currentUser,
  smsAppletTemplate,
  loading: loading.effects['smsAppletTemplate/queryList'],
}))(Index);

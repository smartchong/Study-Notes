import React, { useState,useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Card, Form, Input, Select, Space, message, notification } from 'antd';
import PreviewModal from './components/PreviewModal';
import { connect,useParams,history } from "umi";
import styles from './style.less';
const { TextArea } = Input;

const Modify = props => {

  const {
    dispatch,
    loading,
    appLoading,
    appAndTableList,
    smsAppletShortLink,
  } = props;
  const { detailsData } = smsAppletShortLink;
  const { appSelectList } = appAndTableList;
  const params = useParams();
  const [form] = Form.useForm();
  const [ url,handleUrl ] = useState('');
  const [ modal,handleModal ] = useState(false);
  useEffect(() => {
    if(dispatch){
      dispatch({
        type:'smsAppletShortLink/queryDetails',
        payload:{
          id:Number(params.id)
        }
      })
    }
    if (dispatch && !appLoading) {
      dispatch({
        type:'appAndTableList/queryAppSelectRule',
      })
    }
  },[params.id]);
  const layout = {
    labelCol: {
      span: 8,
    },
    wrapperCol: {
      span: 8,
    },
  };
  const checkSourceLink = async (_, value) => {
    const promise = Promise;
    if (value) {
      if (
        /^(((http|ftp|https)\:\/\/)(([a-zA-Z0-9\._-]+\.[a-zA-Z]{2,6})|(\d{1,3}\.\d{1,3}\.\d{1,3}\.\d{1,3})|([a-fA-F0-9]{1,4}(:[a-fA-F0-9]{1,4}){7}|[a-fA-F0-9]{1,4}(:[a-fA-F0-9]{1,4}){0,7}::[a-fA-F0-9]{0,4}(:[a-fA-F0-9]{1,4}){0,7}))(\:\d{1,6})?){1,500}/.test(value)
        && !/[\u4E00-\u9FA5]/g.test(value)
      ) {
        return promise.resolve();
      } else {
        return promise.reject('请输入正确的原链接！');
      }
    }
  }
  const onFinish = values => {
    values.id = params.id;
    dispatch({
      type:'smsAppletShortLink/modifyList',
      payload:{
        ...values
      }
    }).then(response => {
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      } else {
        if(dispatch){
          dispatch({
            type:'smsAppletShortLink/setDetails',
            payload:{
              data:null
            }
          })
        }
        message.success('短链提交成功！');
        history.go(-1);
      }
    })
  }

  if (!detailsData || detailsData.id !== Number(params.id)) {
    return null;
  }
  return (
    <PageHeaderWrapper
      title={"修改短链"}
    >
      <Card>
        <Form
          {...layout}
          form={form}
          name="shortLink"
          onFinish={onFinish}
          hideRequiredMark={true}
          initialValues={{
            appId: detailsData.appId,
            sourceLink: detailsData.sourceLink,
            shortLink: detailsData.shortLink,
            comment: detailsData.comment,
          }}
        >
          {/* 应用 */}
          {
            appSelectList && appSelectList.length ? (
              <Form.Item
                label="应用"
                name="appId"
                rules={[
                  {
                    required: true,
                    message: '请选择1个应用！',
                  },
                ]}
              >
                <Select
                  placeholder='请选择'
                >
                  {
                    appSelectList && appSelectList.map((item,index)=>(
                      <Select.Option key={item.appId}>{item.appName}</Select.Option>
                    ))
                  }
                </Select>
              </Form.Item>
            ) : (
              <Form.Item
                label="应用"
                name="appId"
                hasFeedback
                validateStatus="error"
                help="请先创建应用！"
              >
                <Select
                  placeholder='请选择'
                >
                  {
                    appSelectList && appSelectList.map((item,index)=>(
                      <Select.Option key={item.appId}>{item.appName}</Select.Option>
                    ))
                  }
                </Select>
              </Form.Item>
            )
          }
          {/* 原链接 */}
          <Form.Item
            label={'原链接'}
            name={'sourceLink'}
            validateTrigger={"onBlur"}
            rules={[
              {
                required: true,
                message: '请输入原链接！',
              },
              {
                validator: checkSourceLink,
              },
            ]}
          >
            <Input
              maxLength={500}
              placeholder={'请输入包含完整协议的链接，500个字符以内。'}
            />
          </Form.Item>
          {/* 转短后样式 */}
          <Form.Item
            label={'转短后样式'}
            name={'shortLink'}
          >
            <Input
              disabled={true}
            />
          </Form.Item>
          {/* 使用说明 */}
          <Form.Item
            label={'使用说明'}
            name={'comment'}
            validateTrigger={"onBlur"}
            rules={[
              {
                required: true,
                message: '请输入使用说明！',
              },
              {
                pattern: /^[\S]{1,100}$/,
                message: '请输入正确的使用说明！',
              },
            ]}
          >
            <TextArea
              maxLength={100}
              rows={4}
              placeholder={'请简要说明转短目的，100个字符以内。'}
            />
          </Form.Item>
          <Form.Item
            wrapperCol={{
              offset: 8
            }}
          >
            <Space
              size={'large'}
            >
              <Button
                onClick={() => {
                  form.validateFields(['sourceLink']).then(() => {
                    handleUrl(form.getFieldsValue(['sourceLink']).sourceLink);
                    handleModal(true);
                  })
                }}
              >
                预览
              </Button>
              <Button
                onClick={() => {
                  form.resetFields();
                  history.go(-1);
                }}
              >
                取消
              </Button>
              <Button
                loading={loading}
                htmlType={'submit'}
              >
                提交
              </Button>
            </Space>
          </Form.Item>
        </Form>
      </Card>
      <PreviewModal
        onCancel={() => handleModal(false)}
        modalVisible={modal}
      >
        <div className={styles.iframeWrap}>
          <iframe
            className={styles.iframe}
            src={url}
            frameBorder="0"
            scrolling="no"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
          />
        </div>
      </PreviewModal>
    </PageHeaderWrapper>
  )
}

export default connect(({ appAndTableList,smsAppletShortLink,loading }) => ({
  appAndTableList,
  smsAppletShortLink,
  loading: loading.effects['smsAppletShortLink/modifyList'],
  appLoading: loading.effects['appAndTableList/queryAppSelectRule'],
}))(Modify);

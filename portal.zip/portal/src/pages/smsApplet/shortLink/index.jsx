import React, { useRef } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { Button, Card, Divider, Input, Select, message, Modal, notification } from 'antd';
import ControledInput from './components/Input';
import { connect,history } from 'umi';
import { queryList } from './service';
import styles from './style.less';
const { Option } = Select;
let defaultCurrent = 1;
let defaultPageSize = 20;

const Index = props => {

  const { dispatch,smsAppletShortLink } = props;
  const { searchParam } = smsAppletShortLink;
  const actionRef = useRef();
  const formRef = useRef(null);
  const statusList = [
    {
      label:'全部',
      value:'',
    },
    {
      label:'待审核',
      value:3,
    },
    {
      label:'审核通过',
      value:1,
    },
    {
      label:'审核不通过',
      value:2,
    },
  ];
  const columns = [
    {
      title: '短链ID',
      dataIndex: 'id',
      hideInSearch:true,
    },
    {
      title: '原链接地址',
      dataIndex: 'sourceLink',
      ellipsis:true,
      width: 250,
      renderFormItem: (_, { onChange, type, defaultRender,...rest }, form) => {
        return (
          <ControledInput
            maxLength={500}
            regex={/[^a-z_A-Z0-9-\.!@#\$%\\\^&\*\)\(\+=\{\}\[\]\/",'<>~\·`\?:;|]/g}
            placeholder="请输入原链接地址"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '短链接地址',
      dataIndex: 'shortLink',
      ellipsis:true,
      width: 250,
      renderFormItem: (_, { onChange, type, defaultRender,...rest }, form) => {
        return (
          <ControledInput
            maxLength={200}
            regex={/[^a-z_A-Z0-9-\.!@#\$%\\\^&\*\)\(\+=\{\}\[\]\/",'<>~\·`\?:;|]/g}
            placeholder="请输入短链接地址"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '使用说明',
      dataIndex: 'comment',
      ellipsis:true,
      hideInSearch:true,
      width: 200,
    },
    {
      title: '状态',
      dataIndex: 'status',
      renderFormItem: (_, { type, defaultRender,...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              statusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{statusList.find(item => item.value === _) ? statusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '所属应用',
      dataIndex: 'appName',
      ellipsis:true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入应用名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      hideInSearch:true,
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
          {
            record.status === 2 ? (
              <>
                <a
                  onClick={() => {
                    history.push(`/layouts/smsApplet/shortLink/modify/${record.id}`)
                  }}
                >
                  修改
                </a>
                <Divider type="vertical" />
              </>
            ) : null
          }
          <a
            onClick={() => {
              if (dispatch) {
                dispatch({
                  type:'smsAppletShortLink/setParam',
                  payload:{
                    ...formRef.current.getFieldsValue(),
                    current:defaultCurrent,
                    pageSize:defaultPageSize,
                  },
                })
              }
              history.push(`/layouts/smsApplet/shortLink/details/${record.id}`)
            }}
          >
            查看
          </a>
          {
            record.status === 2 ? (
              <>
                <Divider type="vertical" />
                <a
                  onClick={
                    () => {
                      Modal.confirm({
                        title: '是否确定删除:',
                        icon: <QuestionCircleOutlined />,
                        content: '短链删除后将无法正常使用，确定删除该短链？',
                        onOk:()=>{
                          if (dispatch) {
                            dispatch({
                              type:'smsAppletShortLink/deleteList',
                              payload:{
                                id:record.id
                              }
                            }).then(response => {
                              if (!response.success) {
                                notification.error({
                                  message: response.message || '操作失败！',
                                });
                              } else {
                                message.success('删除成功！');
                                if (actionRef.current) {
                                  actionRef.current.reload();
                                }
                              }
                            })
                          }
                        }
                      })
                    }
                  }
                >
                  删除
                </a>
              </>
            ) : null
          }
        </>
      ),
    },
  ];
  return (
    <PageHeaderWrapper
      title={"短链列表"}
    >
      <Card>
        <ProTable
          actionRef={actionRef}
          columns={columns}
          formRef={formRef}
          options={false}
          pagination={{
            defaultCurrent:searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize:searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          rowKey="id"
          request={
            (params, sorter, filter) => {
              if (searchParam) {
                params.sourceLink = searchParam.sourceLink || '';
                params.shortLink = searchParam.shortLink || '';
                params.status = searchParam.status || '';
                params.appName = searchParam.appName || '';
                if (dispatch) {
                  dispatch({
                    type:'smsAppletShortLink/setParam',
                    payload:null,
                  })
                }
              }
              params.pageNum = params.current;
              defaultCurrent = params.current;
              defaultPageSize = params.pageSize;
              delete params.current;
              delete params.createTime;
              return queryList(params)
            }
          }
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              if (searchParam) {
                form.setFieldsValue({
                  sourceLink : searchParam.sourceLink || '',
                  shortLink : searchParam.shortLink || '',
                  status : searchParam.status || '',
                  appName : searchParam.appName || '',
                });
              }
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          toolBarRender={
            () => [
              <Button
                icon={<PlusOutlined />}
                type="primary"
                onClick={() => {
                  history.push(`/layouts/smsApplet/shortLink/add`);
                }}
              >
                创建短链
              </Button>
            ]
          }
        />
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ smsAppletShortLink, loading }) => ({
  smsAppletShortLink,
  loading: loading.effects['smsAppletShortLink/queryList'],
}))(Index);

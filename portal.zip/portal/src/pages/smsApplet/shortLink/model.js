import { notification } from 'antd';
import { queryList,queryDetails,addList,updateList,deleteList } from './service';

const Model = {
  namespace: 'smsAppletShortLink',
  state: {
    tableData:{},
    detailsData:null,
    searchParam:null,
  },
  effects: {
    *queryList({ payload }, { call, put }) {
      const response = yield call(queryList, payload);
      yield put({
        type: 'setList',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
    *queryDetails({ payload }, { call, put }) {
      const response = yield call(queryDetails, payload);
      yield put({
        type: 'setDetails',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
    *addList({ payload }, { call, put }) {
      const response = yield call(addList, payload);
      return response;
    },
    *modifyList({ payload }, { call, put }) {
      const response = yield call(updateList, payload);
      return response;
    },
    *deleteList({ payload }, { call, put }) {
      const response = yield call(deleteList, payload);
      return response;
    },
  },
  reducers: {
    setList(state, { payload }) {
      return { ...state,tableData: payload };
    },
    setDetails(state, { payload }) {
      return { ...state, detailsData:payload.data };
    },
    setParam(state, { payload }) {
      return { ...state,searchParam: payload };
    },
  },
};

export default Model;

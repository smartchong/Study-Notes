import React, { useState,useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Card, Row, Col, Typography } from 'antd';
import PreviewModal from './components/PreviewModal';
import { connect,useParams,history } from "umi";
import styles from './style.less';
const { Text } = Typography;

const Details = props => {

  const { dispatch,smsAppletShortLink,loading } = props;
  const [ modal,handleModal ] = useState(false);
  const params = useParams();
  const { detailsData } = smsAppletShortLink;
  const statusList = [
    {
      label:'待审核',
      value:3,
    },
    {
      label:'审核通过',
      value:1,
    },
    {
      label:'审核不通过',
      value:2,
    },
  ];

  useEffect(() => {
    if(dispatch && !loading){
      dispatch({
        type:'smsAppletShortLink/queryDetails',
        payload:{
          id:Number(params.id)
        }
      })
    }
  },[params.id]);

  if (!detailsData || detailsData.id !== Number(params.id)) {
    return null;
  }
  return (
    <PageHeaderWrapper
      title={"短链详情"}
      content={
        <Button
          style={{float:'right'}}
          onClick={() => history.go(-1)}
        >
          返回
        </Button>
      }
    >
      <Card>
        <Row gutter={[24,24]}>
          <Col span={8}>
            <span>短链ID：</span>
            <span className={styles.text}>{detailsData.id}</span>
          </Col>
          <Col span={8}>
            <span>状态：</span>
            <span className={styles.text}>
              {
                statusList.find(item => item.value === detailsData.status) ?
                  statusList.find(item => item.value === detailsData.status).label :
                  ''
              }
            </span>
          </Col>
          <Col span={8}>
            <span>创建时间：</span>
            <span className={styles.text}>{detailsData.createTime}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={24}>
            <span>所属应用：</span>
            <span className={styles.text}>{detailsData.appName}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={24}>
            <span>原链接地址：</span>
            <span className={styles.text}>{detailsData.sourceLink}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={24}>
            <span>短链接地址：</span>
            <span className={styles.text}>{detailsData.shortLink}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={24}>
            <span>使用说明：</span>
            <span className={styles.text}>{detailsData.comment}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={24}>
            <span>审核意见：</span>
            <span className={styles.text}>{detailsData.opinion}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={24}>
            <Button
              onClick={() => handleModal(true)}
            >
              预览
            </Button>
          </Col>
        </Row>
      </Card>
      <PreviewModal
        onCancel={() => handleModal(false)}
        modalVisible={modal}
      >
        <div className={styles.iframeWrap}>
          <iframe
            className={styles.iframe}
            src={detailsData.sourceLink}
            frameBorder="0"
            scrolling="no"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
          />
        </div>
      </PreviewModal>
    </PageHeaderWrapper>
  )
}

export default connect(({ smsAppletShortLink,loading }) => ({
  smsAppletShortLink,
  loading: loading.effects['smsAppletShortLink/queryDetails'],
}))(Details);

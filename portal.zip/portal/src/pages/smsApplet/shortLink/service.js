import request from '@/utils/request';
import API from '../../../services/api';

// 列表查询
export async function queryList(params) {
  return request(`${API.SMSAPPLET.SHORTLINK.LIST}`, {
    method: 'POST',
    data: params,
  });
}

// 列表详情
export async function queryDetails(params) {
  return request(`${API.SMSAPPLET.SHORTLINK.DETAILS}`, {
    params,
  });
}

// 列表新增
export async function addList(params) {
  return request(`${API.SMSAPPLET.SHORTLINK.ADD}`,{
    method: 'POST',
    data: params,
  })
}

// 列表修改
export async function updateList(params) {
  return request(`${API.SMSAPPLET.SHORTLINK.UPDATE}`,{
    method: 'POST',
    data: params,
  })
}

// 列表删除
export async function deleteList(params) {
  return request(`${API.SMSAPPLET.SHORTLINK.DELETE}`, {
    params,
  })
}

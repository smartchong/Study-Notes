import { message,notification } from 'antd'
import { queryTemplateList,queryDetail,querySmsAppletTemplateList } from './service';

const Model = {
  namespace:'templateAndList',
  state:{
    appList:[],
    detailData:null,
    searchParam:null,
    temSelectList:[],
    smsAppletTemplateList:[],
  },
  effects:{
    *queryTemSelectList({payload,resetData}, { call, put }) {
      if(resetData){
        yield put({
          type: 'setTemSelectList',
          payload: {},
        });
      }
      const response = yield call(queryTemplateList,payload);
      if(response && response.success){
        yield put({
          type: 'setTemSelectList',
          payload: response,
        });
      }else {
        yield put({
          type: 'setTemSelectList',
          payload: {},
        });
      }
    },
    *queryDetail({payload,callback},{call,put}){
      yield put({
        type: 'setDetailData',
        payload: {},
      });
      const response = yield call(queryDetail,payload);
      if(response && response.success){
        yield put({
          type: 'setDetailData',
          payload: response,
        });
        callback(response.data)
      }else {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
    *querySmsAppletTemplateList({payload},{call,put}) {
      const response = yield call(querySmsAppletTemplateList,payload);
      if(response && response.success){
        yield put({
          type: 'setSmsAppletTemplateList',
          payload: response,
        });
      } else {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    }
  },
  reducers:{
    setTemSelectList(state, { payload }) {
      return { ...state, temSelectList:payload.data };
    },
    setDetailData(state, { payload }) {
      return { ...state, detailData:payload.data };
    },
    setSmsAppletTemplateList(state, { payload }) {
      return { ...state, smsAppletTemplateList:payload.data };
    },
    setParam(state, { payload }) {
      return { ...state,searchParam: payload };
    },
  }
}

export default Model;

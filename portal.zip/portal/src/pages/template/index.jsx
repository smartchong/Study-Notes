import React, { useState, useRef, useEffect } from 'react';
import { connect,history } from 'umi';
import { Card, Button, Divider, Dropdown, Input, Menu, message,Modal, Select } from 'antd';
import { DownOutlined, PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import ControledInput from './components/Input';
import ControledRangePicker from './components/RangePicker';
import { queryRule, updateRule, addRule, removeRule } from './service';
import styles from './style.less';
const { Option } = Select;
const prepend = (arr,item) => {
  const temp = arr.slice(0);
  temp.unshift(item);
  return temp;
}
const statusList = [
  {
    label:'全部',
    value:'',
  },
  {
    label:'待审核',
    value:3,
  },
  {
    label:'审核通过',
    value:1,
  },
  {
    label:'审核不通过',
    value:2,
  },
  {
    label:'媒体内容失效',
    value:5,
  },
];
let defaultCurrent = 1;
let defaultPageSize = 20;

const TableList = (props) => {
  const actionRef = useRef();
  const formRef = useRef(null);
  const {
    dispatch,
    templateAndList,
    currentUser,
    location,
  } = props;
  const { searchParam } = templateAndList;
  const { chatbotType } = currentUser;
  const columns = [
    {
      title: '模板ID',
      dataIndex: 'id',
      width: 100,
      ellipsis:true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={18}
            regex={/[\D]/g}
            placeholder="请输入模板ID"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      }
    },
    {
      title: '模板名称',
      dataIndex: 'name',
      textWrap: 'word-break',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入模板名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属应用',
      dataIndex: 'appName',
      textWrap: 'word-break',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入所属应用"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotType',
      renderFormItem: (_, { type, defaultRender,...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              prepend(chatbotType,{label:'全部', value:''}).map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{chatbotType.find(item => item.value === _) ? chatbotType.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '短信模板名称',
      dataIndex: 'smsAppletTemplateName',
      textWrap: 'word-break',
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入短信模板名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      renderFormItem: (_, { type, defaultRender,...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              statusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{statusList.find(item => item.value === _) ? statusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '备注',
      dataIndex: 'remark',
      textWrap: 'word-break',
      hideInSearch: true,
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      textWrap: 'word-break',
      renderFormItem: (_, { type, defaultRender,...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        record.status !== 3 ? (
          <>
            <a
              onClick={() => {
                if (dispatch) {
                  dispatch({
                    type:'templateAndList/setParam',
                    payload:{
                      ...formRef.current.getFieldsValue(),
                      current:defaultCurrent,
                      pageSize:defaultPageSize,
                    },
                  })
                  dispatch({
                    type: 'appAndTableList/setDetailData',
                    payload: { data:null }
                  });
                }
                if (location.pathname.indexOf('/nlzt/') > -1) {
                  history.push(`/nlzt/template/edit/${record.id}?${location.search}`)
                } else {
                  history.push(`/layouts/template/edit/${record.id}`)
                }
              }}
            >
              修改
            </a>
            <Divider type="vertical" />
            <a onClick={()=>{
              Modal.confirm({
                title: '是否确定删除:',
                icon: <QuestionCircleOutlined />,
                content: '选定的条目及所有相关数据？删除后内容将不可恢复。',
                onOk:()=>handleRemove([record])
              })
            }}>删除</a>
          </>
        ) : null
      ),
    },
  ];
  /**
   *  删除节点
   * @param selectedRows
   */
  const handleRemove = async selectedRows => {
    const hide = message.loading('正在删除');
    if (!selectedRows) return true;

    try {
      const ret = await removeRule({
        templateId: selectedRows.map(row => row.id).join(','),
      });
      hide();
      if(ret && ret.success){
        message.success('删除成功');
        if (actionRef.current) {
          actionRef.current.reload();
        }
        return true;
      }else {
        return false;
      }
    } catch (error) {
      hide();
      message.error('删除失败，请重试');
      return false;
    }
  };

  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <ProTable
          headerTitle=""
          actionRef={actionRef}
          formRef={formRef}
          rowKey="id"
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    id={'resetBtn'}
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          rowSelection={false}
          options={false}
          pagination={{
            defaultCurrent:searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize:searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          tableAlertRender={false}
          toolBarRender={(action, { selectedRows }) => [
            <Button icon={<PlusOutlined />} type="primary" onClick={()=>{
              if (location.pathname.indexOf('/nlzt/') > -1) {
                history.push(`/nlzt/template/create?${location.search}`)
              } else {
                history.push('/layouts/template/create')
              }
            }}>
              创建模板
            </Button>,
            selectedRows && selectedRows.length > 0 && (
              <Dropdown
                overlay={
                  <Menu
                    onClick={async e => {
                      if (e.key === 'remove') {
                        await handleRemove(selectedRows);
                        action.reload();
                      }
                    }}
                    selectedKeys={[]}
                  >
                    <Menu.Item key="remove">批量删除</Menu.Item>
                    <Menu.Item key="approval">批量审批</Menu.Item>
                  </Menu>
                }
              >
                <Button>
                  批量操作 <DownOutlined />
                </Button>
              </Dropdown>
            ),
          ]}
          request={
            params => {
              if (searchParam) {
                Object.entries(searchParam).forEach(([key,value]) => {
                  params[key] = value;
                })
                if (dispatch) {
                  dispatch({
                    type:'templateAndList/setParam',
                    payload:null,
                  })
                }
              }
              params.startTime = params.createTime && params.createTime.length ? params.createTime[0] : null;
              params.endTime = params.createTime && params.createTime.length ? params.createTime[1] : null;
              params.pageNum = params.current;
              params.pageSize = params.pageSize;
              defaultCurrent = params.current;
              defaultPageSize = params.pageSize;
              delete params.current;
              delete params.createTime;
              return queryRule(params)
            }
          }
          columns={columns}
        />
      </Card>
    </PageHeaderWrapper>
  );
};

export default connect(({ appAndTableList,user,templateAndList })=>({
  appAndTableList,
  currentUser:user.currentUser,
  templateAndList
}))(TableList);

import API from '@/services/api';
const baseUrl = location.href.split('/#/')[0].split('/portal')[0];
const mediaUrl = API.MEDIA.GET_FILE;
const GETMEGIAURL = (type)=>{
    let url = baseUrl + mediaUrl + '?id=';
    if(type === 'video'){
      url+= '64491a2245214ae58a1987b0504ee1f7'
    }else if (type === 'audio'){
      url+= 'c606a05831864f3abbc69016dbf6ff66';
    }else {
      url += '277aa40921b84837b7888a103f2c51c0';
    }
    return url;
}
export default [

    //占位
    {
  
    },
  
    // Text
    {
      "text": "",
      "menu": []
    },
  
    // File : Image
    {
      "media": {
        "thumbnailContentType": "image/jpeg",
        "thumbnailUrl": GETMEGIAURL(),
        "thumbnailId":'',
        "mediaContentType": "image/jpeg",
        "mediaUrl": GETMEGIAURL(),
        "fileId": '',
      },
      "menu": []
    },
  
    // File : Audio
    {
      "media": {
        "thumbnailContentType": "",
        "thumbnailUrl": GETMEGIAURL(),
        "thumbnailId":'',
        "mediaContentType": "audio/amr",
        "mediaUrl": GETMEGIAURL('audio'),
        "fileId": '',
      },
      "menu": []
    },
  
    // File : Video
    {
      "media": {
        "thumbnailContentType": "image/jpeg",
        "thumbnailUrl": GETMEGIAURL(),
        "thumbnailId":'',
        "mediaContentType": "video/mp4",
        "mediaUrl": GETMEGIAURL('video'),
        "fileId": '',
      },
      "menu": []
    },
  
    // Card
    {
      "generalPurposeCard": {
        "content": {
          "title": "",
          "description": "",
          "media": {
            "height": "MEDIUM_HEIGHT",
            "thumbnailContentType": "image/jpeg",
            "thumbnailUrl": GETMEGIAURL(),
            "mediaContentType": "image/jpeg",
            "mediaUrl": GETMEGIAURL(),
            "fileId": '',
            "thumbnailId":'',
          },
          "suggestions": [],
          "style": {
            "message":{
              "background-color": "#ffffff",
            },
            "messageTitle": {
              "font-size": "16px",
              "color": "#000000",
              "font-weight": 400,
              "text-align": "left"
            },
            "messageDescription": {
              "font-size": "14px",
              "color": "#000000",
              "font-weight": 400,
              "text-align": "left"
            },
            "messageSuggestion": {
              "color": "#0000ff",
              "font-weight": 400,
              "text-align": "center"
            },
          }
        },
        "layout": {
          "cardOrientation": "VERTICAL",
          "cardWidth": "MEDIUM_WIDTH",
          "imageAlignment": "LEFT"
        }
      },
      "menu": []
    },
  
    // Card Carousel
    {
      "generalPurposeCardCarousel": {
        "content": [
          {
            "title": "",
            "description": "",
            "media": {
              "height": "MEDIUM_HEIGHT",
              "thumbnailContentType": "image/jpeg",
              "thumbnailUrl": GETMEGIAURL(),
              "mediaContentType": "image/jpeg",
              "mediaUrl": GETMEGIAURL(),
              "fileId": '',
              "thumbnailId":'',
            },
            "suggestions": [],
            "style": {
              "message":{
                "background-color": "#ffffff",
              },
              "messageTitle": {
                "font-size": "16px",
                "color": "#000000",
                "font-weight": 400,
                "text-align": "left"
              },
              "messageDescription": {
                "font-size": "14px",
                "color": "#000000",
                "font-weight": 400,
                "text-align": "left"
              },
              "messageSuggestion": {
                "color": "#0000ff",
                "font-weight": 400,
                "text-align": "center"
              },
            }
          },
        ],
        "layout": {
          "cardOrientation": "VERTICAL",
          "cardWidth": "MEDIUM_WIDTH",
          "imageAlignment": "LEFT"
        }
      },
      "menu": []
    },
  
];
import React,{ useState,useRef,useEffect } from 'react';
import { Form,Input,Select,Button,Row,Col,Space,Typography,Modal } from 'antd';
import { history } from 'umi';
import { prepend } from '@/utils/utils';
import Content from './content/Content';
import MediaList from './table/index';
const FormItem = Form.Item;
const { Paragraph } = Typography;
const typeList = [
    {value:1,label:'文本消息'},
    {value:2,label:'图片消息'},
    {value:3,label:'语音消息'},
    {value:4,label:'视频消息'},
    {value:5,label:'卡片消息'},
    {value:6,label:'卡片轮播消息'},
];
const dynamicTypeList = [
    {value:1,label:'静态模板'},
    {value:2,label:'动态模板'},
];
const statusList = [
    {
      label:'待审核',
      value:3,
    },
    {
      label:'审核通过',
      value:1,
    },
    {
      label:'审核不通过',
      value:2,
    },
];

const TemplateForm = props => {

    const { type,templates,setType,setTemplates,defaultTemplates,appSelectList,smsAppletTemplateList,onApplicationIdChange,onSubmit,detailData = null } = props; 
    const [form] = Form.useForm();
    const contentRef = useRef();
    const [mask, setMask] = useState(true);
    const [isDynamic, setIsDynamic] = useState(false);
    const [tipShow, setTipShow] = useState({is:false,msg:''});
    const [mediaVisible,setMediaVisible] = useState(false);
    const [modalParams,setModalParams] = useState({fileType:1});
    const getTemplateList = (v)=>{
        form.setFieldsValue({
          smsAppletTemplateId:undefined
        });
        onApplicationIdChange(v);
    }
    const handleSubmit = () => {
        const { getData,type,isValidate } = contentRef.current;
        const isContentV = isValidate();
        setTipShow(isContentV);
        form.validateFields().then( async values => {
          const params = {
            ...values,
            body:getData,
            style:type === 5 ?
              getData.generalPurposeCard.content.style :
              type === 6 ?
                getData.generalPurposeCardCarousel.content[0].style : null,
            type,
          }
          if(isContentV.is) {
            return false;
          }
          onSubmit(params);
        })
    }
    const onOkBtn = (values)=>{
        if (type === 6) {
            values.mimeType = modalParams.mimeType;
            values.index = modalParams.index;
        }
        contentRef.current.onOkBtn(values);
    }
    useEffect(() => {
        if (detailData) {
            form.setFieldsValue({
                ...detailData
            });
            if (detailData.dynamicType === 2) {
                setIsDynamic(true);
            }
            setMask(false);
            // 设置模板表单数据
            const temp = JSON.parse(JSON.stringify(defaultTemplates));
            if ('style' in detailData) {
                if (detailData.type === 6) {
                    detailData.body.generalPurposeCardCarousel.content[0].style = detailData.style;
                } else if (detailData.type === 5) {
                    detailData.body.generalPurposeCard.content.style = detailData.style;
                }
            }
            temp[detailData.type] = detailData.body;
            setType(detailData.type);
            setTimeout(() => {
                setTemplates(temp);
                if (detailData.type === 6) {
                    const { initPanes,generatePane } = contentRef.current;
                    initPanes(generatePane(detailData.body.generalPurposeCardCarousel?.content?.length));
                }
            },0)
        }
    },[detailData]);

    return (
        <>
            <Form
                requiredMark={false}
                form={form}
                initialValues={{
                    type,
                    dynamicType: 1,
                }}
            >
                <Row gutter={[24,24]}>
                    <Col span={8}>
                    {
                        appSelectList && appSelectList.length ? (
                            <FormItem
                                label="应用"
                                name="applicationId"
                                rules={[
                                    {
                                        required: true,
                                        message: '请选择应用！',
                                    },
                                ]}
                                labelCol={{
                                    span:10
                                }}
                                wrapperCol={{
                                    span:14
                                }}
                            >
                                <Select
                                    placeholder='请选择'
                                    onSelect={(v)=>{
                                        if (v && mask) {
                                            setMask(false);
                                        }
                                        getTemplateList(v);
                                    }}
                                >
                                {
                                    appSelectList && appSelectList.map((item,index)=>(
                                        <Select.Option key={item.appId || index}>{item.appName}</Select.Option>
                                    ))
                                }
                                </Select>
                            </FormItem>
                        ) : (
                            <FormItem
                                label="应用"
                                name="applicationId"
                                hasFeedback
                                validateStatus="error"
                                help="请先创建应用！"
                            >
                                <Select
                                    placeholder='请选择'
                                >
                                    {
                                        appSelectList && appSelectList.map((item,index)=>(
                                            <Select.Option key={item.appId || index}>{item.appName}</Select.Option>
                                        ))
                                    }
                                </Select>
                            </FormItem>
                        )
                    }
                    </Col>
                    <Col 
                        span={16}
                        style={{paddingLeft:0}}
                    >
                        <FormItem
                            label="模板名称"
                            name="name"
                            rules={[
                                {
                                    required: true,
                                    message: '请输入模板名称！',
                                },
                            ]}
                            labelCol={{
                                span:5
                            }}
                            wrapperCol={{
                                span:19
                            }}
                        >
                            <Input maxLength={30} placeholder="请输入模板名称，30个字符数以内"/>
                        </FormItem>
                    </Col>
                </Row>
                <Row gutter={[24,24]}>
                    <Col span={8}>
                        <FormItem
                            label={"短信模板"}
                            name={"smsAppletTemplateId"}
                            rules={[
                                {
                                    required: false,
                                    message: '请选择短信模板！',
                                },
                            ]}
                            labelCol={{
                                span:10
                            }}
                            wrapperCol={{
                                span:14
                            }}
                        >
                            <Select
                                placeholder='请选择'
                                onSelect={(v)=>{
                                    if (v === '') {
                                        form.setFieldsValue({
                                            smsAppletTemplateId:undefined
                                        });
                                    }
                                }}
                            >
                                {
                                    smsAppletTemplateList 
                                    && smsAppletTemplateList.length
                                    && prepend(smsAppletTemplateList,{templateName:'请选择', id:''}).map(item => (
                                        <Select.Option
                                            key={item.id}
                                            value={item.id}
                                        >
                                            {item.templateName}
                                        </Select.Option>
                                    ))
                                }
                            </Select>
                        </FormItem>
                    </Col> 
                    <Col span={8}>
                        <FormItem
                            label={"消息形式"}
                            name={"type"}
                            rules={[
                                {
                                    required: true,
                                    message: '请选择消息形式！',
                                },
                            ]}
                            labelCol={{
                                span:10
                            }}
                            wrapperCol={{
                                span:14
                            }}
                        >
                            <Select
                                placeholder='请选择'
                                onSelect={(v)=>{
                                    setType(v);
                                }}
                            >
                                {
                                    typeList && typeList.map(item => (
                                        <Select.Option
                                            key={item.value}
                                            value={item.value}
                                        >
                                            {item.label}
                                        </Select.Option>
                                    ))
                                }
                            </Select>
                        </FormItem>
                    </Col> 
                    <Col span={8}>
                        <FormItem
                            label={"模板类型"}
                            name={"dynamicType"}
                            rules={[
                                {
                                    required: true,
                                    message: '请选择模板类型！',
                                },
                            ]}
                            labelCol={{
                                span:10
                            }}
                            wrapperCol={{
                                span:14
                            }}
                        >
                            <Select
                                placeholder='请选择'
                                onSelect={(v)=>{
                                    if (v === 2) {
                                        setIsDynamic(true);
                                    } else {
                                        setIsDynamic(false);
                                    }         
                                }}
                            >
                                {
                                    dynamicTypeList && dynamicTypeList.map(item => (
                                        <Select.Option
                                            key={item.value}
                                            value={item.value}
                                        >
                                        {item.label}
                                        </Select.Option>
                                    ))
                                }
                            </Select>
                        </FormItem>  
                    </Col>   
                </Row>
                {
                    isDynamic ? (
                        <Row gutter={[24,24]}>
                            <Col span={24}>
                                <Paragraph style={{marginBottom:0}}>动态模板变量说明：</Paragraph>
                                <Paragraph style={{marginBottom:0}}>1.变量格式：{'{code}'}，示例：您已成功购买{'{prodname}'}，订单编号为{'{orderId}'}，我们将尽快为您发货，敬请期待。</Paragraph>
                                <Paragraph style={{marginBottom:0}}>2.变量命名：需能标识内容场景，否则不予通过，例如：{'{name}'}、{'{address}'}、{'{time}'}、{'{number}'}等。</Paragraph>
                                <Paragraph style={{marginBottom:0}}>3.变量长度：变量长度尽可能短，原则上不能超过10个字（汉字、字符、数字、英文、空格等符号，都按1个字符计算），否则不予通过。</Paragraph>
                                <Paragraph style={{marginBottom:0}}>4.使用场景：动态模板只适用于通过API接口调用进行消息发送，页面消息发送不可用。</Paragraph>
                            </Col> 
                        </Row>
                    ) : null
                }
                {/* 消息体制作 */}
                <Content
                    ref={contentRef}
                    type={type}
                    templates={templates}
                    isDynamic={isDynamic}
                    mask={mask}
                    style={detailData ? detailData['style'] : null}
                    setMediaVisible={setMediaVisible}
                    setModalParams={setModalParams}
                    setTemplates={setTemplates}
                />
                {
                    detailData && detailData.status !== 3 ? (
                        <>
                            <FormItem
                                label="审核结果"
                            >
                                <span
                                    style={{
                                        whiteSpace:"normal",
                                        wordBreak:"break-all"
                                    }}
                                >
                                    {
                                        statusList.find(_ => _.value === detailData.status) ? statusList.find(_ => _.value === detailData.status).label : '-'
                                    }
                                </span>
                            </FormItem>
                            <FormItem
                                label="审核意见"
                            >
                                <span
                                    style={{
                                        whiteSpace:"normal",
                                        wordBreak:"break-all"
                                    }}
                                >
                                    {detailData.auditReason ? detailData.auditReason : '-'}
                                </span>
                            </FormItem>
                        </>
                    ) : null
                }
                <FormItem>
                    <div className="ant-form-item-has-error">
                        <div className="ant-form-item-explain">
                            <div 
                                style={{
                                    display: tipShow.is ? 'block':'none',
                                    color: 'red',
                                }}
                            >
                                {tipShow.msg}
                            </div>
                        </div>
                    </div>
                </FormItem>
                <FormItem>
                    <Space size={"large"}>
                        <Button 
                            onClick={()=>{
                                history.go(-1);
                            }}
                        >
                            取消
                        </Button>
                        <Button
                            type="primary"
                            onClick={handleSubmit}
                        >
                            提交
                        </Button>
                    </Space>
                </FormItem>
            </Form>
            {/* 媒体列表 */}
            <Modal
                width={1000}
                height={300}
                title='媒体列表'
                destroyOnClose={true}
                footer={null}
                visible={mediaVisible}
                onCancel={_=>setMediaVisible(false)}
            >
                <MediaList
                    isUseBtn={true}
                    modalParams={{
                        appName:appSelectList.find(_ => _.appId === form.getFieldsValue().applicationId) ? appSelectList.find(_ => _.appId === form.getFieldsValue().applicationId).appName : '',
                        ...modalParams,
                    }}
                    onOkBtn={onOkBtn}
                />
            </Modal>
        </>
    )
}

export default TemplateForm;

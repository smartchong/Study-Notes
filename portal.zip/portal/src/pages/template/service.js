import request from '@/utils/request';
import API from '@/services/api';

export async function queryTemplateList(params) {
  return request(API.TEMPLATE.QUERY_SELECT_LIST,{
    params
  });
}

export async function queryRule(params) {
  return request(API.TEMPLATE.QUERY_LIST, {
    method: 'POST',
    data:{...params},
  });
}
export async function queryDetail(params) {
  return request(API.TEMPLATE.QUERY_DETAIL, {
    method: 'POST',
    params,
  });
}
export async function removeRule(params) {
  return request(API.TEMPLATE.DEL, {
    method: 'POST',
    params,
  });
}
export async function addRule(params) {
  return request(API.TEMPLATE.ADD, {
    method: 'POST',
    data: { ...params, method: 'add' },
  });
}
export async function updateRule(params) {
  return request(API.TEMPLATE.ADD, {
    method: 'POST',
    data: { ...params, method: 'update' },
  });
}
export async function querySmsAppletTemplateList(params) {
  return request(API.SMSAPPLET.TEMPLATE.PASS,{
    params,
  });
}
export async function queryModalRule(params) {
  return request(API.MEDIA.TABLE_LIST,{
    method: 'POST',
    data:{...params},
  });
}

import { getMenuData, getPageTitle } from '@ant-design/pro-layout';
import { Helmet, HelmetProvider} from 'react-helmet-async';
import { useIntl, connect } from 'umi';
import React from 'react';

const Layout = props => {
  const {
    route = {
      routes: [],
    },
    dispatch,
  } = props;
  const { routes = [] } = route;
  const {
    children,
    location = {
      pathname: '/',
    },
    title:settingsTitle,
  } = props;

  const { formatMessage } = useIntl();
  const { breadcrumb } = getMenuData(routes);
  const title = getPageTitle({
    pathname: location.pathname,
    pageName:'name',
    formatMessage,
    breadcrumb,
    ...props,
  });

  return (
      <HelmetProvider>
        <Helmet>
          <title>{title}</title>
          <meta name="description" content={title} />
        </Helmet>
        {/*<PageHeaderWrapper
          title={title.substr(0,title.indexOf(settingsTitle)-3)}
        >
        {children}
        </PageHeaderWrapper>*/}
        {children}
      </HelmetProvider>
  );
};

export default connect(({ settings }) => ({
  ...settings
}))(Layout);

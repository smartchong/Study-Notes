import React,{ useState,useEffect } from 'react';
import { connect,history,useParams } from 'umi';
import { updateRule } from './service';
import { Card,Row,Col,message } from 'antd';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import Preview from './components/content/Preview';
import TemplateForm from './components/TemplateForm';
import defaultTemplates from './components/defaultTemplates';
import defaultMenuData from '@/pages/app/components/defaultMenuData';

const Edit = props => {

  const params = useParams();
  const [type,setType] = useState(1);
  const [templates,setTemplates] = useState(JSON.parse(JSON.stringify(defaultTemplates)));
  const [bottomMenu,setBottomMenu] = useState(null);
  const [bottomMenuType,setBottomMenuType] = useState(0);
  const {
    dispatch,
    detailData,
    smsAppletTemplateList,
    appSelectList,
    appLoading,
    detailLoading
  } = props;

  useEffect(() => {
    if (dispatch && !detailLoading) {
      dispatch({
        type:'templateAndList/queryDetail',
        payload:{
          templateId:params['id']
        },
        callback:(response) => {
          if (dispatch) {
            dispatch({
              type:'templateAndList/querySmsAppletTemplateList',
              payload:{
                appId:response.applicationId,
              }
            })
          }
        }
      })
    }
  }, []);
  useEffect(()=>{
    if(dispatch && !appLoading){
      dispatch({
        type:'appAndTableList/queryAppSelectRule'
      })
    }
  },[]);
  useEffect(()=>{
    if (detailData) {
        // 设置底部固定菜单数据
        const selected = appSelectList.find(_ => _.appId === detailData.applicationId);
        if ('bottomMenu' in selected && 'bottomMenuType' in selected) {
            const temp = JSON.parse(JSON.stringify(defaultMenuData));
            temp[selected.bottomMenuType] = JSON.parse(selected.bottomMenu);
            setBottomMenu(temp);
            setBottomMenuType(selected.bottomMenuType);
        }
    }
  },[detailData]);

  return (
    <PageHeaderWrapper>
      <Card>
        <Row gutter={[24,24]}>
          {/* 预览 */}
          <Col span={10}>
            <Preview
              templates={templates}
              type={type}
              bottomMenu={bottomMenu}
              bottomMenuType={bottomMenuType}
            />
          </Col>
          {/* 内容制作 */}
          <Col span={14}>
            <TemplateForm 
              type={type}
              templates={templates}
              setType={setType}
              setTemplates={setTemplates}
              defaultTemplates={defaultTemplates}
              appSelectList={appSelectList}
              smsAppletTemplateList={smsAppletTemplateList}
              onApplicationIdChange={(v) => {
                if (dispatch) {
                  dispatch({
                    type:'templateAndList/querySmsAppletTemplateList',
                    payload:{
                      appId:v,
                    }
                  })
                }
                const selected = appSelectList.find(_ => _.appId === v);
                if ('bottomMenu' in selected && 'bottomMenuType' in selected) {
                  const temp = JSON.parse(JSON.stringify(defaultMenuData));
                  temp[selected.bottomMenuType] = JSON.parse(selected.bottomMenu);
                  setBottomMenu(temp);
                  setBottomMenuType(selected.bottomMenuType);
                } else {
                  setBottomMenu(null);
                  setBottomMenuType(0);
                }
              }}
              onSubmit={async (values) => {
                values.id = params['id'];
                const hide = message.loading('正在更新');
                const ret = await updateRule(values);
                hide();
                if(ret && ret.success){
                  message.success('更新成功');
                  history.goBack();
                } else {
                  message.error(ret.message || '操作失败');
                }
              }}
              detailData={detailData}
            />
          </Col>
        </Row>
      </Card>
    </PageHeaderWrapper>
  );
};

export default connect(({templateAndList,appAndTableList,loading})=>({
  smsAppletTemplateList:templateAndList.smsAppletTemplateList,
  appSelectList:appAndTableList.appSelectList,
  appLoading:loading.effects['appAndTableList/queryAppSelectRule'],
  detailData:templateAndList.detailData,
  detailLoading:loading.effects['templateAndList/queryDetail'],
}))(Edit);

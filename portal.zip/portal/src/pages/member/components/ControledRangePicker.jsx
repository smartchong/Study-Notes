import React, { useState } from 'react';
import { DatePicker } from 'antd';
import moment from 'moment';

const { RangePicker } = DatePicker;

const Index  = (props) => {
  const { onChange, initialValue } = props;
  const [dates, setDates] = useState([]);
  const [hackValue, setHackValue] = useState();
  const [value, setValue] = initialValue ? useState(initialValue) : useState();
  const disabledDate = current => {
    if (dates) {
      const tooLate = dates[0] && current.diff(dates[0], 'days') > 90 || current && current > moment().endOf('day');
      const tooEarly = dates[1] && dates[1].diff(current, 'days') > 90;
      return tooLate || tooEarly;
    }
  };

  const onOpenChange = open => {
    if (open) {
      setHackValue([]);
      setDates([]);
    } else {
      setHackValue(undefined);
    }
  };

  return (
    <RangePicker
      value={hackValue || value}
      disabledDate={disabledDate}
      onCalendarChange={val => setDates(val)}
      onChange={val => {
        setValue(val);
        onChange(val);
      }}
      onOpenChange={onOpenChange}
    />
  );
};

export default Index
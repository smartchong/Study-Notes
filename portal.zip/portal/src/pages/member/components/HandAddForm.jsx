import React, { useState } from 'react';
import { checkPartmentUnique } from '../service';
import { Form, Button, Input, Radio, Space, Select, Modal, message } from 'antd';
import { MinusCircleOutlined, PlusCircleOutlined } from '@ant-design/icons';
const FormItem = Form.Item;

const HandAddForm = (props) => {

  const [form] = Form.useForm();
  const [form2] = Form.useForm();
  const { partmentList, modalVisible, onSubmit: handleAdd, onCancel } = props;
  let selectedPartmentText = '';
  const handleOk = async () => {
    const v1 = await form.validateFields();
    const v2 = await form2.validateFields();
    const params = {};
    if (v1.type == '1') {
      params.departmentId = null;
      params.departmentName = v1.departmentName;
    }else {
      params.departmentId = v1.id;
      params.departmentName = selectedPartmentText;
    }
    params.memberList = v2.list;
    handleAdd(params, () => {
      form.resetFields();
      form2.resetFields();
    });
  };
  const checkUnique = async (_, value) => {
    const promise = Promise;
    if (value) {
      //只能输入中文
      const regex = /^[\u4E00-\u9FA5]+$/;
      if (!regex.test(value)) {
        return Promise.reject('请输入中文！');
      }
      const response = await checkPartmentUnique({ name: value });
      if (!response.success) {
        return promise.reject('与已有部门重复，请重新输入！');
      }
      return promise.resolve();
    }
  }
  const checkZh = async (_, value) => {
    if (value) {
      const regex = /^[\u4E00-\u9FA5]+$/;
      if (!regex.test(value)) {
        return Promise.reject('请输入中文！');
      }
      return Promise.resolve();
    }
  }
  const checkPhone = async (_, value) => {
    if (value) {
      const regex = /^1[3-9][0-9]{9}$/;
      if (!regex.test(value)) {
        return Promise.reject('号码格式错误！');
      }
      const list = form2.getFieldsValue().list;
      let count = 0;
      list.forEach((item, index) => {
        if (item.phone === value) {
          count++;
        }
      })
      if (count >= 2) {
        return Promise.reject('号码不能重复！');
      }
      return Promise.resolve();
    }
  }
  const checkEmail = async (_, value) => {
    if (value) {
      const regex = new RegExp('^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?' +
      '(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$');
      if (!regex.test(value)) {
        return Promise.reject('邮箱格式错误！');
      }
      return Promise.resolve();
    }
  }

  return (
    <Modal
      destroyOnClose
      title="添加成员"
      visible={modalVisible}
      onOk={handleOk}
      width={800}
      onCancel={() => {
        form.resetFields();
        form2.resetFields();
        // handleMobileList([]);
        onCancel();
      }}
    >
      <Form
        form={form}
        hideRequiredMark={true}
        autoComplete="off"
        initialValues={{
          type: 2
        }}
      >
        <Space align="baseline">
          <FormItem
            label="所属部门"
            name="type"
          >
            <Radio.Group>
              <Radio value={2}>已有部门</Radio>
              <Radio value={1}>新部门</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            noStyle
            shouldUpdate={(prevValue, curValue) => prevValue.type !== curValue.type}
          >
            {
              ({ getFieldValue }) => {
                const type = Number(getFieldValue('type'));
                if (type === 1) {
                  // 新部门名称
                  return (
                    <FormItem
                      name="departmentName"
                      validateTrigger={"onBlur"}
                      rules={[
                        {
                          required: true,
                          message: '请输入成员所属部门！',
                        },
                        {
                          validator: checkUnique,
                        },
                      ]}
                    >
                      <Input
                        maxLength={20}
                        style={{width: 300}}
                        placeholder={'请输入所属部门名称，20个字符数以内'}
                      />
                    </FormItem>
                  );
                } else if (type === 2) {
                  // 选择已有部门
                  return (
                    <FormItem
                      name="id"
                      rules={[
                        {
                          required: true,
                          message: '请选择所属部门！',
                        },
                      ]}
                    >
                      <Select
                        placeholder='请选择'
                        showSearch
                        optionFilterProp="children"
                        style={{width: 250}}
                        filterOption={(input, option) =>
                          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                        onSelect={(value, option) => {
                          selectedPartmentText = option.children;
                        }}
                      >
                        {
                          partmentList && partmentList.map((item, index) => (
                            <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                          ))
                        }
                      </Select>
                    </FormItem>
                  );
                }
              }
            }
          </FormItem>
        </Space>
      </Form>
      <Form
        form={form2}
        hideRequiredMark={true}
        autoComplete="off"
        initialValues={{
          list: [{
            key: 0
          }]
        }}
      >
        <Form.List name="list" >
          {(fields, { add, remove }) => (
            <>
              <div className='mb-10'>成员信息:</div>
              {fields.map((field, index) => (
                <Space key={field.key} align="baseline">
                  <Form.Item
                    label="姓名"
                    name={[field.name, 'fullName']}
                    fieldKey={[field.fieldKey, 'fullName']}
                    validateTrigger={"onBlur"}
                    rules={[
                      { required: true, message: '请输入姓名!' },
                      {
                        validator: checkZh,
                      },
                    ]}
                  >
                    <Input
                        maxLength={10}
                        placeholder="请输入姓名"
                    />
                  </Form.Item>
                  <Form.Item
                    label="职位"
                    name={[field.name, 'position']}
                    fieldKey={[field.key, 'position']}
                    validateTrigger={"onBlur"}
                    rules={[
                      { required: true, message: '请输入成员职位!' },
                      {
                        validator: checkZh,
                      },
                    ]}
                  >
                    <Input
                        maxLength={20}
                        placeholder={"请输入成员职位，长度20字符数以内。"}
                    />
                  </Form.Item>
                  <Form.Item
                    label="手机号码"
                    name={[field.name, 'phone']}
                    fieldKey={[field.fieldKey, 'phone']}
                    validateTrigger={"onBlur"}
                    rules={[
                      { required: true, message: '请输入成员手机号码！' },
                      {
                        validator: checkPhone,
                      },
                    ]}
                  >
                    <Input
                        maxLength={11}
                        placeholder={"请输入成员手机号码"}
                    />
                  </Form.Item>
                  <Form.Item
                    label="邮箱"
                    name={[field.name, 'mailbox']}
                    fieldKey={[field.fieldKey, 'mailbox']}
                    validateTrigger={"onBlur"}
                    rules={[
                      { required: true, message: '请输入成员邮箱！' },
                      {
                        validator: checkEmail,
                      },
                    ]}
                  >
                    <Input
                        maxLength={50}
                        placeholder={"请输入成员邮箱"}
                    />
                  </Form.Item>
                  <PlusCircleOutlined
                    onClick={() => {
                      if (fields.length < 10) {
                        add(null, index + 1)
                      } else {
                        message.warn('一次性最多添加10个成员！')
                      }
                    }}
                  />
                  {
                    fields.length > 1 ? <MinusCircleOutlined
                      onClick={() => {
                        if (fields.length > 1) {
                          return remove(field.name)
                        }
                      }}
                    /> : null
                  }

                </Space>
              ))}
            </>
          )}
        </Form.List>
      </Form>
    </Modal>
  );
};

export default HandAddForm;

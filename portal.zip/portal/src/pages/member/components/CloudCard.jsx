import React from 'react';
import styles from './style.less';

const Index = props => {
  const { data } = props;
  return (
    <div className={styles.CloudCard}>
      <div className='top-section'>
        <div className='top-left'>
          <div className='name'>
            {data.fullName}
          </div>
          <div className='position'>
            {`${data.department}・${data.position}`}
          </div>
          <div className='compony'>
            {data.companyName}
          </div>
        </div>
        <div className='top-right'>
          <img src={data.companyLogoUrl} />
        </div>
      </div>
      <div className='bottom-section'>
        <div className='bottom-item'>
          <img src={require('../../../assets/vCard/phone.png')} alt='' />
          <div className='bottom-item-content'>
            手机：+86 {data.phone}
          </div>
        </div>
        <div className='bottom-item'>
          <img src={require('../../../assets/vCard/email.png')} alt='' />
          <div className='bottom-item-content'>
            邮箱：{data.mailbox}
          </div>
        </div>
        <div className='bottom-item'>
          <img src={require('../../../assets/vCard/location.png')} alt='' />
          <div className='bottom-item-content'>
            地址：{data.companyAddress}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Index;
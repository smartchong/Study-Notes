import React from 'react';
import { Descriptions, Button, Form, Select, Input } from 'antd';
import styles from './style.less';

const Index = props => {
  const { isEdit, changeEditStatus, data, doSubmit, departmentList, gotoPage } = props;
  let selectedPartmentText = data.department;
  const formItemLayout = {
    labelCol: {
      span: 4,
    },
    wrapperCol: {
      span: 20,
    },
  };
  const tailLayout = {
    wrapperCol: { offset: 4, span: 20 },
  };

  const checkZh = async (_, value) => {
    if (value) {
      const regex = /^[\u4E00-\u9FA5]+$/;
      if (!regex.test(value)) {
        return Promise.reject('请输入中文！');
      }
      return Promise.resolve();
    }
  }
  const checkPhone = async (_, value) => {
    if (value) {
      const regex = /^1[3-9][0-9]{9}$/;
      if (!regex.test(value)) {
        return Promise.reject('号码格式错误！');
      }
      return Promise.resolve();
    }
  }
  const checkEmail = async (_, value) => {
    if (value) {
      const regex = new RegExp('^[a-zA-Z0-9.!#$%&\'*+\/=?^_`{|}~-]+@[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?' +
      '(?:\.[a-zA-Z0-9](?:[a-zA-Z0-9-]{0,61}[a-zA-Z0-9])?)*$');
      if (!regex.test(value)) {
        return Promise.reject('邮箱格式错误！');
      }
      return Promise.resolve();
    }
  }

  const onFinish = values => {
    if (values) {
      values.departmentName = selectedPartmentText;
      doSubmit(values);
    }
  };

  return (
    <div className={styles.basicInfoForm}>
      {
        !isEdit ? <div>
          <Descriptions column={1}>
            <Descriptions.Item label="姓名">
              { data.fullName }
            </Descriptions.Item>
            <Descriptions.Item label="部门">
              { data.department }
            </Descriptions.Item>
            <Descriptions.Item label="职位">
              { data.position }
            </Descriptions.Item>
            <Descriptions.Item label="手机号码">
              { data.phone }
            </Descriptions.Item>
            <Descriptions.Item label="邮箱">
            { data.mailbox }
            </Descriptions.Item>
          </Descriptions>
          <div className='mt-20'>
            <Button
              className='mr-20'
              onClick={() => {
                gotoPage('/cloudCard/member/list');
              }}
            >
              返回
            </Button>
            <Button
              type='primary'
              onClick={() => {
                changeEditStatus(true)
              }}
            >
              修改
            </Button>
          </div>
        </div> : <div className='edit-form'>
            <Form
              // form={form}
              name={"infoForm"}
              {...formItemLayout}
              onFinish={onFinish}
              initialValues={
                data
              }
            >
              <Form.Item
                label={"姓名"}
                name={"fullName"}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入姓名！',
                  },
                  {
                    validator: checkZh,
                  },
                ]}
              >
                <Input
                  maxLength={10}
                  placeholder={"请输入成员姓名，长度30字符数以内。"}
                />
              </Form.Item>
              <Form.Item
                label={"部门"}
                name={"departmentId"}
                rules={[
                  {
                    required: true,
                    message: '请选择成员所属部门',
                  },
                ]}
              >
                <Select
                  placeholder='请选择'
                  showSearch
                  optionFilterProp="children"
                  filterOption={(input, option) =>
                    option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                  }
                  onSelect={(value, option) => {
                    selectedPartmentText = option.children;
                  }}
                >
                  {
                    departmentList && departmentList.map((item, index) => (
                      <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                    ))
                  }
                </Select>
              </Form.Item>
              <Form.Item
                label={"职位"}
                name={"position"}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入成员职位！',
                  },
                  {
                    validator: checkZh,
                  },
                ]}
              >
                <Input
                  maxLength={20}
                  placeholder={"请输入成员职位，长度20字符数以内。"}
                />
              </Form.Item>
              <Form.Item
                label={"手机号码"}
                name={"phone"}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入成员手机号码！',
                  },
                  {
                    validator: checkPhone,
                  },
                ]}
              >
                <Input
                  maxLength={11}
                  placeholder={"请输入成员手机号码"}
                />
              </Form.Item>
              <Form.Item
                label={"邮箱"}
                name={"mailbox"}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入成员邮箱！',
                  },
                  {
                    validator: checkEmail,
                  },
                ]}
              >
                <Input
                  maxLength={50}
                  placeholder={"请输入成员邮箱"}
                />
              </Form.Item>
              <Form.Item {...tailLayout}>
                <Button
                  className='mr-20'
                  onClick={() => {
                    changeEditStatus(false);
                    gotoPage('/cloudCard/member/list');
                  }}
                >
                  取消
                </Button>
                <Button type="primary" htmlType="submit" loading={props.loading}>
                  提交
                </Button>
              </Form.Item>
            </Form>
          </div>
      }
    </div >
  )
}

export default Index;
import React, { useState } from 'react';
import { checkPartmentUnique, downloadTemplate, batchAddMembers } from '../service';
import { Form, Button, Input, Radio, Space, Select, Modal, notification, Upload } from 'antd';
const FormItem = Form.Item;

const BatchImportForm = (props) => {

  const [form] = Form.useForm();
  const { partmentList, modalVisible, onSuccess, onCancel } = props;
  const [uploading, handleUploading] = useState(false);
  let selectedPartmentText = '';

  const checkUnique = async (_, value) => {
    const promise = Promise;
    if (value) {
      const regex = /^[\u4E00-\u9FA5]+$/;
      if (!regex.test(value)) {
        return Promise.reject('请输入中文！');
      }
      const response = await checkPartmentUnique({ name: value });
      if (!response.success) {
        return promise.reject('与已有部门重复，请重新输入！');
      }
      return promise.resolve();
    }
  }

  const uploadProps = {
    accept: '.xls,.xlsx',
    beforeUpload: file => {
      return false;
    },
  };
  const normFile = e => {
    if (Array.isArray(e)) {
      return e.fileList.slice(-1);
    }
    return e && e.fileList.slice(-1);
  };

  const checkFile = async (_, value) => {
    const promise = Promise;
    if (value && value.length) {
      if (value.length > 1) {
        return promise.reject('上传文件数超出限制！');
      } else {
        if (value[0].type && value[0].type !== 'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet' && value[0].type !== 'application/vnd.ms-excel') {
          return promise.reject('请上传正确格式的文件！');
        }
      }
      return promise.resolve();
    }
  }

  const handleUpload = async () => {
    const fieldsValue = await form.validateFields();
    const formData = new FormData();
    formData.append('file', fieldsValue.file[0].originFileObj);
    if (Number(fieldsValue.type) === 2) {
      formData.append('departmentId', fieldsValue.id);
      formData.append('departmentName', selectedPartmentText);
    } else {
      formData.append('departmentId', '');
      formData.append('departmentName', fieldsValue.name);
    }
    handleUploading(true);
    const response = await batchAddMembers(formData);
    if (!response.success) {
      notification.error({
        message: response.message || '操作失败',
      });
    } else {
      notification.success({
        message: response.data || '操作成功',
      });
      onSuccess();
    }
    handleUploading(false);
  };

  return (
    <Modal
      destroyOnClose
      title="添加成员"
      visible={modalVisible}
      footer={null}
      width={700}
      onCancel={() => {
        form.resetFields();
        onCancel();
      }}
    >
      <Form
        form={form}
        hideRequiredMark={true}
        autoComplete="off"
        initialValues={{
          type: 2
        }}
      >
        <Space align="baseline">
          <FormItem
            label="所属部门"
            name="type"
          >
            <Radio.Group>
              <Radio value={2}>已有部门</Radio>
              <Radio value={1}>新部门</Radio>
            </Radio.Group>
          </FormItem>
          <FormItem
            noStyle
            shouldUpdate={(prevValue, curValue) => prevValue.type !== curValue.type}
          >
            {
              ({ getFieldValue }) => {
                const type = Number(getFieldValue('type'));
                if (type === 1) {
                  // 新部门名称
                  return (
                    <FormItem
                      name="name"
                      validateTrigger={"onBlur"}
                      rules={[
                        {
                          required: true,
                          message: '请输入成员所属部门！',
                        },
                        {
                          validator: checkUnique,
                        },
                      ]}
                    >
                      <Input
                        maxLength={20}
                        style={{ width: 300 }}
                        placeholder={'请输入所属部门名称，20个字符数以内'}
                      />
                    </FormItem>
                  );
                } else if (type === 2) {
                  // 选择已有部门
                  return (
                    <FormItem
                      name="id"
                      rules={[
                        {
                          required: true,
                          message: '请选择所属部门！',
                        },
                      ]}
                    >
                      <Select
                        placeholder='请选择'
                        showSearch
                        optionFilterProp="children"
                        style={{ width: 200 }}
                        filterOption={(input, option) =>
                          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                        onSelect={(value, option) => {
                          selectedPartmentText = option.children;
                        }}
                      >
                        {
                          partmentList && partmentList.map((item, index) => (
                            <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                          ))
                        }
                      </Select>
                    </FormItem>
                  );
                }
              }
            }
          </FormItem>
        </Space>
        <div className='mb-10'>
          成员信息
          <div style={{
            display: 'inline-block',
            marginLeft: 40,
            color: '#808080'
          }}>
            *单次导入最多支持导入1000个成员。
          </div>
          <a style={{ marginLeft: 20 }} href={downloadTemplate()}>下载模板</a>
        </div>
        <Space align="baseline">
          <Form.Item
            label='成员名单'
            name='file'
            valuePropName={"fileList"}
            getValueFromEvent={normFile}
            rules={[
              {
                required: true,
                message: '输入项不能为空，请先上传文件！',
              },
              {
                validator: checkFile
              }
            ]}
            extra={
              <Button
                style={{
                  position: 'absolute',
                  top: 0,
                  left: 100,
                }}
                type="primary"
                onClick={handleUpload}
                loading={uploading}
              >
                {false ? '正在导入' : '开始导入'}
              </Button>
            }
          >
            <Upload {...uploadProps}>
              <Button type="primary">选择文件</Button>
            </Upload>
          </Form.Item>
        </Space>
      </Form>
    </Modal>
  );
};

export default BatchImportForm;

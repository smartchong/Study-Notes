import request from '@/utils/request';
import API from '@/services/api';

/**
 * 手动添加成员
 * @param {*} params 
 */
export async function addMembers(params) {
    return request(API.CLOUDCARD.MEMBERMANAGE.LIST.ADD, {
        method: 'POST',
        data: { ...params },
    });
}

/**
 * 批量添加成员
 * @param {*} params 
 */
export async function batchAddMembers(params) {
    return request(API.CLOUDCARD.MEMBERMANAGE.LIST.BATCHADD, {
        method: 'POST',
        data: params,
    });
}

export async function getAllPartment() {
    return request(API.CLOUDCARD.MEMBERMANAGE.LIST.ALL);
}

export async function deleteMembers(params) {
    return request(API.CLOUDCARD.MEMBERMANAGE.LIST.DELETE, {
        method: 'POST',
        data: { ...params },
    });
}

export async function memberDetail(params) {
    return request(API.CLOUDCARD.MEMBERMANAGE.LIST.DETAIL, {
        params 
    });
}

export function downloadTemplate() {
    return API.CLOUDCARD.MEMBERMANAGE.LIST.DOEWLOAD;
}

export async function memberList(params) {
    return request(API.CLOUDCARD.MEMBERMANAGE.LIST.LIST, {
        method: 'POST',
        data: { ...params },
    });
}

export async function modify(params) {
    return request(API.CLOUDCARD.MEMBERMANAGE.LIST.MODIFY, {
        method: 'POST',
        data: { ...params },
    });
}

export async function checkPartmentUnique(params) {
    return request(API.CLOUDCARD.MEMBERMANAGE.LIST.UNIQUE, {
        params 
    });
}
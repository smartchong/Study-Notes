import { notification } from 'antd';
import { addMembers, getAllPartment, deleteMembers, memberDetail, modify } from './service';

const Model = {
    namespace: 'memberManage',
    state: {
        partmentList: [],
        memberInfo: null,
        searchParam:null,
    },
    effects: {
        *addMembers({ payload }, { call, put }) {
            const response = yield call(addMembers, payload);
            if (!response.success) {
                notification.error({
                    message: response.message || '操作失败！',
                });
            }else {
                notification.success({
                    message: '添加成功！',
                });
            }
            return response;
        },
        *getAllPartment({ payload }, { call, put }) {
            const response = yield call(getAllPartment, payload);
            if (!response.success) {
                notification.error({
                    message: response.message || '操作失败！',
                });
            } else {
                yield put({
                    type: 'changeData',
                    payload: { partmentList: response.data },
                });
            }
        },
        *deleteMembers({ payload }, { call, put }) {
            const response = yield call(deleteMembers, payload);
            if (!response.success) {
                notification.error({
                    message: response.message || '操作失败！',
                });
            } else {
                notification.success({
                    message: response.data || '删除成功',
                });
            }
        },
        *memberDetail({ payload }, { call, put }) {
            const response = yield call(memberDetail, payload);
            if (!response.success) {
                notification.error({
                    message: response.message || '操作失败！',
                });
            } else {
                yield put({
                    type: 'changeData',
                    payload: { memberInfo: response.data },
                });
            }
        },
        *modify({ payload, callback }, { call, put }) {
            const response = yield call(modify, payload);
            if (!response.success) {
                notification.error({
                    message: response.message || '操作失败！',
                });
            } else {
                notification.success({
                    message: response.data || '修改成功!',
                });
                callback();
            }
        },
    },
    reducers: {
        changeData(state, { payload }) {
            return { ...state, ...payload };
        },
        setParam(state, { payload }) {
          return { ...state,searchParam: payload };
        }
    },
};
export default Model;
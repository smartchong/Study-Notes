import React, { useEffect, useState } from 'react';
import { connect, useParams } from "umi";
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Card } from 'antd';
import CloudCard from './components/CloudCard';
import BasicInfoForm from './components/BasicInfoForm';
import styles from './style.less';

const MemberDetail = (props) => {
    const param = useParams();
    const { dispatch, memberManage, history } = props;
    const [editStatus, setEditStatus] = useState(history.location.state?.editStatus || false);
    useEffect(() => {
        if (dispatch) {
            dispatch({
                type: 'memberManage/memberDetail',
                payload: {
                    id: param.id
                }
            });
            dispatch({
                type: 'memberManage/getAllPartment'
            });
        }
    }, [param.id]);
    const doSubmit = (params) => {
        params.id = param.id;
        dispatch({
            type: 'memberManage/modify',
            payload: params,
            callback: () => {
                gotoPage('/cloudCard/member/list');
            },
        });
    }
    const gotoPage = (href) => {
        history.push({
            pathname: href,
        });
    }
    if (!memberManage.memberInfo || memberManage.memberInfo.id !== Number(param.id)) {
        return null;
    }
    return (
        <PageHeaderWrapper
            title={editStatus ? '成员修改' : '成员详情'}
            breadcrumb={
                {
                    routes: [
                        { path: '/cloudCard/member/list', breadcrumbName: '成员列表' },
                        { breadcrumbName: editStatus ? '成员修改' : '成员详情' }
                      ],
                }
            }
        >
            <div
                className={styles.memberDetails}
            >
                <Card bordered={false}>
                    <div className='custom-card'>
                        <Card
                            bordered={false}
                            title='名片样式预览'
                        >
                            {
                                memberManage.memberInfo ? <CloudCard
                                    data={memberManage.memberInfo}
                                /> : null
                            }

                        </Card>
                    </div>
                    <div className='custom-card'>
                        <Card
                            bordered={false}
                            title='成员基本信息'
                        >
                            {
                                (!memberManage.memberInfo || memberManage.memberInfo.id !== Number(param.id)) ? null : <BasicInfoForm
                                    isEdit={editStatus}
                                    changeEditStatus={setEditStatus}
                                    data={memberManage?.memberInfo}
                                    doSubmit={doSubmit}
                                    gotoPage={gotoPage}
                                    departmentList={memberManage.partmentList}
                                />
                            }


                        </Card>
                    </div>
                </Card>
            </div>
        </PageHeaderWrapper>
    )
}

export default connect(({ memberManage, loading }) => ({
    memberManage,
    modifyLoading: loading.effects['memberManage/modify']
}))(MemberDetail);
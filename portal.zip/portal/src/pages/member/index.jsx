import React, { useRef, useState, useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Space, Table, Tag, Modal, Popover, message, notification, Input } from 'antd';
import { InfoCircleOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import ProTable from '@ant-design/pro-table';
import { connect } from 'umi';
import moment from 'moment';
import ControledInput from './components/Input';
import ControledRangePicker from './components/ControledRangePicker';
import HandAddForm from './components/HandAddForm';
import BatchImportForm from './components/BatchImportForm';
import { memberList, addMembers, deleteMembers } from './service';

let defaultCurrent = 1;
let defaultPageSize = 20;

const Member = (props) => {
    const { dispatch, memberManage, history } = props;
    const { searchParam } = memberManage;
    const actionRef = useRef();
    const [selectedRow, handleSelectedRow] = useState([]);
    const [selectedRowKeys, handleSelectedRowKeys] = useState([]);
    const [handAddModal, handleHandAddModal] = useState(false);
    const [batchImportModal, handleBatchImportModal] = useState(false);
    const formRef = useRef(null);

    const goToPage = (href, state) => {
        history.push({
            pathname: href,
            state,
        });
    }

    const statusMap = [
        {
            color: 'blue',
            text: '生成中',
        },
        {
            color: 'green',
            text: '已生成',
        },
        {
            color: 'red',
            text: '生成失败',
        },
    ];

    useEffect(() => {
        if (dispatch) {
            dispatch({
                type: 'memberManage/getAllPartment'
            })
        }
    }, []);

    const handleDelete = async (ids) => {
        if (ids.length) {
            Modal.confirm({
                title: '是否确定删除:',
                icon: <QuestionCircleOutlined />,
                content: '删除选中的成员后，将不再为选中的成员提供电子名片服务，确定要进行删除吗？',
                onOk: async () => {
                    const ret = await deleteMembers({
                        ids
                    });
                    if (ret?.success) {
                        notification.success({
                            message: ret.message || '删除成功',
                        });
                        if (actionRef.current) {
                            actionRef.current.reload();
                            handleSelectedRowKeys([]);
                        }
                    } else {
                        notification.error({
                            message: ret.message || '删除失败',
                        });
                    }
                }
            })

        } else {
            Modal.warning({
                title: '操作提示',
                content: '没有可操作的对象，请先在列表中勾选需要操作的对象后再进行操作。',
            });
        }
    }
    const columns = [
        {
            title: '姓名',
            dataIndex: 'fullName',
            key: 'fullName',
            renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
                return (
                    <Input
                        maxLength={10}
                        // regex={/[^\u4e00-\u9fa5a-zA-Z\d]/g}
                        placeholder="请输入姓名"
                        onChange={(value) => {
                            onChange(value)
                        }}
                        {...rest}
                    />
                );
            },
        },
        {
            title: '部门',
            dataIndex: 'department',
            key: 'department',
            renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
                return (
                    <Input
                        maxLength={20}
                        // regex={/[^\u4e00-\u9fa5a-zA-Z]/g}
                        placeholder="请输入部门"
                        onChange={(value) => {
                            onChange(value)
                        }}
                        {...rest}
                    />
                );
            },
        },
        {
            title: '职位',
            dataIndex: 'position',
            key: 'position',
            renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
                return (
                    <Input
                        maxLength={20}
                        // regex={/[^\u4e00-\u9fa5a-zA-Z]/g}
                        placeholder="请输入职位"
                        onChange={(value) => {
                            onChange(value)
                        }}
                        {...rest}
                    />
                );
            },
        },
        {
            title: '手机号码',
            dataIndex: 'phone',
            key: 'phone',
            renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
                return (
                    <ControledInput
                        regex={/[\D]/g}
                        maxLength={11}
                        placeholder="请输入手机号码"
                        onChange={(value) => {
                            onChange(value)
                        }}
                        {...rest}
                    />
                );
            },
        },
        {
            title: '邮箱',
            dataIndex: 'mailbox',
            key: 'mailbox',
            renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
                return (
                    <ControledInput
                        maxLength={50}
                        placeholder="请输入邮箱"
                        onChange={(value) => {
                            onChange(value)
                        }}
                        {...rest}
                    />
                );
            },
        },
        {
            title: '添加时间',
            dataIndex: 'createTime',
            key: 'createTime',
            valueType: 'date',
            renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => <ControledRangePicker onChange={(value) => { onChange(value) }} initialValue={searchParam?.createTime}/>,
        },
        {
            title: '名片状态',
            dataIndex: 'status',
            valueType: 'option',
            key: 'status',
            render: (_, record) => <Tag color={statusMap[Number(record.status) - 1].color}>{statusMap[Number(record.status) - 1].text}</Tag>
        },
        {
            title: '操作',
            valueType: 'option',
            render: (_, record) => [
                Number(record.status) === 2 ?
                    <a
                        key="detail"
                        onClick={() => {
                            goToPage(`/cloudCard/member/details/${record.id}`, { editStatus: false });
                            if (dispatch) {
                                dispatch({
                                    type: 'memberManage/setParam',
                                    payload: {
                                        ...formRef.current.getFieldsValue(),
                                    },
                                })
                            }
                        }}
                    >
                        查看
                </a> : null,
                Number(record.status) === 2 ?
                    <a
                        key="edit"
                        onClick={() => {
                            dispatch({
                                type: 'memberManage/memberDetail',
                                payload: {
                                    id: record.id
                                }
                            });
                            goToPage(`/cloudCard/member/details/${record.id}`, { editStatus: true });
                            if (dispatch) {
                                dispatch({
                                    type: 'memberManage/setParam',
                                    payload: {
                                        ...formRef.current.getFieldsValue(),
                                    },
                                })
                            }
                        }}
                    >
                        修改
                </a> : null,
                Number(record.status) !== 1 ?
                    <a
                        key="delete"
                        onClick={() => {
                            handleDelete([record.id]);
                        }}
                    >
                        删除
                </a> : null
            ],
        },
    ];
    const tips = <div style={{ maxWidth: 600 }}>
        <p>1、手动添加或者批量导入成员后，需要一定时间才能生成名片。</p>
        <p>2、名片生成后方可查看详情、修改、删除。</p>
        <p>3、若您在添加或批量导入成员时认证状态为待审核、审核不通过或名片生成出现异常，则名片状态为生成失败，您需删除相应成员记录后方可重新导入、生成名片。</p>
    </div>
    return (
        <PageHeaderWrapper
            title={
                <>
                    成员列表
                    <Popover content={tips} placement="right">
                        <InfoCircleOutlined className='ml-10' style={{ color: '#1890ff' }} />
                    </Popover>
                </>
            }
        >
            <ProTable
                columns={columns}
                actionRef={actionRef}
                formRef={formRef}
                rowSelection={{
                    selectedRowKeys,
                    onChange: (selectedRowKeys, selectedRow) => {
                        const realSelectRows = selectedRow.filter((item) => item.status != 1);
                        handleSelectedRow(selectedRow);
                        handleSelectedRowKeys(realSelectRows.map((item) => item.id));
                    },
                    getCheckboxProps: record => ({
                        disabled: record.status === 1,
                    }),
                }}
                search={{
                    labelWidth: 'auto',
                    searchText: '查询',
                    resetText: '重置',
                    collapsed: false,
                    optionRender: ({ searchText, resetText }, { form }) => {
                        if (searchParam) {
                            form.setFieldsValue({
                                fullName: searchParam.fullName || '',
                                department: searchParam.department || '',
                                position: searchParam.position || '',
                                phone: searchParam.phone || '',
                                mailbox: searchParam.mailbox || '',
                                createTime: searchParam.createTime || '',
                            });
                        }
                        return (
                            <>
                                <Button
                                    type={'primary'}
                                    onClick={() => {
                                        form.submit();
                                    }}
                                >
                                    {searchText}
                                </Button>
                                <Button
                                    type={'link'}
                                    onClick={() => {
                                        form.resetFields();
                                        form.submit();
                                    }}
                                >
                                    {resetText}
                                </Button>
                            </>
                        );
                    }
                }}
                tableAlertRender={({ selectedRowKeys }) => (
                    <Space size={24}>
                        <span>
                            已选 {selectedRowKeys.length} 项
                        </span>
                    </Space>
                )}
                dataSource={[]}
                options={false}
                rowKey="id"
                headerTitle={[
                    <Button
                        type="primary"
                        key='0'
                        onClick={() => {
                            handleDelete(selectedRowKeys);
                        }}
                    >
                        批量删除
                    </Button>
                ]}
                toolBarRender={(action, { selectedRows }) => [
                    <Button
                        type="primary"
                        key='1'
                        onClick={() => {
                            handleHandAddModal(true)
                        }}
                    >
                        手动添加
                    </Button>,
                    <Button
                        type="primary"
                        key='2'
                        onClick={() => {
                            handleBatchImportModal(true)
                        }}
                    >
                        批量导入
                    </Button>
                ]}
                pagination={{
                    defaultCurrent: searchParam?.current || defaultCurrent,
                    defaultPageSize: searchParam?.pageSize || defaultPageSize,
                }}
                request={
                    params => {
                        if (searchParam) {
                            params.fullName = searchParam.fullName || '';
                            params.department = searchParam.department || '';
                            params.position = searchParam.position || '';
                            params.phone = searchParam.phone || '',
                            params.mailbox = searchParam.mailbox || '',
                            params.createTime = searchParam.createTime || '';
                            if (dispatch) {
                                dispatch({
                                    type: 'memberManage/setParam',
                                    payload: null,
                                })
                            }
                        }
                        params.pageNum = params.current;
                        defaultCurrent = params.current;
                        defaultPageSize = params.pageSize;
                        delete params.current;
                        if (params.createTime) {
                            params.beginTime = moment(params.createTime[0]).format('YYYY-MM-DD');
                            params.endTime = moment(params.createTime[1]).format('YYYY-MM-DD');
                        }
                        delete params.createTime;
                        return memberList(params);
                    }
                }
            />
            <HandAddForm
                partmentList={memberManage.partmentList}
                onSubmit={async (value, callBack) => {
                    const ret = await addMembers(value)
                    if (dispatch) {
                        dispatch({
                            type: 'memberManage/getAllPartment'
                        })
                    }
                    if (ret?.success) {
                        handleHandAddModal(false);
                        if (actionRef.current) {
                            actionRef.current.reload();
                        }
                        notification.success({
                            message: '添加成功！',
                        });
                        callBack && callBack();
                    } else {
                        message.error(ret?.message || '添加失败！')
                    }
                }}
                onCancel={() => handleHandAddModal(false)}
                modalVisible={handAddModal}
            />
            <BatchImportForm
                partmentList={memberManage.partmentList}
                onCancel={() => {
                    handleBatchImportModal(false);
                }}
                onSuccess={() => {
                    handleBatchImportModal(false);
                    if (dispatch) {
                        dispatch({
                            type: 'memberManage/getAllPartment'
                        })
                    }
                    if (actionRef.current) {
                        actionRef.current.reload();
                    }
                }}
                modalVisible={batchImportModal}
            />
        </PageHeaderWrapper>
    )
}
export default connect(({ memberManage, loading }) => ({
    memberManage,
    addMemberLoading: loading.effects['memberManage/addMembers']
}))(Member);

import React, { useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Card, Row, Col, Table } from 'antd';
import { connect,useParams,history } from "umi";
import styles from './style.less';
const columns = [
  {
    title: '产品图',
    dataIndex: 'skuImgs',
    render: (_) => (
      <img
        style={{
          maxWidth:90
        }}
        src={_}
      />
    )
  },
  {
    title: '产品名称',
    dataIndex: 'productName',
    width: 200,
  },
  {
    title: '产品类型',
    dataIndex: 'productType',
    width: 100,
  },
  {
    title: '产品sku',
    dataIndex: 'productSku',
    width: 100,
  },
  {
    title: '价格',
    dataIndex: 'skuPrice',
    width: 100,
  },
  {
    title: '促销价',
    dataIndex: 'skuSalePrice',
    width: 100,
  },
  {
    title: '成本价',
    dataIndex: 'skuCostPrice',
    width: 100,
  },
  {
    title: '规格',
    dataIndex: 'skuProps',
  },
  {
    title: '适用省份',
    dataIndex: 'provinceName',
    width: 100,
  },
  {
    title: '物料编码',
    dataIndex: 'materialCode',
  },
];
const chatbotNameList = [
  {
    label:'和家安防',
    value:1,
  },
  {
    label:'和家视听',
    value:2,
  },
  {
    label:'和家生活',
    value:3,
  },
];
const productStatusList = [
  {
    label:'待上架',
    value:0,
  },
  {
    label:'上架',
    value:1,
  },
  {
    label:'下架',
    value:2,
  },
];

const Details = props => {
  const params = useParams();
  const { dispatch,hardwareProduct,loading } = props;
  useEffect(() => {
    if(dispatch && !loading){
      dispatch({
        type:'hardwareProduct/queryDetails',
        payload:{
          id:Number(params.id)
        }
      })
    }
  },[params.id]);
  const { detailsData } = hardwareProduct;
  if (!detailsData || detailsData.id !== Number(params.id)) {
    return null;
  }
  return (
    <PageHeaderWrapper
      title={"产品详情"}
      content={
        <Button
          style={{float:'right'}}
          onClick={() => history.go(-1)}
        >
          返回
        </Button>
      }
    >
      <Card
        title={"基本信息"}
        headStyle={{
          background:'#ebf3ff'
        }}
      >
        <Row gutter={[24,24]}>
          <Col span={4}>
            <img
              src={detailsData.productLogoImg}
              style={{
                width:'100%'
              }}
            />
          </Col>
          <Col span={20}>
            <Row gutter={[24,24]}>
              <Col span={8}>
                <span>产品编码：</span>
                <span className={styles.text}>{detailsData.productSpu}</span>
              </Col>
              <Col span={8}>
                <span>产品价格：</span>
                <span className={styles.text}>{detailsData.productPrice}</span>
              </Col>
              <Col span={8}>
                <span>产品名称：</span>
                <span className={styles.text}>{detailsData.productName}</span>
              </Col>
            </Row>
            <Row gutter={[24,24]}>
              <Col span={8}>
                <span>产品促销价：</span>
                <span className={styles.text}>{detailsData.productSalePrice}</span>
              </Col>
              <Col span={8}>
                <span>产品库存：</span>
                <span className={styles.text}>{detailsData.productStork}</span>
              </Col>
              <Col span={8}>
                <span>状态：</span>
                <span className={styles.text}>{productStatusList.find(item => item.value === detailsData.productStatus) ? productStatusList.find(item => item.value === detailsData.productStatus).label : '-'}</span>
              </Col>
            </Row>
            <Row gutter={[24,24]}>
              <Col span={24}>
                <span>产品详情：</span>
                <span className={styles.text}>{detailsData.productDesc}</span>
              </Col>
            </Row>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={6}>
            <span>所属业务：</span>
            <span className={styles.text}>
              {chatbotNameList.find(item => item.value === detailsData.chatbotName) ? chatbotNameList.find(item => item.value === detailsData.chatbotName).label : '-'}
            </span>
          </Col>
          <Col span={6}>
            <span>产品保质期：</span>
            <span className={styles.text}>{detailsData.productExpiryDate}</span>
          </Col>
          <Col span={6}>
            <span>是否支持7天无理由退换货：</span>
            <span className={styles.text}>{detailsData.isReturnIn7days}</span>
          </Col>
          <Col span={6}>
            <span>发货地：</span>
            <span className={styles.text}>{detailsData.deliveryPlace}</span>
          </Col>
        </Row>
        <Row gutter={[24,24]}>
          <Col span={6}>
            <span>一级类目名称：</span>
            <span className={styles.text}>{detailsData.fcategoryName}</span>
          </Col>
          <Col span={6}>
            <span>二级类目名称：</span>
            <span className={styles.text}>{detailsData.scategoryName}</span>
          </Col>
          <Col span={6}>
            <span>三级类目名称：</span>
            <span className={styles.text}>{detailsData.tcategoryName}</span>
          </Col>
        </Row>
      </Card>
      <Card
        title={"产品sku信息"}
        headStyle={{
          background:'#ebf3ff'
        }}
      >
        <Table
          bordered
          columns={columns}
          dataSource={detailsData.prodSku}
          pagination={false}
          rowKey={"productSku"}
        />
      </Card>
      <Card
        title={"产品展示图"}
        headStyle={{
          background:'#ebf3ff'
        }}
      >
        {
          detailsData.productImgs && detailsData.productImgs.split(';').map((img,index) => (
            <div key={index}>
              <img
                style={{width:400,marginBottom:20}}
                src={img}
              />
            </div>
          ))
        }
      </Card>
      {
        detailsData.productStatus === 2 ? (
          <Card
            title={"操作意见"}
            headStyle={{
              background:'#ebf3ff'
            }}
          >
            <Row gutter={[24,24]}>
              <Col span={24}>
                <span>操作意见：</span>
                <span className={styles.text}>{detailsData.opinion}</span>
              </Col>
            </Row>
          </Card>
        ) : null
      }
    </PageHeaderWrapper>
  )
}

export default connect(({ hardwareProduct,loading }) => ({
  hardwareProduct,
  loading: loading.effects['hardwareProduct/queryDetails'],
}))(Details);

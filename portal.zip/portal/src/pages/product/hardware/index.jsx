import React, { useRef } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
// import { PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { Button, Card, Select } from 'antd';
import ControledInput from './components/Input';
import { connect,history } from 'umi';
import { queryList } from './service';
// import styles from './style.less';
const { Option } = Select;
let defaultCurrent = 1;
let defaultPageSize = 20;

const Index = props => {

  const { dispatch,hardwareProduct } = props;
  const { searchParam } = hardwareProduct;
  const actionRef = useRef();
  const formRef = useRef(null);
  const productStatusList = [
    {
      label:'全部',
      value:'',
    },
    {
      label:'待上架',
      value:0,
    },
    {
      label:'上架',
      value:1,
    },
    {
      label:'下架',
      value:2,
    },
  ];
  const chatbotNameList = [
    {
      label:'全部',
      value:'',
    },
    {
      label:'和家安防',
      value:1,
    },
    {
      label:'和家视听',
      value:2,
    },
    {
      label:'和家生活',
      value:3,
    },
  ];
  const columns = [
    {
      title: '所属业务',
      dataIndex: 'chatbotName',
      hideInTable: true,
      renderFormItem: (_, { ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              chatbotNameList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
    },
    {
      title: '产品编码',
      dataIndex: 'productSpu',
      ellipsis:true,
      renderFormItem: (_, { onChange,...rest }, form) => {
        return (
          <ControledInput
            maxLength={32}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入产品编码"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '产品主图',
      dataIndex: 'productLogoImg',
      width: 100,
      hideInSearch:true,
      render: (_, record) => (
        <img
          src={_}
          style={{
            width:64,
            height:64
          }}
        />
      )
    },
    {
      title: '产品名称',
      dataIndex: 'productName',
      ellipsis:true,
      renderFormItem: (_, { onChange,...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入产品名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotName',
      hideInSearch: true,
      render: (_, record) => (
        <span>{chatbotNameList.find(item => item.value === _) ? chatbotNameList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '产品价格',
      dataIndex: 'productPrice',
      hideInSearch:true,
    },
    {
      title: '产品促销价',
      dataIndex: 'productSalePrice',
      hideInSearch:true,
    },
    {
      title: '产品状态',
      dataIndex: 'productStatus',
      hideInTable: true,
      renderFormItem: (_, { ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              productStatusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
    },
    {
      title: '状态',
      dataIndex: 'productStatus',
      hideInSearch: true,
      render: (_, record) => (
        <span>{productStatusList.find(item => item.value === _) ? productStatusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      hideInSearch:true,
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
          <a
            onClick={() => {
              if (dispatch) {
                dispatch({
                  type:'hardwareProduct/setParam',
                  payload:{
                    ...formRef.current.getFieldsValue(),
                    current:defaultCurrent,
                    pageSize:defaultPageSize,
                  },
                })
              }
              history.push(`/layouts/product/hardware/details/${record.id}`)
            }}
          >
            详情
          </a>
        </>
      ),
    },
  ];

  return (
    <PageHeaderWrapper
      title={"产品列表"}
    >
      <Card>
        <ProTable
          actionRef={actionRef}
          columns={columns}
          formRef={formRef}
          options={false}
          pagination={{
            defaultCurrent:searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize:searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          rowKey="id"
          request={
            (params, sorter, filter) => {
              if (searchParam) {
                params.chatbotName = searchParam.chatbotName;
                params.productSpu = searchParam.productSpu;
                params.productName = searchParam.productName;
                params.productStatus = searchParam.productStatus;
                if (dispatch) {
                  dispatch({
                    type:'hardwareProduct/setParam',
                    payload:null,
                  })
                }
              }
              params.pageNum = params.current;
              defaultCurrent = params.current;
              defaultPageSize = params.pageSize;
              delete params.current;
              delete params.createTime;
              return queryList(params)
            }
          }
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              if (searchParam) {
                form.setFieldsValue({
                  chatbotName : searchParam.chatbotName,
                  productSpu : searchParam.productSpu,
                  productName : searchParam.productName,
                  productStatus : searchParam.productStatus,
                });
              }
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
        />
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ hardwareProduct, loading }) => ({
  hardwareProduct,
  loading: loading.effects['hardwareProduct/queryList'],
}))(Index);

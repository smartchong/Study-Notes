import request from '@/utils/request';
import API from '../../../services/api';

// 列表查询
export async function queryList(params) {
  return request(`${API.PRODUCT.HARDWARE.LIST}`, {
    method: 'POST',
    data: params,
  });
}

// 产品详情
export async function queryDetails(params) {
  return request(`${API.PRODUCT.HARDWARE.DETAILS}`, {
    params,
  });
}

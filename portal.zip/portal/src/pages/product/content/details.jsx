import React, { useEffect, useState } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import PreviewModal from './components/PreviewModal';
import copy from "copy-to-clipboard";
import { Button, Card, Row, Col,message} from 'antd';
import { connect, useParams, history } from "umi";
import styles from './style.less';
const chatbotNameList = [
  {
    label: '和家安防',
    value: 1,
  },
  {
    label: '和家视听',
    value: 2,
  },
  {
    label: '和家生活',
    value: 3,
  },
];
const productStatusList = [
  {
    label: '待上架',
    value: 0,
  },
  {
    label: '上架',
    value: 1,
  },
  {
    label: '下架',
    value: 2,
  },
];

const Details = props => {
  const [url, handleUrl] = useState('');
  const [modal, handleModal] = useState(false);
  const params = useParams();
  const { dispatch, contentProduct, loading } = props;
  useEffect(() => {
    if (dispatch && !loading) {
      dispatch({
        type: 'contentProduct/queryDetails',
        payload: {
          id: Number(params.id)
        }
      })
    }
  }, [params.id]);
  const { detailsData } = contentProduct;
  if (!detailsData || detailsData.id !== Number(params.id)) {
    return null;
  }
  return (
    <PageHeaderWrapper
      title={"产品详情"}
      content={
        <Button
          style={{ float: 'right' }}
          onClick={() => history.go(-1)}
        >
          返回
        </Button>
      }
    >
      <Card
        title={"基本信息"}
        headStyle={{
          background: '#ebf3ff'
        }}
      >
        <Row gutter={[24, 24]}>
          <Col span={4}>
            <img
              src={detailsData.prodLogoImg}
              style={{
                width: '100%'
              }}
            />
          </Col>
          <Col span={20}>
            <Row gutter={[24, 24]}>
              <Col span={12}>
                <span>产品编码：</span>
                <span className={styles.text}>{detailsData.prodCode}</span>
              </Col>
              <Col span={12}>
                <span>产品价格：</span>
                <span className={styles.text}>{detailsData.prodPrice}</span>
              </Col>
            </Row>
            <Row gutter={[24, 24]}>
              <Col span={12}>
                <span>产品名称：</span>
                <span className={styles.text}>{detailsData.prodName}</span>
              </Col>
              <Col span={12}>
                <span>产品促销价：</span>
                <span className={styles.text}>{detailsData.prodSalePrice}</span>
              </Col>
            </Row>
            <Row gutter={[24, 24]}>
              <Col span={12}>
                <span>产品备注：</span>
                <span className={styles.text}>{detailsData.prodRemarks}</span>
              </Col>
              <Col span={12}>
                <span>产品状态：</span>
                <span className={styles.text}>{productStatusList.find(item => item.value === detailsData.prodStatus) ? productStatusList.find(item => item.value === detailsData.prodStatus).label : '-'}</span>
              </Col>
            </Row>
            <Row gutter={[24, 24]}>
              <Col span={12}>
                <span>所属业务：</span>
                <span className={styles.text}>
                  {chatbotNameList.find(item => item.value === detailsData.chatbotName) ? chatbotNameList.find(item => item.value === detailsData.chatbotName).label : '-'}
                </span>
              </Col>
              {
                detailsData.prodStatus === 1 ? (
                  <Col span={12}>
                    <span>产品详情预览信息：</span>

                    <a
                      onClick={() => {
                        handleUrl(detailsData.prodLink);
                        handleModal(true);
                      }}
                    >
                    {detailsData.prodLink}
                    </a>
                  </Col>
                ) : null
              }

            </Row>
          </Col>
        </Row>
        <Row gutter={[24, 24]}>
          <Col span={24}>
            <span>产品描述：</span>
            <span className={styles.text}>{detailsData.prodDesc}</span>
          </Col>
        </Row>
      </Card>
      {
        detailsData.prodStatus === 2 ? (
          <Card
            title={"操作意见"}
            headStyle={{
              background: '#ebf3ff'
            }}
          >
            <Row gutter={[24, 24]}>
              <Col span={24}>
                <span>操作意见：</span>
                <span className={styles.text}>{detailsData.opinion}</span>
              </Col>
            </Row>
          </Card>
        ) : null
      }
      <PreviewModal
        onCopy={() => {
          copy(url);
          message.success("已复制到剪贴板！");
        }}
        onCancel={() => handleModal(false)}
        modalVisible={modal}
      >
        <div className={styles.iframeWrap}>
          <iframe
            className={styles.iframe}
            src={url}
            frameBorder="0"
            scrolling="no"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
          />
        </div>
      </PreviewModal>
    </PageHeaderWrapper>
  )
}

export default connect(({ contentProduct, loading }) => ({
  contentProduct,
  loading: loading.effects['contentProduct/queryDetails'],
}))(Details);

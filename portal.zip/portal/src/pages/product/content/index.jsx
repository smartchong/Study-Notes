import React, { useState, useRef } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
// import { PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { Button, Card, Select, message } from 'antd';
import copy from "copy-to-clipboard";
import ControledInput from './components/Input';
import PreviewModal from './components/PreviewModal';
import { connect, history } from 'umi';
import { queryList } from './service';
import styles from './style.less';
const { Option } = Select;
let defaultCurrent = 1;
let defaultPageSize = 20;

const Index = props => {

  const [url, handleUrl] = useState('');
  const [modal, handleModal] = useState(false);
  const { dispatch, contentProduct } = props;
  const { searchParam } = contentProduct;
  const actionRef = useRef();
  const formRef = useRef(null);
  const prodStatusList = [
    {
      label: '全部',
      value: '',
    },
    {
      label: '待上架',
      value: 0,
    },
    {
      label: '上架',
      value: 1,
    },
    {
      label: '下架',
      value: 2,
    },
  ];
  const chatbotNameList = [
    {
      label: '全部',
      value: '',
    },
    {
      label: '和家安防',
      value: 1,
    },
    {
      label: '和家视听',
      value: 2,
    },
    {
      label: '和家生活',
      value: 3,
    },
  ];
  const columns = [
    {
      title: '所属业务',
      dataIndex: 'chatbotName',
      hideInTable: true,
      renderFormItem: (_, { ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              chatbotNameList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
    },
    {
      title: '产品编码',
      width: 100,
      dataIndex: 'prodCode',
      ellipsis: true,
      renderFormItem: (_, { onChange, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={32}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入产品编码"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '产品主图',
      dataIndex: 'prodLogoImg',
      width: 100,
      hideInSearch: true,
      render: (_, record) => (
        <img src={_} style={{ width: 64, height: 64 }} />
      )
    },
    {
      title: '产品名称',
      width: 100,
      dataIndex: 'prodName',
      ellipsis: true,
      renderFormItem: (_, { onChange, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入产品名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属业务',
      width: 100,
      dataIndex: 'chatbotName',
      hideInSearch: true,
      render: (_, record) => (
        <span>{chatbotNameList.find(item => item.value === _) ? chatbotNameList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '产品价格',
      width: 100,
      dataIndex: 'prodPrice',
      hideInSearch: true,
    },
    {
      title: '产品促销价',
      width: 100,
      dataIndex: 'prodSalePrice',
      hideInSearch: true,
    },
    {
      title: '备注',
      width: 100,
      dataIndex: 'prodRemarks',
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '产品状态',
      width: 100,
      dataIndex: 'prodStatus',
      hideInTable: true,
      renderFormItem: (_, { ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              prodStatusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
    },
    {
      title: '状态',
      width: 100,
      dataIndex: 'prodStatus',
      hideInSearch: true,
      render: (_, record) => (
        <span>{prodStatusList.find(item => item.value === _) ? prodStatusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '产品详情链接',
      width: 100,
      dataIndex: 'prodLink',
      ellipsis: true,
      hideInSearch: true,
      render: (_, record) => (
        <a
          onClick={() => {
            if (record.prodLink === '--') {
            } else {
              handleUrl(record.prodLink);
              handleModal(true);
            }
          }}
        >{_}</a>
      )
    },
    {
      title: '创建时间',
      width: 100,
      dataIndex: 'createTime',
      hideInSearch: true,
    },
    {
      title: '操作',
      width: 100,
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
          <a
            onClick={() => {
              if (dispatch) {
                dispatch({
                  type: 'contentProduct/setParam',
                  payload: {
                    ...formRef.current.getFieldsValue(),
                    current: defaultCurrent,
                    pageSize: defaultPageSize,
                  },
                })
              }
              history.push(`/layouts/product/content/details/${record.id}`)
            }}
          >
            详情
          </a>
        </>
      ),
    },
  ];

  return (
    <PageHeaderWrapper
      title={"产品列表"}
    >
      <Card>
        <ProTable
          actionRef={actionRef}
          columns={columns}
          formRef={formRef}
          options={false}
          pagination={{
            defaultCurrent: searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize: searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          rowKey="id"
          request={
            (params, sorter, filter) => {
              if (searchParam) {
                params.chatbotName = searchParam.chatbotName;
                params.prodCode = searchParam.prodCode;
                params.prodName = searchParam.prodName;
                params.prodStatus = searchParam.prodStatus;
                if (dispatch) {
                  dispatch({
                    type: 'contentProduct/setParam',
                    payload: null,
                  })
                }
              }
              params.pageNum = params.current;
              defaultCurrent = params.current;
              defaultPageSize = params.pageSize;
              delete params.current;
              delete params.createTime;
              return queryList(params)
            }
          }
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              if (searchParam) {
                form.setFieldsValue({
                  chatbotName: searchParam.chatbotName,
                  prodCode: searchParam.prodCode,
                  prodName: searchParam.prodName,
                  prodStatus: searchParam.prodStatus,
                });
              }
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
        />
      </Card>
      <PreviewModal
        onCopy={() => {
          copy(url);
          message.success("已复制到剪贴板！");
        }}
        onCancel={() => handleModal(false)}
        modalVisible={modal}
      >
        <div className={styles.iframeWrap}>
          <iframe
            className={styles.iframe}
            src={url}
            frameBorder="0"
            scrolling="no"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
          />
        </div>
      </PreviewModal>
    </PageHeaderWrapper>
  )
}

export default connect(({ contentProduct, loading }) => ({
  contentProduct,
  loading: loading.effects['contentProduct/queryList'],
}))(Index);

import React, { useState, useRef, useEffect } from 'react';
import { connect, history } from 'umi';
import { Card, Button, Select } from 'antd';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import ControledInput from './components/Input';
import ControledRangePicker from './components/RangePicker';
import { queryList } from './service';
import styles from './style.less';
const { Option } = Select;
let defaultCurrent = 1;
let defaultPageSize = 20;

const Index = (props) => {
  const actionRef = useRef();
  const formRef = useRef(null);
  const {
    dispatch,
    hardwareOrder,
  } = props;
  const { searchParam } = hardwareOrder;
  const orderStatusList = [
    {
      label: '全部',
      value: '',
    },
    {
      label: '待支付',
      value: 2,
    },
    {
      label: '待发货',
      value: 0,
    },
    {
      label: '待收货',
      value: 4,
    },
    {
      label: '已收货',
      value: 8,
    },
    {
      label: '取消订单',
      value: 3,
    },
    {
      label: '超时关闭',
      value: 9,
    },
  ];
  const chatbotNameList = [
    {
      label: '全部',
      value: '',
    },
    {
      label: '和家安防',
      value: 1,
    },
    {
      label: '和家视听',
      value: 2,
    },
    {
      label: '和家生活',
      value: 3,
    },
  ];
  const columns = [
    {
      title: '订单编号',
      dataIndex: 'channelOrderId',
      width: 100,
      ellipsis: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={32}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入订单编号"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '购买人手机号码',
      dataIndex: 'buyerPhoneNum',
      hideInTable: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={11}
            regex={/[^\d]/g}
            placeholder="请输入购买人手机号码"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '收件人手机号码',
      dataIndex: 'receiverPhoneNum',
      hideInTable: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={11}
            regex={/[^\d]/g}
            placeholder="请输入收件人手机号码"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotName',
      hideInTable: true,
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              chatbotNameList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{chatbotNameList.find(item => item.value === _) ? chatbotNameList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '商品',
      dataIndex: 'goodsName',
      width: 80,
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '价格',
      dataIndex: 'goodsPrice',
      width: 80,
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '数量',
      dataIndex: 'goodsCount',
      width: 60,
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotName',
      width: 100,
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '收件人手机号码',
      width: 100,
      dataIndex: 'receiverPhoneNum',
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '购买人',
      width: 100,
      dataIndex: 'buyerPhoneNum',
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '支付金额',
      dataIndex: 'price',
      width: 80,
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '订单状态',
      dataIndex: 'orderStatus',
      width: 100,
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              orderStatusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{orderStatusList.find(item => item.value === _) ? orderStatusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '下单时间',
      dataIndex: 'orderTime',
      width: 150,
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '支付时间',
      dataIndex: 'payTime',
      width: 150,
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      width: 100,
      render: (_, record) => (
        <>
          <a
            onClick={() => {
              if (dispatch) {
                dispatch({
                  type: 'hardwareOrder/setParam',
                  payload: {
                    ...formRef.current.getFieldsValue(),
                    current: defaultCurrent,
                    pageSize: defaultPageSize,
                  },
                })
              }
              history.push(`/layouts/order/hardware/details/${record.id}`)
            }}
          >
            详情
          </a>
        </>
      ),
    },
  ];

  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <ProTable
          headerTitle=""
          actionRef={actionRef}
          formRef={formRef}
          rowKey="id"
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              if (searchParam) {
                form.setFieldsValue({
                  channelOrderId: searchParam.channelOrderId,
                  buyerPhoneNum: searchParam.buyerPhoneNum,
                  receiverPhoneNum: searchParam.receiverPhoneNum,
                  chatbotName: searchParam.chatbotName,
                  orderStatus:searchParam.orderStatus,
                  orderTime:searchParam.orderTime,
                  payTime:searchParam.payTime
                });
              }
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    id={'resetBtn'}
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          rowSelection={false}
          options={false}
          pagination={{
            defaultCurrent: searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize: searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          tableAlertRender={false}
          request={
            params => {
              if (searchParam) {
                Object.entries(searchParam).forEach(([key, value]) => {
                  params[key] = value;
                })
                if (dispatch) {
                  dispatch({
                    type: 'hardwareOrder/setParam',
                    payload: null,
                  })
                }
              }
              params.beginTime = params.orderTime && params.orderTime.length ? params.orderTime[0] : null;
              params.endTime = params.orderTime && params.orderTime.length ? params.orderTime[1] : null;
              params.beginPayTime = params.payTime && params.payTime.length ? params.payTime[0] : '';
              params.endPayTime = params.payTime && params.payTime.length ? params.payTime[1] : '';
              params.pageNum = params.current;
              params.pageSize = params.pageSize;
              defaultCurrent = params.current;
              defaultPageSize = params.pageSize;
              delete params.current;
              delete params.orderTime;
              delete params.payTime;
              return queryList(params)
            }
          }
          columns={columns}
        />
      </Card>
    </PageHeaderWrapper>
  );
};

export default connect(({ hardwareOrder }) => ({
  hardwareOrder
}))(Index);

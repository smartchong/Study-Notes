import React, { useEffect ,useState} from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Card, Row, Col, Tabs, Table, Steps ,message} from 'antd';
import PreviewModal from './components/PreviewModals';
import copy from "copy-to-clipboard";
import { ShoppingCartOutlined ,CopyOutlined} from '@ant-design/icons';
import { connect, useParams, history } from "umi";
import styles from './style.less';
const { TabPane } = Tabs;
const { Step } = Steps;
const statusList = [
    {
        label: '全部',
        value: '',
    },
    {
        label: '待支付',
        value: 2,
    },
    {
        label: '待发货',
        value: 0,
    },
    {
        label: '待收货',
        value: 4,
    },
    {
        label: '已收货',
        value: 8,
    },
    {
        label: '取消订单',
        value: 3,
    },
    {
        label: '超时关闭',
        value: 9,
    },
];
const Details = props => {
    const [modal, handleModal] = useState(false);
    const params = useParams();
    const { dispatch, hardwareOrder, loading } = props;
    useEffect(() => {
        if (dispatch && !loading) {
            dispatch({
                type: 'hardwareOrder/queryDetails',
                payload: {
                    id: Number(params.id)
                }
            })
        }
    }, [params.id]);
    const { detailsData } = hardwareOrder;
    if (!detailsData || detailsData.id !== Number(params.id)) {
        return null;
    }
    return (
        <PageHeaderWrapper
            title={"产品详情"}
            content={
                <Button
                    style={{ float: 'right' }}
                    onClick={() => history.go(-1)}
                >
                    返回
                </Button>
            }
        >
            <Card >
                <Row gutter={[24, 24]}>
                    <Col span={8}>
                        <span>订单编号：</span>
                        <span className={styles.text}>{detailsData.channelOrderId}</span>
                    </Col>
                    <Col span={8}>
                        <span>下单时间：</span>
                        <span className={styles.text}>{detailsData.orderTime}</span>
                    </Col>
                    <Col span={8}>
                        <span>订单状态：</span>
                        <span className={styles.text}>
                            {statusList.find(item => item.value === detailsData.orderStatus) ? statusList.find(item => item.value === detailsData.orderStatus).label : '-'}
                        </span>
                    </Col>
                </Row>
                <Row gutter={[24, 24]}>
                    <Col span={8}>
                        <span>购买人：</span>
                        <span className={styles.text}>{detailsData.receiverPhoneNum}</span>
                    </Col>
                    <Col span={8}>
                        <span>支付时间：</span>
                        <span className={styles.text}>{detailsData.payTime}</span>
                    </Col>
                </Row>
                <Tabs defaultActiveKey="1">

                    <TabPane tab="订单信息" key="1">
                        <table border="1"cellSpacing="0">
                            <tr>
                                <th style={{ width: 218, textAlign: 'center' }}>商品</th>
                                <th style={{ width: 80, textAlign: 'center' }}>价格</th>
                                <th style={{ width: 46, textAlign: 'center' }}>数量</th>
                                <th style={{ width: 80, textAlign: 'center' }}>所属业务</th>
                                <th style={{ width: 80, textAlign: 'center' }}>商品总价</th>
                                <th style={{ width: 80, textAlign: 'center' }}>商品优惠</th>
                                {/* <th style={{ width: 80, textAlign: 'center' }}>运费</th> */}
                                <th style={{ width: 80, textAlign: 'center' }}>支付金额</th>
                            </tr>
                            <tr>
                                <td style={{ height: 70 }}>
                                    <div style={{ display: 'flex' }}>
                                        <img src={detailsData.goodsImg} alt="" style={{ width: 65, height: 65 }} />
                                        <div style={{ marginTop: 25 }}>{detailsData.goodsName}</div>
                                    </div>
                                </td>
                                <td style={{ textAlign: 'center' }}>{detailsData.goodsPrice}</td>
                                <td style={{ textAlign: 'center' }}>{detailsData.goodsCount}</td>
                                <td style={{ textAlign: 'center' }}>{detailsData.chatbotName}</td>
                                <td style={{ textAlign: 'center' }}>{detailsData.saleAmount}</td>
                                <td style={{ textAlign: 'center' }}>{detailsData.discount}</td>
                                {/* <td style={{ textAlign: 'center' }}>{detailsData.price}</td> */}
                                <td style={{ textAlign: 'center' }}>{detailsData.price}</td>
                            </tr>
                        </table>
                    </TabPane>
                    <TabPane tab="物流信息" key="2">
                        <div className={styles.title_card}>收货人信息</div>
                        <Row gutter={[24, 24]}>
                            <Col span={8}>
                                <span>收件人：</span>
                                <span className={styles.text}>{detailsData.orderLogistics.receiverName}</span>
                            </Col>
                        </Row>
                        <Row gutter={[24, 24]}>
                            <Col span={8}>
                                <span>联系电话：</span>
                                <span className={styles.text}>{detailsData.receiverPhoneNum}</span>
                            </Col>
                        </Row>
                        <Row gutter={[24, 24]}>
                            <Col span={8}>
                                <span>收货地址：</span>
                                <span className={styles.text}>{detailsData.shippingAddress}</span>
                            </Col>
                        </Row>
                        <div className={styles.title_card}>物流信息</div>
                        {
                            detailsData.orderStatus === 0 || detailsData.orderStatus === 4 || detailsData.orderStatus === 8 ? (
                                <div>
                                    <Row gutter={[24, 24]}>
                                        <Col span={8}>
                                            <span>物流公司：</span>
                                            <span className={styles.text}>{detailsData.orderLogistics.transportCompany}</span>
                                        </Col>
                                    </Row>
                                    <Row gutter={[24, 24]}>
                                        <Col span={8}>
                                            <span>运单号：</span>
                                            <span className={styles.text}>{detailsData.orderLogistics.transportNum}</span>
                                            <a
                                                style={{marginLeft:10}}
                                                onClick={() => {
                                                    handleModal(true);
                                                }}
                                            > 
                                            <CopyOutlined style={{fontSize:18}}/>
                                            </a>
                                        </Col>
                                    </Row>
                                    <Steps direction="vertical" current={1}>
                                        {
                                            detailsData.orderLogistics.logistics.map(item =>
                                                <Step description={item.type + '，' + item.address + '，' + item.time} icon={<ShoppingCartOutlined />} />
                                            )
                                        }
                                    </Steps>
                                </div>
                            ) : (
                                    <div className={styles.order}>
                                        <ShoppingCartOutlined className={styles.icon} />
                                        <p>该订单未发货，暂无物流信息！</p>
                                    </div>
                                )
                        }
                    </TabPane>
                </Tabs>
            </Card>
            <PreviewModal
                onCopy={() => {
                    copy(url);
                    message.success("已复制到剪贴板！");
                }}
                onCancel={() => handleModal(false)}
                modalVisible={modal}
            >
            </PreviewModal>
        </PageHeaderWrapper>
    )
}

export default connect(({ hardwareOrder, loading }) => ({
    hardwareOrder,
    loading: loading.effects['hardwareOrder/queryDetails'],
}))(Details);

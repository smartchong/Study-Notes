import { notification } from 'antd';
import { queryList,queryDetails } from './service';

const Model = {
  namespace: 'contentOrder',
  state: {
    tableData:{},
    searchParam:null,
    detailsData:null,
  },
  effects: {
    // *queryList({ payload }, { call, put }) {
    //   const response = yield call(queryList, payload);
    //   yield put({
    //     type: 'setList',
    //     payload: response,
    //   });
    //   if (!response.success) {
    //     notification.error({
    //       message: response.message || '操作失败',
    //     });
    //   }
    // },
    *queryDetails({ payload }, { call, put }) {
      const response = yield call(queryDetails, payload);
      yield put({
        type: 'setDetails',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
  },
  reducers: {
    // setList(state, { payload }) {
    //   return { ...state,tableData: payload };
    // },
    setDetails(state, { payload }) {
      return { ...state, detailsData:payload.data };
    },
    setParam(state, { payload }) {
      return { ...state,searchParam: payload };
    },
  },
};

export default Model;

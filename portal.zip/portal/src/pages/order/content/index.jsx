import React, { useState, useRef, useEffect } from 'react';
import { connect, history } from 'umi';
import { Card, Button, Select } from 'antd';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import ControledInput from './components/Input';
import ControledRangePicker from './components/RangePicker';
import { queryList } from './service';
import styles from './style.less';
const { Option } = Select;
let defaultCurrent = 1;
let defaultPageSize = 20;

const Index = (props) => {
  const actionRef = useRef();
  const formRef = useRef(null);
  const {
    dispatch,
    contentOrder,
  } = props;
  const { searchParam } = contentOrder;
  const statusList = [
    {
      label: '全部',
      value: '',
    },
    {
      label: '订购中',
      value: 0,
    },
    {
      label: '订购成功',
      value: 1,
    },
    {
      label: '订购失败',
      value: 2,
    },
  ];
  const payTypeList = [
    {
      label: '全部',
      value: '',
    },
    {
      label: '支付宝',
      value: 1,
    },
    {
      label: '微信',
      value: 2,
    },
    {
      label: '话费支付',
      value: 4,
    },
    {
      label: '和包',
      value: 5,
    },
    {
      label: '兑换券',
      value: 6,
    },
  ];
  const chatbotNameList = [
    {
      label: '全部',
      value: '',
    },
    {
      label: '和家安防',
      value: 1,
    },
    {
      label: '和家视听',
      value: 2,
    },
    {
      label: '和家生活',
      value: 3,
    },
  ];
  const columns = [
    {
      title: '订单编号',
      dataIndex: 'orderId',
      width: 100,
      ellipsis: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={32}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入订单编号"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '产品名称',
      dataIndex: 'prodName',
      ellipsis: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入产品名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '产品编码',
      dataIndex: 'prodCode',
      ellipsis: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={32}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入产品编码"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotName',
      hideInTable: true,
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              chatbotNameList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{chatbotNameList.find(item => item.value === _) ? chatbotNameList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '购买人',
      dataIndex: 'buyerPhoneNum',
      ellipsis: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={11}
            regex={/[^\d]/g}
            placeholder="请输入购买人手机号码"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '订单状态',
      width:100,
      dataIndex: 'status',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              statusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{statusList.find(item => item.value === _) ? statusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '支付方式',
      width:100,
      dataIndex: 'payType',
      hideInSearch: true,
      renderFormItem: (_, { ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              payTypeList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{payTypeList.find(item => item.value === _) ? payTypeList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '支付金额',
      width:100,
      dataIndex: 'payAmount',
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '下单时间',
      dataIndex: 'orderTime',
      width: 180,
      renderFormItem: (_, { ...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '支付时间',
      dataIndex: 'payTime',
      width: 180,
      renderFormItem: (_, { ...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '操作',
      width:100,
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
          <a
            onClick={() => {
              if (dispatch) {
                dispatch({
                  type: 'contentOrder/setParam',
                  payload: {
                    ...formRef.current.getFieldsValue(),
                    current: defaultCurrent,
                    pageSize: defaultPageSize,
                  },
                })
              }
              history.push(`/layouts/order/content/details/${record.id}`)
            }}
          >
            详情
          </a>
        </>
      ),
    },
  ];

  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <ProTable
          headerTitle=""
          actionRef={actionRef}
          formRef={formRef}
          rowKey="id"
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              if (searchParam) {
                form.setFieldsValue({
                  orderId: searchParam.orderId,
                  prodName: searchParam.prodName,
                  prodCode: searchParam.prodCode,
                  chatbotName: searchParam.chatbotName,
                  buyerPhoneNum:searchParam.buyerPhoneNum,
                  status:searchParam.status,
                  orderTime:searchParam.orderTime,
                  payTime:searchParam.payTime
                });
              }
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    id={'resetBtn'}
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          rowSelection={false}
          options={false}
          pagination={{
            defaultCurrent: searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize: searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          tableAlertRender={false}
          request={
            params => {
              if (searchParam) {
                Object.entries(searchParam).forEach(([key, value]) => {
                  params[key] = value;
                })
                if (dispatch) {
                  dispatch({
                    type: 'contentOrder/setParam',
                    payload: null,
                  })
                }
              }
              params.beginTime = params.orderTime && params.orderTime.length ? params.orderTime[0] : null;
              params.endTime = params.orderTime && params.orderTime.length ? params.orderTime[1] : null;
              params.beginPayTime = params.payTime && params.payTime.length ? params.payTime[0] : '';
              params.endPayTime = params.payTime && params.payTime.length ? params.payTime[1] : '';
              params.pageNum = params.current;
              params.pageSize = params.pageSize;
              defaultCurrent = params.current;
              defaultPageSize = params.pageSize;
              delete params.current;
              delete params.orderTime;
              delete params.payTime;
              return queryList(params)
            }
          }
          columns={columns}
        />
      </Card>
    </PageHeaderWrapper>
  );
};

export default connect(({ contentOrder }) => ({
  contentOrder
}))(Index);

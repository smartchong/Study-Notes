import React, { useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Card, Row, Col } from 'antd';
import { connect, useParams, history } from "umi";
import styles from './style.less';
const chatbotNameList = [
  {
    label: '和家安防',
    value: 1,
  },
  {
    label: '和家视听',
    value: 2,
  },
  {
    label: '和家生活',
    value: 3,
  },
];
const statusList = [
  {
    label: '订购中',
    value: 0,
  },
  {
    label: '订购成功',
    value: 1,
  },
  {
    label: '订购失败',
    value: 2,
  },
];
const payTypeList = [
  {
    label: '支付宝',
    value: 1,
  },
  {
    label: '微信',
    value: 2,
  },
  {
    label: '话费支付',
    value: 4,
  },
  {
    label: '和包',
    value: 5,
  },
  {
    label: '兑换券',
    value: 6,
  },
];

const Details = props => {
  const params = useParams();
  const { dispatch, contentOrder, loading } = props;
  useEffect(() => {
    if (dispatch && !loading) {
      dispatch({
        type: 'contentOrder/queryDetails',
        payload: {
          id: Number(params.id)
        }
      })
    }
  }, [params.id]);
  const { detailsData } = contentOrder;
  if (!detailsData || detailsData.id !== Number(params.id)) {
    return null;
  }
  return (
    <PageHeaderWrapper
      title={"产品详情"}
      content={
        <Button
          style={{ float: 'right' }}
          onClick={() => history.go(-1)}
        >
          返回
        </Button>
      }
    >
      <Card>
        <Row gutter={[24, 24]}>
          <Col span={8}>
            <span>订单编号：</span>
            <span className={styles.text}>{detailsData.orderId}</span>
          </Col>
          <Col span={8}>
            <span>产品名称：</span>
            <span className={styles.text}>{detailsData.prodName}</span>
          </Col>
          <Col span={8}>
            <span>产品编码：</span>
            <span className={styles.text}>{detailsData.prodCode}</span>
          </Col>
        </Row>
        <Row gutter={[24, 24]}>
          <Col span={8}>
            <span>所属业务：</span>
            <span className={styles.text}>
              {chatbotNameList.find(item => item.value === detailsData.chatbotName) ? chatbotNameList.find(item => item.value === detailsData.chatbotName).label : '-'}
            </span>
          </Col>
          <Col span={8}>
            <span>购买人：</span>
            <span className={styles.text}>{detailsData.buyerPhoneNum}</span>
          </Col>
          <Col span={8}>
            <span>订单状态：</span>
            <span className={styles.text}>
              {statusList.find(item => item.value === detailsData.status) ? statusList.find(item => item.value === detailsData.status).label : '-'}
            </span>
          </Col>
        </Row>
        <Row gutter={[24, 24]}>
        <Col span={8}>
            <span>下单时间：</span>
            <span className={styles.text}>{detailsData.orderTime}</span>
          </Col>
          <Col span={8}>
            <span>支付方式：</span>
            <span className={styles.text}>
              {payTypeList.find(item => item.value === detailsData.payType) ? payTypeList.find(item => item.value === detailsData.payType).label : '-'}
            </span>
          </Col>
          <Col span={8}>
            <span>支付金额：</span>
            <span className={styles.text}>{detailsData.payAmount}</span>
          </Col>
        </Row>
        <Row gutter={[24, 24]}>
          <Col span={8}>
            <span>支付时间：</span>
            <span className={styles.text}>{detailsData.payTime}</span>
          </Col>
        </Row>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ contentOrder, loading }) => ({
  contentOrder,
  loading: loading.effects['contentOrder/queryDetails'],
}))(Details);

import API from '../../../services/api';

const result = {
  message:'成功',
  code:1,
  success:true,
};

const arr = [
  {id:Math.floor(Math.random()*100),text:'阿萨四大皆空'},
  {id:Math.floor(Math.random()*100),text:'阿萨四大皆空1'},
  {id:'zxc00009',text:'阿萨四大皆空2'},
]

export default {
  [`POST ${API.MASSSEND.SEND}`]: {
    ...result,
    data:{}
  },
  [`GET ${API.MASSSEND.QUERY_APP_LIST}`]: {
    ...result,
    data:arr
  },
  [`GET ${API.MASSSEND.QUERY_TEMPLATE_LIST}`]: {
    ...result,
    data:arr
  },
};

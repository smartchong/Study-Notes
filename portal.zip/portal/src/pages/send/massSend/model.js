import { message,notification } from 'antd';
import { send,queryGroupList,queryTemplates,queryH5Templates } from './service';

const Model = {
  namespace: 'massSend',
  state: {
    recipientGroupList:[],
    temSelectList:[],
    H5TemSelectList:[],
  },
  effects: {
    *fetchSend({payload,callback,reset}, { call, put }) {
      try {
        const response = yield call(send,payload);
        if(response && response.success){
          callback();
          reset();
          yield put({
            type: 'send',
            payload: response,
          });
          message.success('发送成功');
        }else {
          callback();
          notification.error({
            message: response.message || '操作失败',
          });
        }
        return true;
      } catch (error) {
        callback();
        notification.error({
          message: '操作失败',
        });
        return false;
      }
    },
    *queryRecipientGroupRule({ payload }, { call, put }) {
      const response = yield call(queryGroupList, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      } else {
        yield put({
          type: 'setRecipientGroupList',
          payload: response,
        });
      }
    },
    *queryTemSelectList({ payload },{ call, put }) {
      const response = yield call(queryTemplates, payload);
      if (!response.success) {
        // notification.error({
        //   message: response.message || '操作失败',
        // });
        yield put({
          type: 'setTemSelectList',
          payload: {data: []},
        });
      } else {
        yield put({
          type: 'setTemSelectList',
          payload: response,
        });
      }
    },
    *queryH5TemSelectList({ payload },{ call, put }) {
      const response = yield call(queryH5Templates, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      } else {
        yield put({
          type: 'setH5TemSelectList',
          payload: response,
        });
      }
    }
  },
  reducers: {
    send(state, { payload }) {
      return { ...state, ...payload };
    },
    setRecipientGroupList(state, { payload }) {
      return { ...state, recipientGroupList: payload.data };
    },
    setTemSelectList(state, { payload }) {
      return { ...state, temSelectList: payload.data };
    },
    setH5TemSelectList(state, { payload }) {
      return { ...state, H5TemSelectList: payload.data };
    }
  },
};
export default Model;

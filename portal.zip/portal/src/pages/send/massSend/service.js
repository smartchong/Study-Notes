import request from '@/utils/request';
import API from '../../../services/api';

export async function send(params) {
  return request(API.MASSSEND.SEND, {
    method: 'POST',
    data: { ...params },
  });
}

export async function queryGroupList() {
  return request(API.MASSSEND.QUERY_GROUP_LIST);
}

export async function queryTemplates(params) {
  return request(API.MASSSEND.QUERY_TEMPLATES, {
    params
  });
}

export async function queryH5Templates(params) {
  return request(API.MASSSEND.QUERY_H5_TEMPLATES, {
    params
  });
}

import { Card, Form, Select, Button, Input, Space, Modal } from 'antd';
import React, { useState, useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { connect } from 'umi';
import {isRepeat} from '@/utils/utils';
import styles from './style.less';
const FormItem = Form.Item;
const { TextArea } = Input;
const formLayout = {
  labelCol: {
    span: 4,
  },
  wrapperCol: {
    span: 10,
  },
};
const tailLayout = {
  wrapperCol: { offset: 4, span: 10 },
};
const sendTypeList = [
  { label:'5G消息',value:0 },
  { label:'短信小程序',value:1 },
  { label:'H5 Chatbot',value:2 },
];
const addReceiversTypeList = [
  {
    label:'选择收信人群组',
    value:1,
  },
  {
    label:'直接添加号码',
    value:2
  },
];

const Index = props => {
  const [visible, setVisible] = useState(false);
  const { dispatch, massSend, loading, appLoading, templateLoading, H5TemplateLoading, appAndTableList } = props;
  const { appSelectList } = appAndTableList;
  const { recipientGroupList,temSelectList,H5TemSelectList } = massSend;
  const [form] = Form.useForm();

  useEffect(() => {
    if (dispatch && !loading) {
      dispatch({
        type:'massSend/queryRecipientGroupRule',
      })
    }
    if (dispatch && !appLoading) {
      dispatch({
        type:'appAndTableList/queryAppSelectRule',
      })
    }
  }, []);
  const getTemplateList = ()=>{
    const appId = form.getFieldValue("appId");
    const sendType = form.getFieldValue("sendType");
    form.setFieldsValue({
      smsTemplateId:undefined,
      templateId:undefined,
    })
    if (dispatch && !templateLoading && (typeof appId !== 'undefined') && (typeof sendType !== 'undefined')) {
      dispatch({
        type:'massSend/queryTemSelectList',
        payload:{
          appId,
          sendType,
        }
      })
    }
  }
  const getH5TemplateList = (v) => {
    form.setFieldsValue({
      templateId:undefined,
    })
    if (temSelectList && temSelectList.length) {
      const sendType = form.getFieldValue("sendType");
      if (dispatch && !H5TemplateLoading) {
        dispatch({
          type:'massSend/queryH5TemSelectList',
          payload:{
            smsTemplateId:v, 
            sendType,
          }
        })
      }
    }
  }
  const formValidate = async()=>{
    await form.validateFields();
    setVisible(true)
  }
  const onSubmit = () => {
    const fieldsValue = form.getFieldsValue();
    fieldsValue.addReceiversType = Number(fieldsValue.addReceiversType);
    if (fieldsValue.addReceiversType === 1) {
      fieldsValue.groupId = Number(fieldsValue.groupId);
    }
    if (fieldsValue.addReceiversType === 2) {
      fieldsValue.mobiles = fieldsValue.mobiles.split(';');
    }
    dispatch({
      type:'massSend/fetchSend',
      payload:fieldsValue,
      callback:()=>{
        setVisible(false);
      },
      reset:()=>{
        onFormReset();
      }
    })
  }
  const onFormReset = () => {
    form.resetFields();
  }
  const CheckMobiles = (v)=>{
    if (v) {
      let is = true;
      const temp = v.split(';');
      temp.map(_ => {
        if (!/^1(3[0-9]|5[0-9]|8[0-9]|4[0-9]|7[0-9]|9[0-9]|66)\d{8}$/.test(_)) {
          is = false;
        }
      })
      if(is){
        return true;
      }
      return false;
    }
  }
  const CheckMobilesL = (v)=>{
    const is = v.split(';').length <= 100;
    if(is){
      return true;
    }
    return false;
  }
  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <Form
          {...formLayout}
          form={form}
          colon={false}
          hideRequiredMark={true}
        >
          {/* 应用 */}
          {
            appSelectList && appSelectList.length ? (
              <FormItem
                label="应用"
                name="appId"
                rules={[
                  {
                    required: true,
                    message: '请选择1个应用！',
                  },
                ]}
              >
                <Select
                  placeholder='请选择'
                  onSelect={()=>{
                    getTemplateList();
                  }}
                >
                  {
                    appSelectList && appSelectList.map((item,index)=>(
                      <Select.Option value={item.appId} key={item.appId || index}>{item.appName}</Select.Option>
                    ))
                  }
                </Select>
              </FormItem>
            ) : (
              <FormItem
                label="应用"
                name="appId"
                hasFeedback
                validateStatus="error"
                help="请先创建应用！"
              >
                <Select
                  placeholder='请选择'
                >
                  {
                    appSelectList && appSelectList.map((item,index)=>(
                      <Select.Option key={item.appId || index}>{item.appName}</Select.Option>
                    ))
                  }
                </Select>
              </FormItem>
            )
          }
          {/* 发送方式 */}
          <FormItem
            label="发送方式"
            name="sendType"
            rules={[
              {
                required: true,
                message: '请选择发送方式！',
              },
            ]}
          >
            <Select
              placeholder='请选择'
              onSelect={()=>{
                getTemplateList();
              }}
            >
              {
                sendTypeList.map((item,index)=>(
                  <Select.Option value={item.value} key={item.value || index}>{item.label}</Select.Option>
                ))
              }
            </Select>
          </FormItem>
          {/* 模板名称 */}
          <FormItem 
            noStyle
            shouldUpdate={(prevValue,curValue) => prevValue.sendType !== curValue.sendType}
          >
            {
              ({ getFieldValue }) => {
                const sendType = Number(getFieldValue('sendType'));
                if (sendType === 0) {
                  return (
                    <FormItem
                      label="模板名称"
                      name="templateId"
                      rules={[
                        {
                          required: true,
                          message: '请选择1个模板！',
                        },
                      ]}
                    >
                      <Select
                        placeholder='请选择'
                        showSearch
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                      >
                        {
                          temSelectList && temSelectList.map((item,index)=>(
                            <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                          ))
                        }
                      </Select>
                    </FormItem>
                  )
                } else if (sendType === 1) {
                  return (
                    <FormItem
                      label="模板名称"
                      name="smsTemplateId"
                      rules={[
                        {
                          required: true,
                          message: '请选择1个模板！',
                        },
                      ]}
                    >
                      <Select
                        placeholder='请选择'
                        showSearch
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                      >
                        {
                          temSelectList && temSelectList.map((item,index)=>(
                            <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                          ))
                        }
                      </Select>
                    </FormItem>
                  )
                } else if (sendType === 2) {
                  return (
                    <Form.Item
                      label="模板名称"
                    >
                      <Form.Item
                        name="smsTemplateId"
                        rules={[
                          {
                            required: true,
                            message: '请选择1个H5 Chatbot模板！',
                          },
                        ]}
                        style={{ display: 'inline-block', width: 'calc(50% - 8px)', marginBottom: 0 }}
                      >
                        <Select
                          placeholder='请选择'
                          showSearch
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                          onSelect={(v)=>{
                            getH5TemplateList(v);
                          }}
                        >
                          {
                            temSelectList && temSelectList.map((item,index)=>(
                              <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                            ))
                          }
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name="templateId"
                        rules={[
                          {
                            required: true,
                            message: '请选择1个5G消息模板！',
                          },
                        ]}
                        style={{ display: 'inline-block', width: 'calc(50% - 8px)', margin: '0 0 0 16px' }}
                      >
                        <Select
                          placeholder='请选择'
                          showSearch
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                        >
                          {
                            H5TemSelectList && H5TemSelectList.map((item,index)=>(
                              <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                            ))
                          }
                        </Select>
                      </Form.Item>
                    </Form.Item>
                  ) 
                }
              }
            }
          </FormItem>
          {/* 收信人添加方式 */}
          <FormItem
            label="收信人添加方式"
            name="addReceiversType"
            rules={[
              {
                required: true,
                message: '请选择收信人添加方式！',
              },
            ]}
          >
            <Select
              placeholder='请选择'
            >
              {
                addReceiversTypeList.map((item,index) => (
                  <Select.Option value={item.value} key={item.value || index}>{item.label}</Select.Option>
                ))
              }
            </Select>
          </FormItem>
          <FormItem
            noStyle
            shouldUpdate={(prevValue,curValue) => prevValue.addReceiversType !== curValue.addReceiversType}
          >
            {
              ({ getFieldValue }) => {
                const type = Number(getFieldValue('addReceiversType'));
                if (type === 1) {
                  // 收信人群组
                  return (
                    recipientGroupList && recipientGroupList.length ? (
                      <FormItem
                        label="收信人群组"
                        name="groupId"
                        rules={[
                          {
                            required: true,
                            message: '请选择收信人群组！',
                          },
                        ]}
                      >
                        <Select
                          placeholder='请选择'
                          showSearch
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                        >
                          {
                            recipientGroupList && recipientGroupList.map((item,index)=>(
                              <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                            ))
                          }
                        </Select>
                      </FormItem>
                    ) : (
                      <FormItem
                        label="收信人群组"
                        name="groupId"
                        hasFeedback
                        validateStatus="error"
                        help="请先创建收信人群组！"
                      >
                        <Select
                          placeholder='请选择'
                          showSearch
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                        >
                          {
                            recipientGroupList && recipientGroupList.map((item,index)=>(
                              <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                            ))
                          }
                        </Select>
                      </FormItem>
                    )
                  )
                } else if (type === 2) {
                  // 收信人手机号码
                  return (
                    <FormItem
                      label='收信人手机号码'
                      name="mobiles"
                      extra="单次群发操作用户至多可添加100个手机号码作为收信人，手机号码之间需要用半角的“;”分隔开。"
                      rules={[
                        {
                          required: true,
                          message: '请添加收信人手机号码！',
                        },
                        ({ getFieldValue })  => ({
                          async validator(rule, value) {
                            if (value) {
                              const vMobiles = await CheckMobiles(value);
                              const vLength = await CheckMobilesL(value);
                              const vRepeat = await !isRepeat(value.split(';'));
                              if (!value || (vMobiles && vLength && vRepeat)) {
                                return Promise.resolve();
                              }
                              if(!vMobiles){
                                return Promise.reject('收信人手机号码错误，请重新输入！');
                              }
                              if(!vLength){
                                return Promise.reject('单次最多可添加100个手机号码！');
                              }
                              if(!vRepeat){
                                return Promise.reject('收信人手机号码错误，请重新输入！');
                              }
                            }
                          },
                        }),
                      ]}
                    >
                      <TextArea
                        autoSize={{
                          minRows: 6,
                          maxRows: 8
                        }}
                        maxLength={1199}
                        placeholder="请输入"
                      />
                    </FormItem>
                  )
                } else {
                  return null;
                }
              }
            }
          </FormItem>
          <Form.Item
            {...tailLayout}
          >
            <Space>
              <Button onClick={onFormReset}>取消</Button>
              <Button
                type="primary"
                onClick={formValidate}
                loading={loading}
              >
                发送
              </Button>
            </Space>
          </Form.Item>
        </Form>
        <Modal
          title="操作提示"
          visible={visible}
          onOk={onSubmit}
          confirmLoading={loading}
          onCancel={()=>setVisible(false)}
        >
          <p>是否确定发送消息？一经发送即不可撤回</p>
        </Modal>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(({ appAndTableList, massSend, loading }) => ({
  appAndTableList,
  massSend,
  loading: loading.effects['massSend/fetchSend'],
  appLoading: loading.effects['appAndTableList/queryAppSelectRule'],
  templateLoading: loading.effects['massSend/queryTemSelectList'],
  H5TemplateLoading: loading.effects['massSend/queryH5TemSelectList'],
}))(Index);

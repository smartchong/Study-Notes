import React, { useState, useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Card,Form,Select,Button,Input,Radio,Space,Modal} from 'antd';
import { connect } from 'umi';
const FormItem = Form.Item;
const formLayout = {
  labelCol: {
    span: 4,
  },
  wrapperCol: {
    span: 10,
  },
};
const tailLayout = {
  wrapperCol: { offset: 4, span: 10 },
};
const sendTypeList = [
  { label:'5G消息',value:0 },
  { label:'短信小程序',value:1 },
  { label:'H5 Chatbot',value:2 },
];

const Index = props => {
  const [form] = Form.useForm();
  const [visible, setVisible] = useState(false);
  const { dispatch, loading, appLoading, templateLoading, H5TemplateLoading, appAndTableList,testSend } = props;
  const { appSelectList } = appAndTableList;
  const { detailsData,temSelectList,H5TemSelectList } = testSend;
  const getTemplateList = ()=>{
    const appId = form.getFieldValue("appId");
    const sendType = form.getFieldValue("sendType");
    form.setFieldsValue({
      smsTemplateId:undefined,
      templateId:undefined,
    })
    if (dispatch && !templateLoading && (typeof appId !== 'undefined') && (typeof sendType !== 'undefined')) {
      dispatch({
        type:'testSend/queryTemSelectList',
        payload:{
          appId,
          sendType,
        }
      })
    }
  }
  const getH5TemplateList = (v) => {
    form.setFieldsValue({
      templateId:undefined,
    })
    if (temSelectList && temSelectList.length) {
      const sendType = form.getFieldValue("sendType");
      if (dispatch && !H5TemplateLoading) {
        dispatch({
          type:'testSend/queryH5TemSelectList',
          payload:{
            smsTemplateId:v, 
            sendType,
          }
        })
      }
    }
  }
  const onSubmit = () => {
    const fieldsValue = form.getFieldsValue();
    dispatch({
      type:'testSend/fetchSend',
      payload:fieldsValue,
      callback:()=>{
        onFormReset();
        if (visible) {
          setVisible(false);
        }
        dispatch({
          type:'testSend/fetchDetail',
        })
      }
    })
  }
  const onFormReset = () => {
    form.resetFields();
  }
  const formValidate = async()=>{
    await form.validateFields();
    if ((detailsData && detailsData.confirmSecondIs === 1) || !detailsData) {
      setVisible(true);
    } else {
      onSubmit();
    }
  }
  useEffect(() => {
    if (dispatch) {
      dispatch({
        type:'testSend/fetchDetail',
      })
    }
    if (dispatch && !appLoading) {
      dispatch({
        type:'appAndTableList/queryAppSelectRule',
      })
    }
  }, []);
  useEffect(() => {
    if (detailsData) {
      form.setFieldsValue({
        appFixedIs:detailsData ? detailsData.appFixedIs : 1,
        mobileFixedIs:detailsData ? detailsData.mobileFixedIs : 1,
        sendTypeFixedIs:detailsData ? detailsData.sendTypeFixedIs : 1,
        templateFixedIs:detailsData ? detailsData.templateFixedIs : 1,
        confirmSecondIs:detailsData ? detailsData.confirmSecondIs : 2,
        appId:detailsData && detailsData.appFixedIs === 1 ? detailsData.fixedAppId : undefined,
        mobile:detailsData && detailsData.mobileFixedIs === 1 ? detailsData.fixedMobile : undefined,
        sendType:detailsData && detailsData.sendTypeFixedIs === 1 ? detailsData.fixedSendType : undefined,
        templateId:detailsData && detailsData.sendTypeFixedIs === 1 && (detailsData.fixedSendType === 0 || detailsData.fixedSendType === 2) ? detailsData.fixedTemplateId : undefined,
        smsTemplateId:detailsData && detailsData.sendTypeFixedIs === 1 && (detailsData.fixedSendType === 1 || detailsData.fixedSendType === 2) ? detailsData.fixedSmsTemplateId : undefined,
      })
    }
    if (
      dispatch 
      && !templateLoading 
      && detailsData 
      && 'fixedAppId' in detailsData 
      && 'fixedSendType' in detailsData
    ) {
      dispatch({
        type:'testSend/queryTemSelectList',
        payload:{
          appId:detailsData.fixedAppId,
          sendType:detailsData.fixedSendType,
        }
      })
    }
    if (
      dispatch 
      && !H5TemplateLoading 
      && detailsData 
      && 'fixedSmsTemplateId' in detailsData 
      && 'fixedSendType' in detailsData
      && detailsData.fixedSendType === 2
    ) {
      dispatch({
        type:'testSend/queryH5TemSelectList',
        payload:{
          smsTemplateId:detailsData.fixedSmsTemplateId, 
          sendType:detailsData.fixedSendType,
        }
      })
    }
  },[detailsData]);

  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <Form
          {...formLayout}
          colon={false}
          form={form}
          hideRequiredMark={true}
          initialValues={{
            appFixedIs:detailsData ? detailsData.appFixedIs : 1,
            mobileFixedIs:detailsData ? detailsData.mobileFixedIs : 1,
            sendTypeFixedIs:detailsData ? detailsData.sendTypeFixedIs : 1,
            templateFixedIs:detailsData ? detailsData.templateFixedIs : 1,
            confirmSecondIs:detailsData ? detailsData.confirmSecondIs : 2,
            appId:detailsData ? detailsData.fixedAppId : undefined,
            mobile:detailsData ? detailsData.fixedMobile : undefined,
            sendType:detailsData ? detailsData.fixedSendType : undefined,
            templateId:detailsData && detailsData.sendTypeFixedIs === 1 && (detailsData.fixedSendType === 0 || detailsData.fixedSendType === 2) ? detailsData.fixedTemplateId : undefined,
            smsTemplateId:detailsData && detailsData.sendTypeFixedIs === 1 && (detailsData.fixedSendType === 1 || detailsData.fixedSendType === 2) ? detailsData.fixedSmsTemplateId : undefined,
          }}
        >
          {/* 发送规则配置 */}
          <FormItem noStyle>
            <h1
              style={{
                fontSize:18,
                fontWeight:600,
              }}
            >发送规则配置</h1>
          </FormItem>
          {/* 应用 */}
          <FormItem
            label="应用"
            name="appFixedIs"
          >
            <Radio.Group>
              <Radio value={1}>首次后固定</Radio>
              <Radio value={2}>每次变化</Radio>
            </Radio.Group>
          </FormItem>
          {/* 收信人手机号码 */}
          <FormItem
            label="收信人手机号码"
            name="mobileFixedIs"
          >
            <Radio.Group>
              <Radio value={1}>首次后固定</Radio>
              <Radio value={2}>每次变化</Radio>
            </Radio.Group>
          </FormItem>
          {/* 发送方式 */}
          <FormItem
            label="发送方式"
            name="sendTypeFixedIs"
          >
            <Radio.Group>
              <Radio value={1}>首次后固定</Radio>
              <Radio value={2}>每次变化</Radio>
            </Radio.Group>
          </FormItem>
          {/* 模板名称 */}
          <FormItem
            label="模板名称"
            name="templateFixedIs"
          >
            <Radio.Group>
              <Radio value={1}>首次后固定</Radio>
              <Radio value={2}>每次变化</Radio>
            </Radio.Group>
          </FormItem>
          {/* 发送确认 */}
          <FormItem
            label="发送确认"
            name="confirmSecondIs"
          >
            <Radio.Group>
              <Radio value={2}>无需二次确认</Radio>
              <Radio value={1}>需要二次确认</Radio>
            </Radio.Group>
          </FormItem>
          {/* 发送内容配置 */}
          <FormItem noStyle>
            <h1
              style={{
                fontSize:18,
                fontWeight:600,
              }}
            >发送内容配置</h1>
          </FormItem>
          {/* 应用 */}
          <FormItem
            label="应用"
            name="appId"
            rules={[
              {
                required: true,
                message: '请选择1个应用！',
              },
            ]}
          >
            <Select
              placeholder='请选择'
              onSelect={(v)=>{
                getTemplateList(v);
              }}
            >
              {
                appSelectList && appSelectList.map((item,index)=>(
                  <Select.Option key={item.appId}>{item.appName}</Select.Option>
                ))
              }
            </Select>
          </FormItem>
          {/* 收信人手机号码 */}
          <FormItem
            label="收信人手机号码"
            name="mobile"
            rules={[
              {
                required: true,
                message: '请输入收信人手机号码！',
              },
              {
                pattern: /^1(3[0-9]|5[0-9]|8[0-9]|4[0-9]|7[0-9]|9[0-9]|66)\d{8}$/,
                message: '请输入正确的收信人手机号码！',
              },
            ]}
          >
            <Input
              maxLength={11}
              placeholder='请输入'
            />
          </FormItem>
          {/* 发送方式 */}
          <FormItem
            label="发送方式"
            name="sendType"
            rules={[
              {
                required: true,
                message: '请选择发送方式！',
              },
            ]}
          >
            <Select
              placeholder='请选择'
              onSelect={()=>{
                getTemplateList();
              }}
            >
              {
                sendTypeList.map((item,index)=>(
                  <Select.Option value={item.value} key={item.value || index}>{item.label}</Select.Option>
                ))
              }
            </Select>
          </FormItem>
          {/* 模板名称 */}
          <FormItem 
            noStyle
            shouldUpdate={(prevValue,curValue) => prevValue.sendType !== curValue.sendType}
          >
            {
              ({ getFieldValue }) => {
                const sendType = Number(getFieldValue('sendType'));
                if (sendType === 0) {
                  return (
                    <FormItem
                      label="模板名称"
                      name="templateId"
                      rules={[
                        {
                          required: true,
                          message: '请选择1个模板！',
                        },
                      ]}
                    >
                      <Select
                        placeholder='请选择'
                        showSearch
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                      >
                        {
                          temSelectList && temSelectList.map((item,index)=>(
                            <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                          ))
                        }
                      </Select>
                    </FormItem>
                  )
                } else if (sendType === 1) {
                  return (
                    <FormItem
                      label="模板名称"
                      name="smsTemplateId"
                      rules={[
                        {
                          required: true,
                          message: '请选择1个模板！',
                        },
                      ]}
                    >
                      <Select
                        placeholder='请选择'
                        showSearch
                        optionFilterProp="children"
                        filterOption={(input, option) =>
                          option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                        }
                      >
                        {
                          temSelectList && temSelectList.map((item,index)=>(
                            <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                          ))
                        }
                      </Select>
                    </FormItem>
                  )
                } else if (sendType === 2) {
                  return (
                    <Form.Item
                      label="模板名称"
                    >
                      <Form.Item
                        name="smsTemplateId"
                        rules={[
                          {
                            required: true,
                            message: '请选择1个H5 Chatbot模板！',
                          },
                        ]}
                        style={{ display: 'inline-block', width: 'calc(50% - 8px)', marginBottom: 0 }}
                      >
                        <Select
                          placeholder='请选择'
                          showSearch
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                          onSelect={(v)=>{
                            getH5TemplateList(v);
                          }}
                        >
                          {
                            temSelectList && temSelectList.map((item,index)=>(
                              <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                            ))
                          }
                        </Select>
                      </Form.Item>
                      <Form.Item
                        name="templateId"
                        rules={[
                          {
                            required: true,
                            message: '请选择1个5G消息模板！',
                          },
                        ]}
                        style={{ display: 'inline-block', width: 'calc(50% - 8px)', margin: '0 0 0 16px' }}
                      >
                        <Select
                          placeholder='请选择'
                          showSearch
                          optionFilterProp="children"
                          filterOption={(input, option) =>
                            option.children.toLowerCase().indexOf(input.toLowerCase()) >= 0
                          }
                        >
                          {
                            H5TemSelectList && H5TemSelectList.map((item,index)=>(
                              <Select.Option value={item.id} key={item.id || index}>{item.name}</Select.Option>
                            ))
                          }
                        </Select>
                      </Form.Item>
                    </Form.Item>
                  ) 
                }
              }
            }
          </FormItem>
          {/* 操作 */}
          <FormItem
            {...tailLayout}
          >
            <Space>
              <Button onClick={onFormReset}>取消</Button>
              <Button
                type="primary"
                onClick={formValidate}
                loading={loading}
              >
                发送
              </Button>
            </Space>
          </FormItem>
        </Form>
        <Modal
          title="操作提示"
          visible={visible}
          onOk={onSubmit}
          confirmLoading={loading}
          onCancel={()=>setVisible(false)}
        >
          <p>是否确定发送消息？一经发送即不可撤回</p>
        </Modal>
      </Card>
    </PageHeaderWrapper>
  )
}

export default connect(
  ({appAndTableList,testSend,loading}) =>
  ({
    appAndTableList,
    testSend,
    loading: loading.effects['testSend/fetchSend'],
    appLoading: loading.effects['appAndTableList/queryAppSelectRule'],
    templateLoading: loading.effects['testSend/queryTemSelectList'],
    H5TemplateLoading: loading.effects['testSend/queryH5TemSelectList'],
  })
)(Index);

import request from '@/utils/request';
import API from '../../../services/api';

export async function fetchDetails() {
  return request(API.TESTSEND.DETAILS);
}

export async function send(params) {
  return request(API.TESTSEND.SEND, {
    method: 'POST',
    data: { ...params },
  });
}

export async function queryTemplates(params) {
  return request(API.TESTSEND.QUERY_TEMPLATES, {
    params
  });
}

export async function queryH5Templates(params) {
  return request(API.TESTSEND.QUERY_H5_TEMPLATES, {
    params
  });
}
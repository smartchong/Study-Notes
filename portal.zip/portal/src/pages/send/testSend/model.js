import { message,notification } from 'antd';
import { send,fetchDetails,queryTemplates,queryH5Templates } from './service';

const Model = {
  namespace: 'testSend',
  state: {
    detailsData:null,
    temSelectList:[],
    H5TemSelectList:[],
  },
  effects: {
    *fetchDetail({payload,callback}, { call, put }) {
      const response = yield call(fetchDetails,payload);
      if(response && response.success){
        yield put({
          type: 'setDetails',
          payload: response,
        });
      } else {
        notification.error({
          message: response.message || '操作失败',
        });
      }
    },
    *fetchSend({payload,callback}, { call, put }) {
      try {
        const response = yield call(send,payload);
        if(response && response.success){
          callback(response);
          message.success('发送成功');
        } else {
          notification.error({
            message: response.message || '操作失败',
          });
        }
        return true;
      } catch (error) {
        notification.error({
          message: '操作失败',
        });
        return false;
      }
    },
    *queryTemSelectList({ payload },{ call, put }) {
      const response = yield call(queryTemplates, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      } else {
        yield put({
          type: 'setTemSelectList',
          payload: response,
        });
      }
    },
    *queryH5TemSelectList({ payload },{ call, put }) {
      const response = yield call(queryH5Templates, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      } else {
        yield put({
          type: 'setH5TemSelectList',
          payload: response,
        });
      }
    },
  },
  reducers: {
    setDetails(state, { payload }) {
      return { ...state,detailsData: payload.data.hcbSmsSendTestRule };
    },
    setTemSelectList(state, { payload }) {
      return { ...state, temSelectList: payload.data };
    },
    setH5TemSelectList(state, { payload }) {
      return { ...state, H5TemSelectList: payload.data };
    },
  },
};
export default Model;

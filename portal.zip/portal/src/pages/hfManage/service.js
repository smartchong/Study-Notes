import request from '@/utils/request';
import API from '@/services/api';

// 列表查询
export async function queryList(params) {
  return request(`${API.HFMANAGE.QUERY_LIST}`, {
    method: 'POST',
    data: params,
  });
}

// 删除
export async function removeRule(params) {
  return request(`${API.HFMANAGE.DELETE}?id=${params.id}`, {
    method: 'POST',
    data: params,
  });
}
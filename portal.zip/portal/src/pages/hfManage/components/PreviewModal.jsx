import React from 'react';
import { Button, Modal } from 'antd';
import styles from './component.less';

const PreviewModal = (props) => {
  const { modalVisible, onCopy, onCancel, showCopy, children } = props;
  return (
    <Modal
      destroyOnClose
      wrapClassName={styles.previewModal}
      title={null}
      visible={modalVisible}
      onCancel={() => onCancel()}
      footer={
        showCopy
          ? [
              <Button key="close" onClick={onCancel}>
                关闭
              </Button>,
              <Button
                key="copy"
                type="primary"
                onClick={() => {
                  onCopy();
                  onCancel();
                }}
              >
                复制链接
              </Button>,
            ]
          : [
              <Button key="close" onClick={onCancel}>
                关闭
              </Button>,
            ]
      }
    >
      {children}
    </Modal>
  );
};

export default PreviewModal;

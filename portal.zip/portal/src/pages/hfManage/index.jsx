import React, { useState, useRef } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import { PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { Button, Card, Select, Space, Modal, message, notification } from 'antd';
import copy from 'copy-to-clipboard';
import ControledInput from './components/Input';
import PreviewModal from './components/PreviewModal';
import { connect, history } from 'umi';
import { queryList,removeRule } from './service';
import styles from './style.less';
const { Option } = Select;
const statusList = [
  {
    label: '全部',
    value: '',
  },
  {
    label: '待提交',
    value: 0,
  },
  {
    label: '待审核',
    value: 1,
  },
  {
    label: '审核通过',
    value: 2,
  },
  {
    label: '审核不通过',
    value: 3,
  },
];
let defaultCurrent = 1;
let defaultPageSize = 20;

const Index = (props) => {
  const [url, handleUrl] = useState('');
  const [shortlink, handleShortlink] = useState('');
  const [modal, handleModal] = useState(false);
  const [showCopy, handleShowCopy] = useState(false);
  const { dispatch, hfManage } = props;
  const { searchParam } = hfManage;
  const actionRef = useRef();
  const formRef = useRef(null);
  /**
   *  删除节点
   * @param selectedRows
   */
  const handleRemove = async (id) => {
    const hide = message.loading('正在删除');

    try {
      const ret = await removeRule({
        id,
      });
      hide();
      if (ret && ret.success) {
        notification.success({
          message:'删除成功！'
        });
        if (actionRef.current) {
          actionRef.current.reload();
        }
        return true;
      } else {
        notification.error({
          message:ret.message || '删除失败，请重试！'
        });
        return false;
      }
    } catch (error) {
      hide();
      notification.error({
        message:'删除失败，请重试！'
      });
      return false;
    }
  };
  const columns = [
    {
      title: 'H5页面ID',
      dataIndex: 'id',
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '页面标题',
      dataIndex: 'title',
      ellipsis: true,
      hideInTable: true,
      renderFormItem: (_, { onChange, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入页面标题"
            onChange={(value) => {
              onChange(value);
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: 'H5页面标题',
      dataIndex: 'title',
      width: 150,
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: 'H5页面短链',
      dataIndex: 'shortLink',
      ellipsis: true,
      hideInSearch: true,
    },
    {
      title: '状态',
      dataIndex: 'status',
      hideInTable: true,
      renderFormItem: (_, { ...rest }, form) => {
        return (
          <Select placeholder={'全部'} {...rest}>
            {statusList.map((item) => (
              <Option key={item.value} value={item.value}>
                {item.label}
              </Option>
            ))}
          </Select>
        );
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      hideInSearch: true,
      render: (_, record) => (
        <span>
          {statusList.find((item) => item.value === _)
            ? statusList.find((item) => item.value === _).label
            : '-'}
        </span>
      ),
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      valueType: 'dateTime',
      hideInSearch: true,
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
          <Space>
            <a 
              onClick={
                () => {
                  if (record.status === 2) {
                    handleShortlink(record.shortLink);
                    handleShowCopy(true);
                  } else {
                    handleShowCopy(false);
                  }
                  handleUrl(`${window.location.href.split('#')[0]}#/h5/${record.shortStr}`);
                  handleModal(true);
                }
              }
            >预览</a>
            {
              record.status === 0 || record.status === 3 ? (
                <a
                  onClick={() => {
                    history.push(`/h5Editor/modify/${record.id}`);
                  }}
                >修改</a>
              ) : null
            }
            {
              record.status === 0 || record.status === 2 || record.status === 3 ? (
                <a
                  onClick={() => {
                    Modal.confirm({
                      title: '是否确定删除:',
                      icon: <QuestionCircleOutlined />,
                      content: '删除后，该H5页面信息不在列表中展示。',
                      onOk: () => handleRemove(record?.id),
                    });
                  }}
                >删除</a>
              ) : null
            }    
          </Space>
        </>
      ),
    },
  ];

  return (
    <PageHeaderWrapper title={'H5页面列表'}>
      <Card>
        <ProTable
          actionRef={actionRef}
          columns={columns}
          formRef={formRef}
          options={false}
          pagination={{
            defaultCurrent: searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize: searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          rowKey="id"
          request={(params, sorter, filter) => {
            if (searchParam) {
              params.id = searchParam.id;
              params.title = searchParam.title;
              params.shortLink = searchParam.shortLink;
              params.status = searchParam.status;
              if (dispatch) {
                dispatch({
                  type: 'hfManage/setParam',
                  payload: null,
                });
              }
            }
            params.pageNum = params.current;
            defaultCurrent = params.current;
            defaultPageSize = params.pageSize;
            delete params.current;
            delete params.createTime;
            return queryList(params);
          }}
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              if (searchParam) {
                form.setFieldsValue({
                  id: searchParam.id,
                  title: searchParam.title,
                  shortLink: searchParam.shortLink,
                  status: searchParam.status,
                });
              }
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          toolBarRender={() => [
            <Button
              icon={<PlusOutlined />}
              type="primary"
              onClick={() => {
                history.push('/h5Editor/add');
              }}
            >
              创建H5页面
            </Button>,
          ]}
        />
      </Card>
      <PreviewModal
        showCopy={showCopy}
        onCopy={() => {
          copy(shortlink);
          message.success('已复制到剪贴板！');
        }}
        onCancel={() => handleModal(false)}
        modalVisible={modal}
      >
        <div className={styles.iframeWrap}>
          <iframe
            className={styles.iframe}
            src={url}
            frameBorder="0"
            scrolling="no"
            sandbox="allow-forms allow-scripts allow-same-origin allow-popups"
          />
        </div>
      </PreviewModal>
    </PageHeaderWrapper>
  );
};

export default connect(({ hfManage, loading }) => ({
  hfManage,
  loading: loading.effects['hfManage/queryList'],
}))(Index);

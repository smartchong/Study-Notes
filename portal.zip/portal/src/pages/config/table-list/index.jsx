import { DownOutlined, PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { Button,message,Card,Modal } from 'antd';
import React, { useState, useRef } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import CreateForm from './components/CreateForm';
import { connect } from 'umi';
import config from './config';
import { queryRule, addRule, removeRule } from './service';

const Index = props => {
  const [createModalVisible, handleModalVisible] = useState(false);
  const actionRef = useRef();
  const { dispatch,loading,temSelectList,appSelectList } = props;
  /**
   * 添加节点
   * @param fields
   */
  const handleAdd = async (fields) => {
    const hide = message.loading('正在添加');

    try {
      const ret = await addRule(fields);
      if(ret && ret.success){
        hide();
        message.success('添加成功');
        return true;
      }else {
        message.error(ret.message || '添加失败请重试！');
        return false;
      }
    } catch (error) {
      hide();
      message.error('添加失败请重试！');
      return false;
    }
  };
  /**
   *  删除节点
   * @param selectedRows
   */
  const handleRemove = async (selectedRows) => {
    const hide = message.loading('正在删除');
    if (!selectedRows) return true;

    try {
      const ret = await removeRule({
        id: selectedRows.map((row) => row.id).join(','),
      });
      hide();
      if(ret && ret.success){
        message.success('删除成功');
        if (actionRef.current) {
          actionRef.current.reload();
        }
        return true;
      }else {
        message.error(ret.message || '删除失败，请重试');
        return false;
      }
    } catch (error) {
      hide();
      message.error('删除失败，请重试');
      return false;
    }
  };
  const columns = [
    {
      title: '上行消息内容',
      dataIndex: 'keyWord',
      ellipsis:true,
      width: 200,
    },
    {
      title: '下行模板',
      dataIndex: 'templateName',
      ellipsis:true,
      width: 200,
    },
    {
      title: '所属应用',
      dataIndex: 'appName',
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotName',
    },
    {
      title: '是否默认',
      dataIndex: 'defaultFlag',
      renderText: v => {
        return config.defaultFlag[v]
      },
    },
    {
      title: '状态',
      dataIndex: 'status',
      valueEnum: {
        0: { text: '有效' },
        1: { text: '无效',},
      },
    },
    {
      title: '配置时间',
      dataIndex: 'createTime',
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        <>
          <a onClick={()=>{
            Modal.confirm({
              title: '是否确定删除:',
              icon: <QuestionCircleOutlined />,
              content: '选定的条目及所有相关数据？删除后内容将不可恢复。',
              onOk:()=>handleRemove([record])
            })
          }}>删除</a>
        </>
      ),
    },
  ];

  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <ProTable
          headerTitle=""
          actionRef={actionRef}
          rowKey="id"
          search={false}
          rowSelection={false}
          options={false}
          tableAlertRender={false}
          toolBarRender={(action, { selectedRows }) => [
            <Button
              icon={<PlusOutlined />}
              type="primary"
              onClick={() => handleModalVisible(true)}
            >
              新增配置
            </Button>
           ]}
          request={params=>queryRule({...params,pageNum:params.current})}
          columns={columns}
        />
      </Card>
      <CreateForm
        dispatch={dispatch}
        appSelectList={appSelectList}
        temSelectList={temSelectList}
        onSubmit={async (value,callBack) => {
          const success = await handleAdd(value);

          if (success) {
            handleModalVisible(false);
            callBack && callBack();
            if (actionRef.current) {
              actionRef.current.reload();
            }
          }
        }}
        onCancel={() => handleModalVisible(false)}
        modalVisible={createModalVisible}
      />
    </PageHeaderWrapper>
  );
};

export default connect(({ configAndTableList,templateAndList,appAndTableList, loading }) => ({
  configAndTableList,
  temSelectList:templateAndList.temSelectList,
  appSelectList:appAndTableList.appSelectList,
  loading: loading.effects['configAndTableList/queryRule'],
}))(Index);

import request from '@/utils/request';
import API from '@/services/api';

export async function queryAppSelectList() {
  return request(API.APP.TABLE_SELECT_LIST);
}

export async function queryRule(params) {
  return request(API.CONFIG.QUERY_LIST, {
    params,
  });
}

export async function removeRule(params) {
  return request(API.CONFIG.DEL, {
    params,
  });
}
export async function addRule(params) {
  return request(API.CONFIG.ADD, {
    method: 'POST',
    data: { ...params },
  });
}

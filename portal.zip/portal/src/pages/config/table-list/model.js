import { history } from 'umi';
import { message } from 'antd';
import { queryRule,queryAppSelectList,removeRule,addRule,updateRule } from './service';

const Model = {
  namespace: 'configAndTableList',
  state: {
    tableData:{},
    appSelectList:[],
  },
  effects: {
    *queryRule({ payload }, { call, put }) {
      const response = yield call(queryRule, payload);
      yield put({
        type: 'changeQueryRule',
        payload: response,
      });
      if (!response.success) {
        message.error(response.message || '操作失败');
      }
    },
    *queryAppSelectRule({ payload }, { call, put }) {
      const response = yield call(queryAppSelectList, payload);
      yield put({
        type: 'setAppSelectList',
        payload: response,
      });
      if (!response.success) {
        message.error(response.message || '操作失败');
      }
    }
  },
  reducers: {
    changeQueryRule(state, { payload }) {
      return { ...state,tableData: payload };
    },
    setAppSelectList(state, { payload }) {
      return { ...state,appSelectList: payload.data };
    },
  },
};
export default Model;

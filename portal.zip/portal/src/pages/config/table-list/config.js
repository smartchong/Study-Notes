export default {
  defaultFlag : {
    '1':'是',
    '0':'否',
  }
}

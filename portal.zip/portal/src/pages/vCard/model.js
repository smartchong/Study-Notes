import { notification } from 'antd';
import { edit, getDeail } from './service';

const Model = {
  namespace: 'vCardMy',
  state: {
    data: {
      companyAddr: 'XXXXXXXXXXXXX',
      companyName: 'XXXXXXXXXXXXX',
      customerManager: '林先生',
      customerManagerMobile: '188XXXXXXXX'
    }
  },
  effects: {
    *fetchDetail({ payload }, { call, put }) {
      const response = yield call(getDeail, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      } else {
        yield put({
          type: 'changeData',
          payload: {data: response.data},
        });
      }
    },
    *submit({ payload }, { call, put }) {
      const response = yield call(edit, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      }else {
        window.location.reload();
      }
    },
  },
  reducers: {
    changeData(state, { payload }) {
      return { ...state, ...payload };
    }
  },
};
export default Model;

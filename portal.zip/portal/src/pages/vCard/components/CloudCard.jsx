import React from 'react';
import styles from './style.less';

const Index = props => {
  const { data, getLogo } = props;
  return (
    <div className={styles.CloudCard}>
      <div className='top-section'>
        <div className='top-left'>
          <div className='name'>
            姓名
          </div>
          <div className='position'>
            部门・职位
          </div>
          <div className='compony'>
            {data.companyName}
          </div>
        </div>
        <div className='top-right'>
          <img src={getLogo()} />
        </div>
      </div>
      <div className='bottom-section'>
        <div className='bottom-item'>
          <img src={require('../../../assets/vCard/phone.png')} alt='' />
          <div className='bottom-item-content'>
            手机：手机号码
          </div>
        </div>
        <div className='bottom-item'>
          <img src={require('../../../assets/vCard/email.png')} alt='' />
          <div className='bottom-item-content'>
            邮箱：邮箱
          </div>
        </div>
        <div className='bottom-item'>
          <img src={require('../../../assets/vCard/location.png')} alt='' />
          <div className='bottom-item-content'>
            {`地址：${data.provinceName}${data.cityName}${data.countyName}${data.companyAddr}`}
          </div>
        </div>
      </div>
    </div>
  )
}

export default Index;
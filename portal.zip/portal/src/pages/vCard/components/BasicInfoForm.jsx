import React from 'react';
import { Descriptions, Button, Form, Cascader, Upload, Input } from 'antd';
import CITYS from '@/utils/city';
import { UploadOutlined } from '@ant-design/icons';
import Cookie from "js-cookie";
import { getLogo, uploadLogo } from '../service';
import styles from './style.less';

const Index = props => {

  const { isEdit, changeEditStatus, data, doSubmit } = props;
  const formItemLayout = {
    labelCol: {
      span: 4,
    },
    wrapperCol: {
      span: 20,
    },
  };
  const tailLayout = {
    wrapperCol: { offset: 4, span: 20 },
  };
  const normFile = e => {
    if (Array.isArray(e)) {
      return e;
    }
    return e && e.fileList;
  }
  /**
   * 校验公司LOGO
   * @param {*} _
   * @param {*} value
   */
  const checkLogo = async (_, value) => {
    const promise = Promise;
    if (value && value.length) {
      if (value.length > 1) {
        return promise.reject('仅支持单个文件上传');
      } else {
        if (value[0].size && value[0].size > 500 * 1024) {
          return promise.reject('图片大小超出限制，请重新上传');
        }
        if (value[0].type && value[0].type !== 'image/png') {
          return promise.reject('请上传正确格式的图片');
        }
      }
      return promise.resolve();
    }
  }
  const onFinish = values => {
    if (values) {
      values.companyAddr = values.companyAddr;
      values.provinceName = values.companyLocation[0] || '';
      values.cityName = values.companyLocation[1] || '';
      values.countyName = values.companyLocation[2] || '';
      values.customerManager = data.customerManager;
      values.customerManagerMobile = data.customerManagerMobile;
      delete values.companyLocation;
      delete values.companyLogo;
      doSubmit(values);
    }
  };

  return (
    <div className={styles.basicInfoForm}>
      {
        !isEdit ? <div>
          <Descriptions column={1}>
            <Descriptions.Item label="公司LOGO">
              <img src={getLogo()} style={{
                width: 100,
                height: 100
              }}/>
            </Descriptions.Item>
            <Descriptions.Item label="公司名称">
              { data.companyName }
            </Descriptions.Item>
            <Descriptions.Item label="公司地址">
              { `${data.provinceName}${data.cityName}${data.countyName}${data.companyAddr}` }
            </Descriptions.Item>
          </Descriptions>
          <Button
            type='primary'
            className='mt-20'
            onClick={() => {
              changeEditStatus(true)
            }}
          >
            修改公司信息
          </Button>
        </div> : <div className='edit-form'>
            <Form
              // form={form}
              name={"companyForm"}
              {...formItemLayout}
              onFinish={onFinish}
              initialValues={
                {
                  companyLogo: [{
                    uid:Math.random().toString(),
                    name:'',
                    url:getLogo(),
                    status:'done',
                  }],
                  companyName: data.companyName,
                  companyLocation: [data.provinceName,data.cityName,data.countyName],
                  companyAddr: data.companyAddr
                }
              }
            >
              <Form.Item
                label={"公司LOGO"}
                name={"companyLogo"}
                valuePropName={"fileList"}
                getValueFromEvent={normFile}
                extra={"请上传公司LOGO。图片大小控制在500K以内，格式仅支持PNG。"}
                rules={[
                  {
                    required: true,
                    message: '请上传公司LOGO！',
                  },
                  {
                    validator: checkLogo
                  }
                ]}
              >
                <Upload
                  action={uploadLogo}
                  accept='.png'
                  listType="picture"
                  headers={{
                    'X-XSRF-TOKEN': Cookie.get('XSRF-TOKEN')
                  }}
                  beforeUpload={(file, fileList) => {
                    if (file.type !== 'image/png') {
                      return false;
                    }
                    if (file.size > 500 * 1024) {
                      return false;
                    }
                    return true;
                  }}
                >
                  <Button>
                    <UploadOutlined /> 上传图片
                  </Button>
                </Upload>
              </Form.Item>
              <Form.Item
                label={"公司名称"}
                name={"companyName"}
                rules={[
                  {
                    required: true,
                    message: '请输入公司名称',
                    whitespace: true,
                  },
                ]}
              >
                <Input
                  placeholder={"请输入公司名称，长度30字符数以内。"}
                  maxLength={30}
                />
              </Form.Item>
              <Form.Item
                label={"公司地址"}
                name={"companyLocation"}
                rules={[
                  {
                    required: true,
                    message: '请选择公司所在地',
                  },
                ]}
              >
                <Cascader
                  options={CITYS}
                />
              </Form.Item>
              <Form.Item
                name={"companyAddr"}
                rules={[
                  {
                    required: true,
                    message: '请输入详细地址',
                    whitespace: true
                  },
                ]}
              >
                <Input
                  placeholder={"请输入详细地址，无需再重复省市区，可从XXX路开始描述，长度30字符数以内"}
                  maxLength={30}
                />
              </Form.Item>
              <Form.Item {...tailLayout}>
                <Button
                  className='mr-20'
                  onClick={() => {
                    changeEditStatus(false)
                  }}
                >
                  取消
                </Button>
                <Button type="primary" htmlType="submit">
                  提交
                </Button>
              </Form.Item>
            </Form>
          </div>
      }
    </div>
  )
}

export default Index;
import React, { useEffect, useState } from 'react';
import { connect } from "umi";
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Card } from 'antd';
import CloudCard from './components/CloudCard';
import BasicInfoForm from './components/BasicInfoForm';
import { getLogo } from './service';
import styles from './style.less';

const VCard = (props) => {
    const { dispatch, vCardMy, loading } = props;
    const [ editStatus, setEditStatus ] = useState(false);
    useEffect(() => {
        dispatch({
            type: 'vCardMy/fetchDetail'
        });
    }, []);
    const doSubmit = (params) => {
        dispatch({
            type: 'vCardMy/submit',
            payload: params
        });
    }
    return (
        <PageHeaderWrapper>
            <div
                className={styles.vCard}
            >
                <Card bordered={false}>
                    <div className='custom-card'>
                        <Card
                            bordered={false}
                            title='名片样式预览'
                        >
                            <div className='link-info'>
                                *当前名片为免费使用版，如需定制名片样式请联系客户经理{vCardMy.data.customerManager}（手机号码{vCardMy.data.customerManagerMobile}）
                            </div>
                            <CloudCard
                                data={vCardMy.data}
                                getLogo={getLogo}
                            />
                        </Card>
                    </div>
                    <div className='custom-card'>
                        <Card
                            bordered={false}
                            title='公司基本信息'
                        >
                            <BasicInfoForm
                                isEdit={editStatus}
                                changeEditStatus={setEditStatus}
                                data={vCardMy.data}
                                doSubmit={doSubmit}
                                loading={loading}
                            />
                        </Card>
                    </div>
                </Card>
            </div>
        </PageHeaderWrapper>
    )
}

export default connect(
    ({ vCardMy, loading }) => ({
        vCardMy,
        loading: loading.effects['vCardMy/submit']
    })
)(VCard);
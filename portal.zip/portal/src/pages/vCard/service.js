import request from '@/utils/request';
import API from '@/services/api';

export async function getDeail() {
    return request(API.CLOUDCARD.ELECTRONCARD.MY.DETAILS);
}

export function getLogo() {
    return API.CLOUDCARD.ELECTRONCARD.MY.GETLOGO;
}

export async function uploadLogo() {
    return API.CLOUDCARD.ELECTRONCARD.MY.UPLOADLOGO;
}

export async function edit(params) {
  return request(API.CLOUDCARD.ELECTRONCARD.MY.EDIT, {
    method: 'POST',
    data: { ...params },
  });
}
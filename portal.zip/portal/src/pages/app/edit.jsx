import React,{ useEffect } from 'react';
import { connect,history,useParams } from 'umi';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Card, Row, Col, message } from 'antd';
import AppForm from './components/AppForm';
import Preview from './components/Preview';
import defaultMenuData from './components/defaultMenuData';

const Edit = props => {

    const params = useParams();
    const { dispatch,currentUser,loading,detailLoading,appAndTableList, } = props;
    const { chatbotType } = currentUser;
    const { type,menuData,detailData } = appAndTableList;
    const handleUpdate = async (values) => {
        const hide = message.loading('正在更新');
    
        try {
            values.id = params.id;
            dispatch({
                type: 'appAndTableList/updateApp',
                payload: { ...values },
            }).then(ret => {
                if(ret && ret.success){
                    hide();
                    history.goBack();
                    message.success('创建成功');
                    return true;
                } else {
                    message.error(ret.message || '创建失败请重试！');
                    return false;
                }
            })
        } catch (error) {
            hide();
            message.error('更新失败请重试！');
            return false;
        }
    };
    useEffect(() => {
        if (dispatch && !detailLoading) {
          dispatch({
            type:'appAndTableList/queryDetail',
            payload:{
              id:params.id
            },
            callback:(data) => {
                if (dispatch && 'bottomMenuType' in data && 'bottomMenu' in data) {
                    const temp = JSON.parse(JSON.stringify(defaultMenuData));
                    temp[data.bottomMenuType] = JSON.parse(data.bottomMenu);
                    dispatch({
                        type: 'appAndTableList/setType',
                        payload: { data:data.bottomMenuType }
                    })
                    dispatch({
                        type: 'appAndTableList/setMenuData',
                        payload: { data:temp }
                    })
                }
            }
          })
        }
    }, []);

    if (!detailData) {
        return null;
    }
    return (
        <PageHeaderWrapper>
            <Card>
                <Row gutter={[24,24]}>
                    <Col span={14}>
                        <AppForm
                            id={params.id}
                            detailData={detailData}
                            onTypeChange={(v) => {
                                if (dispatch) {
                                    dispatch({
                                        type: 'appAndTableList/setType',
                                        payload: { data:v }
                                    })
                                }
                            }}
                            onMenuDataChange={(v) => {
                                if (dispatch) {
                                    dispatch({
                                        type: 'appAndTableList/setMenuData',
                                        payload: { data:v }
                                    })
                                }
                            }}
                            onSubmit={handleUpdate}
                            onCancel={() => {
                                history.goBack();
                            }}
                            loading={loading}
                            chatbotTypeList={chatbotType}
                        />
                    </Col>
                    <Col span={10}>
                        <Preview 
                            type={type}
                            menuData={menuData}
                        />
                    </Col>
                </Row>
            </Card>
        </PageHeaderWrapper>   
    );
}

export default connect(({ appAndTableList, user, loading }) => ({
    appAndTableList,
    currentUser:user.currentUser,
    loading:loading.effects['appAndTableList/updateApp'],
    detailLoading:loading.effects['appAndTableList/queryDetail'],
}))(Edit);
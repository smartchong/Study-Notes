import { notification } from 'antd';
import defaultMenuData from './components/defaultMenuData';
import { queryRule,queryAppSelectList,queryDetails,create,update } from './service';

const Model = {
  namespace: 'appAndTableList',
  state: {
    type:1,
    tableData:{},
    appSelectList:[],
    searchParam:null,
    detailData:null,
    menuData:defaultMenuData,
  },
  effects: {
    *queryRule({ payload }, { call, put }) {
      const response = yield call(queryRule, payload);
      yield put({
        type: 'changeQueryRule',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      }
    },
    *queryAppSelectRule({ payload }, { call, put }) {
      const response = yield call(queryAppSelectList, payload);
      yield put({
        type: 'setAppSelectList',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败！',
        });
      }
    },
    *queryDetails({ payload, callback }, { call, put }) {
      const response = yield call(queryDetails, payload);
      if (!response.success) {
        notification.error({
          message: response.message || '操作失败',
        });
      } else {
        yield put({
          type: 'setDetails',
          payload: response,
        });
        if ('data' in response) {
          callback(response.data);
        }
      }
    },
    *queryDetail({payload,callback},{call,put}){
      yield put({
        type: 'setDetailData',
        payload: {},
      });
      const response = yield call(queryDetails,payload);
      if(response && response.success){
        yield put({
          type: 'setDetailData',
          payload: response,
        });
        if ('data' in response) {
          callback(response.data);
        }
      }else {
        notification.error({
          message: response.message || '操作失败！',
        });
      }
    },
    *createApp({ payload }, { call }) {
      const response = yield call(create, payload);
      return response;
    },
    *updateApp({ payload }, { call }) {
      const response = yield call(update, payload);
      return response;
    },
  },
  reducers: {
    changeQueryRule(state, { payload }) {
      return { ...state,tableData: payload };
    },
    setAppSelectList(state, { payload }) {
      return { ...state,appSelectList: payload.data };
    },
    setDetailData(state, { payload }) {
      return { ...state, detailData:payload.data };
    },
    setDetails(state, { payload }) {
      return { ...state, detailsData:payload.data };
    },
    setType(state, { payload }) {
      return { ...state,type: payload.data };
    },
    setMenuData(state, { payload }) {
      return { ...state,menuData: payload.data };
    },
    setParam(state, { payload }) {
      return { ...state,searchParam: payload };
    },
  },
};
export default Model;

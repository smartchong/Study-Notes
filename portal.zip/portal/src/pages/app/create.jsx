import React from 'react';
import { connect,history } from 'umi';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Card, Row, Col, message } from 'antd';
import AppForm from './components/AppForm';
import Preview from './components/Preview';

const Create = props => {

    const { dispatch,currentUser,loading,appAndTableList, } = props;
    const { chatbotType } = currentUser;
    const { type,menuData } = appAndTableList;
    const handleCreate = async (values) => {
        const hide = message.loading('正在创建');

        try {
            dispatch({
                type: 'appAndTableList/createApp',
                payload: { ...values },
            }).then(ret => {
                if(ret && ret.success){
                    hide();
                    history.goBack();
                    message.success('创建成功');
                    return true;
                } else {
                    message.error(ret.message || '创建失败请重试！');
                    return false;
                }
            })
        } catch (error) {
            hide();
            message.error('创建失败请重试！');
            return false;
        }
    };

    return (
        <PageHeaderWrapper>
            <Card>
                <Row gutter={[24,24]}>
                    <Col span={14}>
                        <AppForm
                            detailData={null}
                            onTypeChange={(v) => {
                                if (dispatch) {
                                    dispatch({
                                        type: 'appAndTableList/setType',
                                        payload: { data:v }
                                    })
                                }
                            }}
                            onMenuDataChange={(v) => {
                                if (dispatch) {
                                    dispatch({
                                        type: 'appAndTableList/setMenuData',
                                        payload: { data:v }
                                    })
                                }
                            }}
                            onSubmit={handleCreate}
                            onCancel={() => {
                                history.goBack();
                            }}
                            loading={loading}
                            chatbotTypeList={chatbotType}
                        />
                    </Col>
                    <Col span={10}>
                        <Preview 
                            type={type}
                            menuData={menuData}
                        />
                    </Col>
                </Row>
            </Card>
        </PageHeaderWrapper>   
    );
}

export default connect(({ appAndTableList, user, loading }) => ({
    appAndTableList,
    currentUser:user.currentUser,
    loading:loading.effects['appAndTableList/createApp'],
}))(Create);
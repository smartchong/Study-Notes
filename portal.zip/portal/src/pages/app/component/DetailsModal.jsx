import React from 'react';
import { Modal } from 'antd';
import styles from './component.less';

const DetailsModal = props => {
  const { modalVisible, onCancel, children } = props;
  return (
    <Modal
      destroyOnClose
      wrapClassName={styles.detailsModal}
      title={"短链预览"}
      visible={modalVisible}
      onCancel={() => onCancel()}
      footer={null}
    >
      {children}
    </Modal>
  )
}

export default DetailsModal;

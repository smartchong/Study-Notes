import React,{ useState } from 'react';
import IconTextModal from './IconTextModal';
import styles from './component.less';

const IconText = props => {

    const { type,index,menuData,setMenuData,disable = false,} = props;
    const [ modalVisible,handleModalVisible ] = useState(false);
    return (
        <>
            <div className={styles.iconText}>
                <div 
                    className={styles.hoverBlock} 
                    onClick={() => {
                        if (!disable) {
                            handleModalVisible(true);
                        }
                    }}
                >
                    <div className={styles.icon}>
                        <img src={menuData[type].menu[index].icon[0].url} />
                    </div>
                    <div className={styles.mainFont}
                    >
                        {menuData[type].menu[index].name ? menuData[type].menu[index].name : '菜单名称'}
                    </div>
                </div>
            </div>
            <IconTextModal
                menu={menuData[type].menu[index]}
                onCancel={() => {
                    // form.resetFields();
                    handleModalVisible(false);
                }}
                modalVisible={modalVisible}
            />  
        </>
    )
}

export default IconText;
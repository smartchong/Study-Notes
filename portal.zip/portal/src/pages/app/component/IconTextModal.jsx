import React from 'react';
import { Modal, Button, Row, Col } from 'antd';
import Preview from './Preview';
import { connect } from "umi";
import Image from './Image';
const menuTypeList = [
    { label: '添加链接', value: 'urlAction' },
    { label: '添加回复', value: 'replyAction' },
    { label: '拨打电话', value: 'dialerAction' },
];
const IconTextModal = props => {
    const { menu, onCancel, modalVisible, appAndTableList } = props;
    const { type, menuData, } = appAndTableList;
    return (
        <Modal
            destroyOnClose
            title="菜单详情"
            visible={modalVisible}
            footer={[
                <Button key="back" onClick={() => {
                    onCancel();
                }}>关闭</Button>
            ]}
            onCancel={onCancel}
            width={800}
        >
            <Row gutter={[24, 24]}>
                <Col span={12}>
                    <Row gutter={[24, 24]}>
                        <Col span={24}>
                            <span>菜单图标：</span>
                            <Image
                                src={menu.icon[0].url}
                                title={"菜单图标"}
                            />
                            {/* <img src={menu.icon[0].url} alt="" style={{ width: 50 }} /> */}
                        </Col>
                    </Row>
                    <Row gutter={[24, 24]}>
                        <Col span={24}>
                            <span>菜单名称：</span>
                            <span>{menu.name}</span>
                        </Col>
                    </Row>
                    <Row gutter={[24, 24]}>
                        <Col span={24}>
                            <span>菜单类型：</span>
                            <span>{menuTypeList.find(_ => _.value === menu.type) ? menuTypeList.find(_ => _.value === menu.type).label : '-'}</span>
                        </Col>
                    </Row>
                    {
                        menu.type === 'urlAction' ? (
                            <Row gutter={[24, 24]}>
                                <Col span={24}>
                                    <span>菜单内容：</span>
                                    <a href={menu.content} target='_blank'>{menu.content}</a>
                                </Col>
                            </Row>
                        ) : (
                                <Row gutter={[24, 24]}>
                                    <Col span={24}>
                                        <span>菜单内容：</span>
                                        <span>{menu.content}</span>
                                    </Col>
                                </Row>
                            )
                    }
                </Col>
                <Col span={12}>
                    <Preview
                        type={type}
                        menuData={menuData}
                    />
                </Col>
            </Row>
        </Modal>
    );
}
export default connect(({ appAndTableList }) => ({
    appAndTableList,
}))(IconTextModal);
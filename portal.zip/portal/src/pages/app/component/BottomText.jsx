import React,{ useState } from 'react';
import BottomTextModal from './BottomTextModal';
import styles from './component.less';

const BottomText = props => {

    const { type,menuData,setMenuData,disable = false } = props;
    const [ modalVisible,handleModalVisible ] = useState(false);
    
    return (
        <>
            <div className={styles.bottomText}>
                <div 
                    className={styles.hoverBlock} 
                    onClick={() => {
                        if (!disable) {
                            handleModalVisible(true);
                        }
                    }}
                >
                    {menuData[type].bottomText}
                </div>
            </div>
            <BottomTextModal
                bottomText={menuData[type].bottomText}
                onCancel={() => {
                    handleModalVisible(false);
                }}
                modalVisible={modalVisible}
            />  
        </>
    )
}

export default BottomText;
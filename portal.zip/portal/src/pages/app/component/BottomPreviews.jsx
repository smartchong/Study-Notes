import React from 'react';
import { Space,Divider } from 'antd';
import classnames from 'classnames';
import PlainText from './PlainTexts';
import IconText from './IconTexts';
import LogoText from './LogoText';
import BottomText from './BottomText';
import classNames from 'classnames';
import styles from './component.less';
import defaultMenuData from './defaultMenuData';

const BottomPreview = (props) => {
    const { type,menuData,className='' } = props;
    const setMenuData = (callBack)=>{
        let temp = JSON.parse(JSON.stringify(menuData));
        handleMenuData(callBack(temp));
    };
    const customProps = {
        disable:true,
        type,
        menuData,
        defaultMenuData,
        setMenuData,
    };
    const renderMenu = (type,restProp) => {
        switch(type) {
            case 1:
                return (
                    <Space 
                        className={classNames(styles.oneBox,styles.two)}
                        split={<Divider type="vertical" size="middle" />}
                    >
                        <LogoText
                            key={`logo${type}`} 
                            {...restProp}
                        />
                        <IconText
                            key={`${type}0`}
                            index={0}
                            {...restProp}
                        />
                    </Space>
                );
            case 2:
                return (
                    <Space 
                        className={classNames(styles.oneBox,styles.three)}
                        split={<Divider type="vertical" size="middle" />}
                    >
                        <LogoText 
                            key={`logo${type}`}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}0`}
                            index={0}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}1`}
                            index={1}
                            {...restProp}
                        />
                    </Space>
                );
            case 3: 
                return (
                    <Space 
                        className={classNames(styles.oneBox,styles.four)}
                        split={<Divider type="vertical" size="middle" />}
                    >
                        <LogoText 
                            key={`logo${type}`}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}0`}
                            index={0}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}1`}
                            index={1}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}2`}
                            index={2}
                            {...restProp}
                        />
                    </Space>
                );
            case 4: 
                return (
                    <>
                        <Space 
                            className={classNames(styles.topBox,styles.two)}
                            split={<Divider type="vertical" size="middle" />}
                        >
                            <IconText
                                key={`${type}0`}
                                index={0}
                                {...restProp}
                            />
                            <IconText
                                key={`${type}1`}
                                index={1}
                                {...restProp}
                            />
                        </Space>
                        <Space className={styles.bottomBox}>
                            <BottomText 
                                key={type}
                                {...restProp}
                            /> 
                        </Space>
                    </>
                );
            case 5:
                return (
                    <>
                        <Space 
                            className={classNames(styles.topBox,styles.three)}
                            split={<Divider type="vertical" size="middle" />}
                        >
                            <IconText
                                key={`${type}0`}
                                index={0}
                                {...restProp}
                            />
                            <IconText
                                key={`${type}1`}
                                index={1}
                                {...restProp}
                            />
                            <IconText
                                key={`${type}2`}
                                index={2}
                                {...restProp}
                            />
                        </Space> 
                        <Space className={styles.bottomBox}>
                            <BottomText 
                                key={type}
                                {...restProp}
                            /> 
                        </Space>
                    </>
                );
            case 6:
                return (
                    <>
                        <Space 
                            className={classNames(styles.topBox,styles.two)}
                            split={<Divider type="vertical" size="middle" />}
                        >
                            <PlainText 
                                {...restProp}
                                index={0}
                            />
                            <PlainText 
                                {...restProp}
                                index={1}
                            />
                        </Space>
                        <Space className={styles.bottomBox}>
                            <BottomText 
                                key={type}
                                {...restProp}
                            /> 
                        </Space>
                    </>
                );
            case 7: 
                return (
                    <>
                        <Space 
                            className={classNames(styles.topBox,styles.three)}
                            split={<Divider type="vertical" size="middle" />}
                        >
                            <PlainText 
                                {...restProp}
                                index={0}
                            />
                            <PlainText 
                                {...restProp}
                                index={1}
                            />
                            <PlainText 
                                {...restProp}
                                index={2}
                            />
                        </Space>
                        <Space className={styles.bottomBox}>
                            <BottomText 
                                key={type}
                                {...restProp}
                            /> 
                        </Space>
                    </>
                );    
            default:
        }
    };

    return (
        <div className={classnames(styles.bottomMenu,className)}>
            {renderMenu(type,customProps)}
        </div>
    );
}

export default BottomPreview;
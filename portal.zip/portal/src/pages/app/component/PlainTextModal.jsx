import React from 'react';
import { Modal, Button, Row, Col } from 'antd';
import { connect } from "umi";
import Preview from './Preview';
const menuTypeList = [
    { label: '添加链接', value: 'urlAction' },
    { label: '添加回复', value: 'replyAction' },
    { label: '拨打电话', value: 'dialerAction' },
];

const PlainTextModal = props => {
    const { menu, onSubmit, onCancel, modalVisible, appAndTableList } = props;
    const { type, menuData } = appAndTableList;

    return (
        <Modal
            width={800}
            destroyOnClose
            title="菜单详情"
            visible={modalVisible}
            footer={[
                <Button key="back" onClick={() => {
                    onCancel();
                }}>关闭</Button>
            ]}
            onCancel={onCancel}
        >
            <Row gutter={[24, 24]}>
                {
                    menu.isSubMenu === 1 ? (
                        <>
                            <Col span={12}>
                                {
                                    menu.subMenu.map((item,index) =>
                                        <>
                                            <p>菜单{index+1}</p>
                                            <Row gutter={[24, 24]}>
                                                <Col span={24}>
                                                    <span>菜单名称：</span>
                                                    <span>{item.name}</span>
                                                </Col>
                                            </Row>
                                            <Row gutter={[24, 24]}>
                                                <Col span={24}>
                                                    <span>菜单类型：</span>
                                                    <span>{menuTypeList.find(_ => _.value === item.type) ? menuTypeList.find(_ => _.value === item.type).label : '-'}</span>
                                                </Col>
                                            </Row>
                                            {
                                                item.type === 'urlAction' ? (
                                                    <Row gutter={[24, 24]}>
                                                        <Col span={24}>
                                                            <span>菜单内容：</span>
                                                            <a href={item.content} target='_blank'>{item.content}</a>
                                                        </Col>
                                                    </Row>
                                                ) : (
                                                        <Row gutter={[24, 24]}>
                                                            <Col span={24}>
                                                                <span>菜单内容：</span>
                                                                <span>{item.content}</span>
                                                            </Col>
                                                        </Row>
                                                    )
                                            }
                                        </>
                                    )
                                }
                            </Col>
                            <Col span={12}>
                                <Preview
                                    type={type}
                                    menuData={menuData}
                                />
                            </Col>
                        </>
                    ) : (
                            <>
                                <Col span={12}>
                                    <Row gutter={[24, 24]}>
                                        <Col span={24}>
                                            <span>菜单名称：</span>
                                            <span>{menu.name}</span>
                                        </Col>
                                    </Row>
                                    <Row gutter={[24, 24]}>
                                        <Col span={24}>
                                            <span>菜单类型：</span>
                                            <span>{menuTypeList.find(_ => _.value === menu.type) ? menuTypeList.find(_ => _.value === menu.type).label : '-'}</span>
                                        </Col>
                                    </Row>
                                    {
                                        menu.type === 'urlAction' ? (
                                            <Row gutter={[24, 24]}>
                                                <Col span={24}>
                                                    <span>菜单内容：</span>
                                                    <a href={menu.content} target='_blank'>{menu.content}</a>
                                                </Col>
                                            </Row>
                                        ) : (
                                                <Row gutter={[24, 24]}>
                                                    <Col span={24}>
                                                        <span>菜单内容：</span>
                                                        <span>{menu.content}</span>
                                                    </Col>
                                                </Row>
                                            )
                                    }
                                </Col>
                                <Col span={12}>
                                    <Preview
                                        type={type}
                                        menuData={menuData}
                                    onClick={()=>
                                    alert('11111')
                                    }
                                    />
                                </Col>
                            </>
                        )
                }
            </Row>
        </Modal>
    );
}
export default connect(({ appAndTableList }) => ({
    appAndTableList,
}))(PlainTextModal);
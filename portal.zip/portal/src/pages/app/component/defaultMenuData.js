export default [
    {},
    // 品牌LOGO+1个菜单
    {
        logo:[
            {
                uid:'1',
                name:'default_logo.png',
                status: 'done',
                url:'https://oss.komect.com/chatbot/96dccd9a0b945089a6225c5b1c8ae72.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773399&Signature=v3KzWvkCOJUC9j36DLS%2BqzUHTHk%3D',
            }
        ],
        menu: [
            {
                icon:[{
                    uid:'1',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
        ],
        bottomText: 'Powered by 中移杭研',
    },
    // 品牌LOGO+2个菜单
    {
        logo:[
            {
                uid:'1',
                name:'default_logo.png',
                status: 'done',
                url:'https://oss.komect.com/chatbot/96dccd9a0b945089a6225c5b1c8ae72.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773399&Signature=v3KzWvkCOJUC9j36DLS%2BqzUHTHk%3D',
            } 
        ],
        menu: [
            {
                icon:[{
                    uid:'1',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
            {
                icon:[{
                    uid:'2',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
        ],
        bottomText: 'Powered by 中移杭研',
    },
    // 品牌LOGO+3个菜单
    {
        logo:[
            {
                uid:'1',
                name:'default_logo.png',
                status: 'done',
                url:'https://oss.komect.com/chatbot/96dccd9a0b945089a6225c5b1c8ae72.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773399&Signature=v3KzWvkCOJUC9j36DLS%2BqzUHTHk%3D',
            }
        ],
        menu: [
            {
                icon:[{
                    uid:'1',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
            {
                icon:[{
                    uid:'2',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
            {
                icon:[{
                    uid:'3',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
        ],
        bottomText: 'Powered by 中移杭研',
    },
    // 小图标+文字2栏
    {
        menu: [
            {
                icon:[{
                    uid:'1',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
            {
                icon:[{
                    uid:'2',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
        ],
        bottomText: 'Powered by 中移杭研',
    },
    // 小图标+文字3栏
    {
        menu: [
            {
                icon:[{
                    uid:'1',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
            {
                icon:[{
                    uid:'2',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
            {
                icon:[{
                    uid:'3',
                    name:'default_app.png',
                    status: 'done',
                    url:'https://oss.komect.com/chatbot/2b98bfaca1c79a94f18ba59d0878e02.png?AWSAccessKeyId=2T24PAYM1IDB5RFYZK8Z&Expires=4099773233&Signature=7c9HWucQGVtHFePXA%2FF%2Bo9mTL6A%3D',
                }],
                name:'',
                type:'urlAction',
                content:'',
            },
        ],
        bottomText: 'Powered by 中移杭研',
    },
    // 纯文字2栏（可设二级菜单）
    {
        menu:[
            {
                name:'',
                isSubMenu:0,
                type:'urlAction',
                content:'',
            },
            {
                name:'',
                isSubMenu:0,
                type:'urlAction',
                content:'',
            },
        ],
        bottomText: 'Powered by 中移杭研',
    },
    // 纯文字3栏（可设二级菜单）
    {
        menu:[
            {
                name:'',
                isSubMenu:0,
                type:'urlAction',
                content:'',
            },
            {
                name:'',
                isSubMenu:0,
                type:'urlAction',
                content:'',
            },
            {
                name:'',
                isSubMenu:0,
                type:'urlAction',
                content:'',
            },
        ],
        bottomText: 'Powered by 中移杭研',
    },
];
import React, { useState } from 'react';
import { Modal, Row, Col,Button } from 'antd';
import { connect} from "umi";
import Preview from './Preview';
const LogoTextModal = props => {
    const { logo, bottomText, modalVisible, onCancel,appAndTableList} = props;
    const {type, menuData,} = appAndTableList;
    return (
        <Modal
            width={800}
            destroyOnClose
            title="菜单详情"
            visible={modalVisible}
            footer={[
                <Button key="back" onClick={() => {
                    onCancel();
                }}>关闭</Button>
            ]}
            onCancel={onCancel}
        >
            <Row gutter={[24, 24]}>
                <Col span={12}>
                    <Row gutter={[24, 24]}>
                        <Col span={24}>
                            <span>底部文案LOGO：</span>
                            <img src={logo} alt="" style={{ width: 50 }} />
                        </Col>
                    </Row>
                    <Row gutter={[24, 24]}>
                        <Col span={24}>
                            <span>底部文案内容：</span>
                            <span>{bottomText}</span>
                        </Col>
                    </Row>
                </Col>
                <Col span={12}>
                    <Preview
                        type={type}
                        menuData={menuData}
                    />
                </Col>
            </Row>

        </Modal>
    );
}
export default connect(({ appAndTableList }) => ({
    appAndTableList,
  }))(LogoTextModal);
import React,{ useState } from 'react';
import styles from './component.less';
import LogoTextModal from './LogoTextModal';
const LogoText = props => {

    const { type,menuData,setMenuData,disable = false } = props;
    const [ modalVisible,handleModalVisible ] = useState(false);
    return (
        <>
            <div className={styles.logoText}>
                <div 
                    className={styles.hoverBlock}
                    onClick={() => {
                        if (!disable) {
                            handleModalVisible(true);
                        }
                    }}
                >
                    <div className={styles.logo}>
                        <img src={menuData[type].logo[0].url} />
                    </div>
                    <div className={styles.mainFont}>
                        {menuData[type].bottomText}
                    </div>
                </div>
            </div>
            <LogoTextModal
                logo={menuData[type].logo[0].url}
                bottomText={menuData[type].bottomText}
                onCancel={() => {
                    handleModalVisible(false);
                }}
                modalVisible={modalVisible}
            />
        </>
    )
}

export default LogoText;
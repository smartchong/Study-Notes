import React from 'react';
import { Modal } from 'antd';
import styles from './component.less';

const AuditModal = props => {
  const { title,modalVisible, onCancel, children } = props;
  return (
    <Modal
      destroyOnClose
      wrapClassName={styles.auditModal}
      title={title}
      visible={modalVisible}
      onCancel={() => onCancel()}
      footer={null}
    >
      {children}
    </Modal>
  )
}

export default AuditModal;

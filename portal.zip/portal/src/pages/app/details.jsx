import React, { useEffect } from 'react';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import { Button, Card, Row, Col } from 'antd';
import { connect, useParams, history } from "umi";
import styles from './style.less';
// import BottomPreview from './components/BottomPreview';
import BottomPreview from './component/BottomPreview';
import defaultMenuData from './component/defaultMenuData';
const statusList = [
    {
        label: '全部',
        value: '',
    },
    {
        label: '待审核',
        value: 3,
    },
    {
        label: '审核通过',
        value: 1,
    },
    {
        label: '审核不通过',
        value: 2,
    },
];
const Details = props => {
    const params = useParams();
    const { dispatch, appAndTableList, loading } = props;
    useEffect(() => {
        if (dispatch && !loading) {
            dispatch({
                type: 'appAndTableList/queryDetails',
                payload: {
                    id: Number(params.id)
                },
                callback: (data) => {
                    if (dispatch && 'bottomMenuType' in data && 'bottomMenu' in data) {
                        const temp = JSON.parse(JSON.stringify(defaultMenuData));
                        temp[data.bottomMenuType] = JSON.parse(data.bottomMenu);
                        dispatch({
                            type: 'appAndTableList/setType',
                            payload: { data: data.bottomMenuType }
                        })
                        dispatch({
                            type: 'appAndTableList/setMenuData',
                            payload: { data: temp }
                        })
                    }
                }
            })

        }
    }, [params.id]);
    const { detailsData, type, menuData, onMenuDataChange } = appAndTableList;
    if (!detailsData || detailsData.id !== Number(params.id)) {
        return null;
    }
    return (
        <PageHeaderWrapper
            title={"产品详情"}
            content={
                <Button
                    style={{ float: 'right' }}
                    onClick={() => history.go(-1)}
                >
                    返回
                </Button>
            }
        >
            {
                detailsData.status == 1 ? (
                    <Card>
                        <Row gutter={[24, 24]}>
                            <Col span={16}>
                                <span>APP ID：</span>
                                <span className={styles.text}>{detailsData.appId}</span>
                            </Col>
                        </Row>
                        <Row gutter={[24, 24]}>
                            <Col span={16}>
                                <span>APP Secret：</span>
                                <span className={styles.text}>{detailsData.appSecret}</span>
                            </Col>
                        </Row>
                        <Row gutter={[24, 24]}>
                            <Col span={16}>
                                <span>应用LOGO：</span>
                                <img src={detailsData.appPhotoUrl} alt="" />
                            </Col>
                        </Row>
                        <Row gutter={[24, 24]}>
                            <Col span={16}>
                                <span>上行消息回调URL：</span>
                                <span className={styles.text}>{detailsData.upCallbackUrl}</span>
                            </Col>
                        </Row>
                        <Row gutter={[24, 24]}>
                            <Col span={16}>
                                <span>应用状态：</span>
                                <span className={styles.text}>{statusList.find(item => item.value === detailsData.status) ? statusList.find(item => item.value === detailsData.status).label : '-'}</span>
                            </Col>
                        </Row>
                        <Row gutter={[24, 24]}>
                            <Col span={16}>
                                <span>审核意见：</span>
                                <span className={styles.text}>{detailsData.auditReason}</span>
                            </Col>
                        </Row>
                        <Row gutter={[24, 24]}>
                            <Col span={8}>
                                <span>底部固定菜单：</span>
                                <span className={styles.text}>
                                    <BottomPreview
                                        type={type}
                                        menuData={menuData}
                                        onMenuDataChange={onMenuDataChange}
                                    />
                                </span>
                            </Col>
                        </Row>
                    </Card>
                ) : (
                        detailsData.status == 2 ? (
                            <Card>
                                <Row gutter={[24, 24]}>
                                    <Col span={16}>
                                        <span>应用LOGO：</span>
                                        <img src={detailsData.appPhotoUrl} alt="" />
                                    </Col>
                                </Row>
                                <Row gutter={[24, 24]}>
                                    <Col span={16}>
                                        <span>上行消息回调URL：</span>
                                        <span className={styles.text}>{detailsData.upCallbackUrl}</span>
                                    </Col>
                                </Row>
                                <Row gutter={[24, 24]}>
                                    <Col span={16}>
                                        <span>应用状态：</span>
                                        <span className={styles.text}>{statusList.find(item => item.value === detailsData.status) ? statusList.find(item => item.value === detailsData.status).label : '-'}</span>
                                    </Col>
                                </Row>
                                <Row gutter={[24, 24]}>
                                    <Col span={16}>
                                        <span>审核意见：</span>
                                        <span className={styles.text}>{detailsData.auditReason}</span>
                                    </Col>
                                </Row>
                                <Row gutter={[24, 24]}>
                                    <Col span={8}>
                                        <span>底部固定菜单：</span>
                                        <span className={styles.text}>
                                            <BottomPreview
                                                type={type}
                                                menuData={menuData}
                                                onMenuDataChange={onMenuDataChange}
                                            />
                                        </span>
                                    </Col>
                                </Row>
                            </Card>
                        ) : (
                                <Card>
                                    <Row gutter={[24, 24]}>
                                        <Col span={16}>
                                            <span>应用LOGO：</span>
                                            <img src={detailsData.appPhotoUrl} alt="" />
                                        </Col>
                                    </Row>
                                    <Row gutter={[24, 24]}>
                                        <Col span={16}>
                                            <span>上行消息回调URL：</span>
                                            <span className={styles.text}>{detailsData.upCallbackUrl}</span>
                                        </Col>
                                    </Row>
                                    <Row gutter={[24, 24]}>
                                        <Col span={16}>
                                            <span>应用状态：</span>
                                            <span className={styles.text}>{statusList.find(item => item.value === detailsData.status) ? statusList.find(item => item.value === detailsData.status).label : '-'}</span>
                                        </Col>
                                    </Row>
                                    <Row gutter={[24, 24]}>
                                        <Col span={16}>
                                            <span>审核意见：</span>
                                            <span className={styles.text}>{detailsData.auditReason}</span>
                                        </Col>
                                    </Row>
                                    <Row gutter={[24, 24]}>
                                        <Col span={8}>
                                            <span>底部固定菜单：</span>
                                            <span className={styles.text}>
                                                <BottomPreview
                                                    type={type}
                                                    menuData={menuData}
                                                    onMenuDataChange={onMenuDataChange}
                                                />
                                            </span>
                                        </Col>
                                    </Row>
                                </Card>
                            )
                    )
            }
        </PageHeaderWrapper>
    )
}

export default connect(({ appAndTableList, loading }) => ({
    appAndTableList,
    loading: loading.effects['appAndTableList/queryDetails'],
}))(Details);




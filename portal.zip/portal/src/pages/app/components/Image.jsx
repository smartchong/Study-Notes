import React,{ useState } from 'react';
import { Button,Modal } from 'antd';
import styles from './component.less';

const Image = (props) => {

    const { src,title="查看图片" } = props; 
    const [modalVisible,handleModalVisible] = useState(false);
    const onCancel = () => {
        handleModalVisible(false);
    }
    const onShow = () => {
        handleModalVisible(true);
    }
    const renderFile = (url) => {
        return (
            <img
                src={url}
            />
        )
    }

    return (
        <>
            <img
            style={{width:50,height:50}} 
                className={styles.image}
                src={src} 
                onClick={onShow}
            />
            <Modal
                destroyOnClose
                title={title}
                visible={modalVisible}
                onCancel={onCancel}
                wrapClassName={styles.imageModal}
                width={520}
                footer={[
                    <Button key="back" onClick={onCancel}>关闭</Button>
                ]}
            >
                { renderFile(src) }
            </Modal> 
        </>
    );
}

export default Image;
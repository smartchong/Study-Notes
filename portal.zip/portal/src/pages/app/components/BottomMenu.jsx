import React,{ useState,forwardRef,useImperativeHandle } from 'react';
import { Space,Divider } from 'antd';
import PlainText from './PlainText';
import IconText from './IconText';
import LogoText from './LogoText';
import BottomText from './BottomText';
import classNames from 'classnames';
import validate from './validate';
import styles from './component.less';
import defaultMenuData from './defaultMenuData';

const BottomMenu = (props,ref) => {
    const { type,detailData,onMenuDataChange } = props;
    const setDefaultMenuData = () => {
        if (detailData) {
            const tempData = JSON.parse(JSON.stringify(defaultMenuData));
            tempData[type] = detailData;
            return tempData;
        }
        return JSON.parse(JSON.stringify(defaultMenuData));
    };
    const [menuData,handleMenuData] = useState(setDefaultMenuData());
    const setMenuData = (callBack)=>{
        let temp = JSON.parse(JSON.stringify(menuData));
        handleMenuData(callBack(temp));
        onMenuDataChange(callBack(temp));
    };
    const customProps = {
        type,
        menuData,
        defaultMenuData,
        setMenuData,
    };
    const renderMenu = (type,restProp) => {
        switch(type) {
            case 1:
                return (
                    <Space 
                        className={classNames(styles.oneBox,styles.two)}
                        split={<Divider type="vertical" size="middle" />}
                    >
                        <LogoText
                            key={`logo${type}`} 
                            {...restProp}
                        />
                        <IconText
                            key={`${type}0`}
                            index={0}
                            {...restProp}
                        />
                    </Space>
                );
            case 2:
                return (
                    <Space 
                        className={classNames(styles.oneBox,styles.three)}
                        split={<Divider type="vertical" size="middle" />}
                    >
                        <LogoText 
                            key={`logo${type}`}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}0`}
                            index={0}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}1`}
                            index={1}
                            {...restProp}
                        />
                    </Space>
                );
            case 3: 
                return (
                    <Space 
                        className={classNames(styles.oneBox,styles.four)}
                        split={<Divider type="vertical" size="middle" />}
                    >
                        <LogoText 
                            key={`logo${type}`}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}0`}
                            index={0}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}1`}
                            index={1}
                            {...restProp}
                        />
                        <IconText
                            key={`${type}2`}
                            index={2}
                            {...restProp}
                        />
                    </Space>
                );
            case 4: 
                return (
                    <>
                        <Space 
                            className={classNames(styles.topBox,styles.two)}
                            split={<Divider type="vertical" size="middle" />}
                        >
                            <IconText
                                key={`${type}0`}
                                index={0}
                                {...restProp}
                            />
                            <IconText
                                key={`${type}1`}
                                index={1}
                                {...restProp}
                            />
                        </Space>
                        <Space className={styles.bottomBox}>
                            <BottomText 
                                key={type}
                                {...restProp}
                            /> 
                        </Space>
                    </>
                );
            case 5:
                return (
                    <>
                        <Space 
                            className={classNames(styles.topBox,styles.three)}
                            split={<Divider type="vertical" size="middle" />}
                        >
                            <IconText
                                key={`${type}0`}
                                index={0}
                                {...restProp}
                            />
                            <IconText
                                key={`${type}1`}
                                index={1}
                                {...restProp}
                            />
                            <IconText
                                key={`${type}2`}
                                index={2}
                                {...restProp}
                            />
                        </Space> 
                        <Space className={styles.bottomBox}>
                            <BottomText 
                                key={type}
                                {...restProp}
                            /> 
                        </Space>
                    </>
                );
            case 6:
                return (
                    <>
                        <Space 
                            className={classNames(styles.topBox,styles.two)}
                            split={<Divider type="vertical" size="middle" />}
                        >
                            <PlainText 
                                {...restProp}
                                index={0}
                            />
                            <PlainText 
                                {...restProp}
                                index={1}
                            />
                        </Space>
                        <Space className={styles.bottomBox}>
                            <BottomText 
                                key={type}
                                {...restProp}
                            /> 
                        </Space>
                    </>
                );
            case 7: 
                return (
                    <>
                        <Space 
                            className={classNames(styles.topBox,styles.three)}
                            split={<Divider type="vertical" size="middle" />}
                        >
                            <PlainText 
                                {...restProp}
                                index={0}
                            />
                            <PlainText 
                                {...restProp}
                                index={1}
                            />
                            <PlainText 
                                {...restProp}
                                index={2}
                            />
                        </Space>
                        <Space className={styles.bottomBox}>
                            <BottomText 
                                key={type}
                                {...restProp}
                            /> 
                        </Space>
                    </>
                );    
            default:
        }
    };
    useImperativeHandle(ref,()=>({
        menuData:menuData[type],
        validator:()=>validate(Number(type),menuData),
    }));

    return (
        <div className={styles.bottomMenu}>
            {renderMenu(type,customProps)}
        </div>
    );
}

export default forwardRef(BottomMenu);
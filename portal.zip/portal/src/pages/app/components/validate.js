const validate = (type,data) => {
    let isOk = true;
    const temp = JSON.parse(JSON.stringify(data[type]));
    switch(type) {
        case 1:
        case 2:
        case 3:
        case 4:
        case 5:
            temp.menu.forEach(item => {
                if (item.name === '' || item.content === '') {
                    isOk = false;
                }
            })
            break;
        case 6:
        case 7:
            temp.menu.forEach(item => {
                if (item.isSubMenu === 1) {
                    item.subMenu.forEach(_ => {
                        if (_.name === '' || _.content === '') {
                            isOk = false;
                        }
                    })
                } else if (item.isSubMenu === 0) {
                    if (item.name === '') {
                        isOk = false;
                    }
                }
            })
            break;
        default:
            isOk = false;
    }
    return isOk;
}

export default validate;
import { Modal } from 'antd';

const ImageModal = props => {

    const { visible,title,image,handleCancel } = props;

    return (
        <Modal
          visible={visible}
          title={title}
          footer={null}
          onCancel={handleCancel}
        >
          <img 
            alt={title} 
            style={{ width: '100%' }} 
            src={image} 
          />
        </Modal>
    )
}

export default ImageModal;
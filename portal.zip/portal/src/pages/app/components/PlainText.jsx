import React,{ useState } from 'react';
import PlainTextModal from './PlainTextModal';
import styles from './component.less';

const PlainText = props => {

    const { type,index,menuData,setMenuData,disable = false } = props;
    const [ modalVisible,handleModalVisible ] = useState(false);

    return (
        <>
            <div className={styles.plainText}>
                <div 
                    className={styles.hoverBlock} 
                    onClick={() => {
                        if (!disable) {
                            handleModalVisible(true);
                        }
                    }}
                >
                    <div className={styles.mainFont}>
                        {menuData[type].menu[index].name ? menuData[type].menu[index].name : '菜单名称'}
                    </div>
                </div>
            </div>
            <PlainTextModal
                menu={menuData[type].menu[index]}
                onSubmit={(values) => {
                    handleModalVisible(false);
                    setMenuData((menuData) => {
                        menuData[type].menu[index] = values;
                        return menuData;
                    })
                }}
                onCancel={() => {
                    handleModalVisible(false);
                }}
                modalVisible={modalVisible}
            />  
        </>
    )
}

export default PlainText;
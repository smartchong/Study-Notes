import React, { useState } from 'react';
import PlainTextModal from './PlainTextModal';
// import styles from '../component/component.less';
import styles from './component.less';
const PlainText = props => {

    const { type, index, menuData, setMenuData, disable = false } = props;
    const [modalVisible, handleModalVisible] = useState(false);

    return (
        <>
            <div className={styles.plainText}>
                <div
                    className={styles.hoverBlock}
                    onClick={() => {
                        if (menuData[type].menu[index].type === 'urlAction' && menuData[type].menu[index].isSubMenu !== 1 && menuData[type].menu[index].content !== '') {
                            // window.open =`${menuData[type].menu[index].content}`
                            window.open(menuData[type].menu[index].content)
                        }
                    }}
                >
                    <div className={styles.mainFont}
                    >
                        {menuData[type].menu[index].name ? menuData[type].menu[index].name : '菜单名称'}

                        {
                            menuData[type].menu[index].isSubMenu == 1 ? <div className={styles.mainFont_w}
                            >
                                {
                                    menuData[type].menu[index].subMenu.map((item, index) =>
                                        <div className={styles.mainFont_q}
                                            onClick={() => {
                                                if (item.type === 'urlAction') {
                                                    // location.href =`${item.content}`
                                                    window.open(item.content)
                                                }
                                            }}
                                        >
                                            {item.name}
                                        </div>
                                    )
                                }
                            </div> : null
                        }
                    </div>
                </div>
            </div>
            <PlainTextModal
                menu={menuData[type].menu[index]}
                onCancel={() => {
                    handleModalVisible(false);
                }}
                modalVisible={modalVisible}
            />
        </>
    )
}

export default PlainText;
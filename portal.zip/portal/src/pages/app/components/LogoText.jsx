import React,{ useState } from 'react';
import LogoTextModal from './LogoTextModal';
import styles from './component.less';

const LogoText = props => {

    const { type,menuData,setMenuData,disable = false } = props;
    const [ modalVisible,handleModalVisible ] = useState(false);
    
    return (
        <>
            <div className={styles.logoText}>
                <div 
                    className={styles.hoverBlock} 
                    onClick={() => {
                        if (!disable) {
                            handleModalVisible(true);
                        }
                    }}
                >
                    <div className={styles.logo}>
                        <img src={menuData[type].logo[0].url} />
                    </div>
                    <div className={styles.mainFont}>
                        {menuData[type].bottomText}
                    </div>
                </div>
            </div>
            <LogoTextModal
                logo={menuData[type].logo}
                bottomText={menuData[type].bottomText}
                onSubmit={(value) => {
                    handleModalVisible(false);
                    setMenuData((menuData) => {
                        menuData[type].logo = value.logo;
                        menuData[type].bottomText = value.bottomText;
                        return menuData;
                    })
                }}
                onCancel={() => {
                    handleModalVisible(false);
                }}
                modalVisible={modalVisible}
            />  
        </>
    )
}

export default LogoText;
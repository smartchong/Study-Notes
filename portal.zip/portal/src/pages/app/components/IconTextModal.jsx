import React from 'react';
import { phonePattern,urlPattern } from '@/utils/regex';
import { Modal,Form,Input,Button,Upload,Select } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import { getUploadAction } from '../service';
import Cookie from "js-cookie";
import styles from './component.less';
const FormItem = Form.Item;
const { Option } = Select;
const formLayout = {
    labelCol: {
        span: 7,
    },
    wrapperCol: {
        span: 13,
    },
};
const menuTypeList = [
    { label:'添加链接',value:'urlAction' },
    { label:'添加回复',value:'replyAction' },
    { label:'拨打电话',value:'dialerAction' },
];
const normFile = e => {
    if (Array.isArray(e)) {
        return e;
    }
    return e && e.fileList;
};

const IconTextModal = props => {
    const [form] = Form.useForm();
    const { menu,onSubmit,onCancel,modalVisible } = props;
    const validateIcon = async (_, value) => {
        const promise = Promise;
        if (value && value.length) {
          if (value.length > 1) {
            return promise.reject('仅支持单个文件上传！');
          } else {
            if (value[0].size && value[0].size > 500 * 1024) {
              return promise.reject('图片大小超出限制，请重新上传！');
            }
            if (value[0].type && value[0].type !== 'image/png') {
              return promise.reject('请上传正确格式的图片！');
            }
          }
          return promise.resolve();
        }
    }

    return (
        <Modal
            destroyOnClose
            title="信息配置"
            visible={modalVisible}
            onOk={() => {
                form.validateFields().then(values => {
                    if (values.icon.length && values.icon[0]?.response?.success && values.icon[0]?.response?.data) {
                        values.icon[0].name = values.icon[0].response.data?.appPhotoKey;
                        values.icon[0].url = values.icon[0].response.data?.appPhotoUrl;
                    }
                    onSubmit(values);
                });
            }}
            onCancel={() => {
                form.resetFields();
                onCancel();
            }}
        >
            <Form
                {...formLayout}
                form={form}
                initialValues={{
                    ...menu,
                }}
            >
                <FormItem
                    label="菜单图标"
                    name="icon"
                    getValueFromEvent={normFile}
                    valuePropName={"fileList"}
                    extra={<>建议上传图片尺寸192*192px，格式为PNG，大小不超过500K</>}
                    rules={[
                        {
                            required: true,
                            message: '请上传菜单图标！',
                        },
                        {
                            validator: validateIcon
                        }
                    ]}
                >
                    <Upload
                        className={styles.customUpload}
                        action={getUploadAction}
                        accept='.png'
                        listType="picture-card"
                        headers={{
                            'X-XSRF-TOKEN': Cookie.get('XSRF-TOKEN')
                        }}
                        beforeUpload={(file) => {
                            if (file.type !== 'image/png') {
                                return false;
                            }
                            if (file.size > 500 * 1024) {
                                return false;
                            }
                            return true;
                        }}
                    >
                        <Button>
                            <UploadOutlined /> 上传图标
                        </Button>
                    </Upload>
                </FormItem>
                <FormItem
                    label="菜单名称"
                    name="name"
                    rules={[
                        {
                            required: true,
                            message: '请输入菜单名称！',
                        },
                        {
                            pattern: /^([\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]){2,5}$/,
                            message: '请输入正确格式的菜单名称！',
                        }
                    ]}
                >
                    <Input 
                        maxLength={5}
                        placeholder="请输入2-5个字的菜单名称"  
                    />
                </FormItem>
                <FormItem
                    label="菜单类型"
                    name="type"
                    rules={[
                        {
                            required: true,
                            message: '请选择菜单类型！',
                        }
                    ]}
                >
                    <Select
                        placeholder='请选择'
                    >
                        {
                            menuTypeList.map(item => (
                                <Option 
                                    key={item.value}
                                    value={item.value} 
                                >
                                    {item.label}
                                </Option>
                            ))
                        }
                    </Select>
                </FormItem>
                <FormItem
                    noStyle
                    shouldUpdate={(prevValue,curValue) => prevValue.type !== curValue.type}
                >
                    {
                        ({ getFieldValue }) => {
                            const type = getFieldValue('type');
                            if (type === 'urlAction') {
                                return (
                                    <FormItem
                                        label="菜单内容"
                                        name="content"
                                        rules={[
                                            {
                                                required: true,
                                                message: '请输入菜单内容！',
                                            },
                                            {
                                                pattern: urlPattern,
                                                message:'请输入正确格式的菜单内容！',
                                            }
                                        ]}
                                    >
                                        <Input 
                                            maxLength={1024}
                                            placeholder={"请输入以http或https开头的地址"}
                                        />
                                    </FormItem>
                                )
                            } else if (type === 'replyAction') {
                                return (
                                    <FormItem
                                        label="菜单内容"
                                        name="content"
                                        rules={[
                                            {
                                                required: true,
                                                message: '请输入菜单内容！',
                                                whiteSpace: true,
                                            },
                                        ]}
                                    >
                                        <Input 
                                            maxLength={300}
                                            placeholder={"请输入回复文本"}
                                        />
                                    </FormItem>
                                )
                            } else if (type === 'dialerAction') {
                                return (
                                    <FormItem
                                        label="菜单内容"
                                        name="content"
                                        rules={[
                                            {
                                                required: true,
                                                message: '请输入菜单内容！',
                                            },
                                            {
                                                pattern: phonePattern,
                                                message:'请输入正确格式的菜单内容！',
                                            }
                                        ]}
                                    >
                                        <Input 
                                            maxLength={20}
                                            placeholder={"请输入电话号码"}
                                        />
                                    </FormItem>
                                )
                            }   
                        }
                    }
                </FormItem>
            </Form>
        </Modal>
    );
}

export default IconTextModal;
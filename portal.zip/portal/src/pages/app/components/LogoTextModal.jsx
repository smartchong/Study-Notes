import React from 'react';
import { Modal,Form,Input,Button,Upload } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import { getUploadAction } from '../service';
import Cookie from "js-cookie";
import styles from './component.less';
const FormItem = Form.Item;
const formLayout = {
    labelCol: {
        span: 7,
    },
    wrapperCol: {
        span: 13,
    },
};
const normFile = e => {
    if (Array.isArray(e)) {
        return e;
    }
    return e && e.fileList;
};

const LogoTextModal = props => {
    const [form] = Form.useForm();
    const { logo,bottomText,onSubmit,onCancel,modalVisible } = props;
    const validateLogo = async (_, value) => {
        const promise = Promise;
        if (value && value.length) {
          if (value.length > 1) {
            return promise.reject('仅支持单个文件上传！');
          } else {
            if (value[0].size && value[0].size > 500 * 1024) {
              return promise.reject('图片大小超出限制，请重新上传！');
            }
            if (value[0].type && value[0].type !== 'image/png') {
              return promise.reject('请上传正确格式的图片！');
            }
          }
          return promise.resolve();
        }
    }
    const validateBottomText = async (_, value) => {
        const promise = Promise;

        if (value) {
            if (/^[\s\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]{2,20}$/.test(value) && /^(?=.*\S).+$/.test(value)) {
                return promise.resolve();    
            }
            return promise.reject('请输入正确格式的底部文案！');
        }
    }

    return (
        <Modal
            destroyOnClose
            title="信息配置"
            visible={modalVisible}
            onOk={() => {
                form.validateFields().then(values => {
                    if (values.logo.length && values.logo[0]?.response?.success && values.logo[0]?.response?.data) {
                        values.logo[0].name = values.logo[0].response.data?.appPhotoKey;
                        values.logo[0].url = values.logo[0].response.data?.appPhotoUrl;
                    }
                    onSubmit(values);
                });
            }}
            onCancel={() => {
                onCancel();
                form.resetFields();
            }}
        >
            <Form
                {...formLayout}
                form={form}
                initialValues={{
                    logo:logo,
                    bottomText:bottomText,
                }}
            >
                <FormItem
                    label="LOGO样式"
                    name="logo"
                    getValueFromEvent={normFile}
                    valuePropName={"fileList"}
                    extra={<>建议上传图片尺寸（368～944）*160px，格式为PNG，大小不超过500K</>}
                    rules={[
                        {
                            required: true,
                            message: '请上传LOGO！',
                        },
                        {
                            validator: validateLogo
                        }
                    ]}
                >
                    <Upload
                        className={styles.customUpload}
                        action={getUploadAction}
                        accept='.png'
                        listType="picture-card"
                        headers={{
                            'X-XSRF-TOKEN': Cookie.get('XSRF-TOKEN')
                        }}
                        beforeUpload={(file) => {
                            if (file.type !== 'image/png') {
                                return false;
                            }
                            if (file.size > 500 * 1024) {
                                return false;
                            }
                            return true;
                        }}
                    >
                        <Button>
                            <UploadOutlined /> 上传LOGO
                        </Button>
                    </Upload>
                </FormItem>
                <FormItem
                    label="底部文案"
                    name="bottomText"
                    rules={[
                        {
                            required: true,
                            message: '请输入底部文案！',
                        },
                        {
                            validator: validateBottomText,
                        }
                    ]}
                >
                    <Input 
                        placeholder="请输入2-20个字的底部文案" 
                        maxLength={20}
                    />
                </FormItem>
            </Form>
        </Modal>
    );
}
export default LogoTextModal;
import React,{ useRef,useState } from 'react';
import { Button, Form, Input, Select, Space, Upload, Typography, message } from 'antd';
import { UploadOutlined } from '@ant-design/icons';
import BottomMenu from './BottomMenu';
import ImageModal from './ImageModal';
import { checkAppName,getUploadAction } from '../service';
import Cookie from "js-cookie";
const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;
const { Text } = Typography;
const formLayout = {
  labelCol: {
    span: 6,
  },
  wrapperCol: {
    span: 14,
  },
};
const normFile = e => {
  if (Array.isArray(e)) {
    return e;
  }
  return e && e.fileList;
};
const bottomMenuTypeList = [
  { label:'品牌LOGO+1个菜单',value:1 },
  { label:'品牌LOGO+2个菜单',value:2 },
  { label:'品牌LOGO+3个菜单',value:3 },
  { label:'小图标+文字2栏',value:4 },
  { label:'小图标+文字3栏',value:5 },
  { label:'纯文字2栏（可设二级菜单）',value:6 },
  { label:'纯文字3栏（可设二级菜单）',value:7 },
];

const AppForm = (props) => {
  const [form] = Form.useForm();
  const bottomMenuRef = useRef();
  const [previewVisible,handlePreviewVisible] = useState(false);
  const [previewImage,handlePreviewImage] = useState('');
  const [previewTitle,handlePreviewTitle] = useState('');
  const {
    chatbotTypeList,
    onMenuDataChange,
    onTypeChange,
    onSubmit,
    onCancel,
    loading,
    detailData,
    id='',
  } = props;

  const okHandle = (values) => {
    const result = bottomMenuRef.current.validator();
    
    if (result) {
      values.bottomMenu = JSON.stringify(bottomMenuRef.current.menuData);
      if (values.appLogo[0].response?.data) {
        values.appPhotoKey = values.appLogo[0].response.data.appPhotoKey;
        values.appPhotoUrl = values.appLogo[0].response.data.appPhotoUrl;
      } else {
        values.appPhotoKey = values.appLogo[0].name;
        values.appPhotoUrl = values.appLogo[0].url;
      }
      onSubmit(values,()=>{
        form.resetFields();
      });
    } else {
      message.error('请配置底部固定菜单！');
    }
  };

  const validateAppName = async (appName) => {
    const ret = await checkAppName({
      appName,
      id,
    });
    if(ret && ret.success){
      return true;
    }else {
      return false;
    }
  }

  const validateAppLogo = async (_, value) => {
    const promise = Promise;
    if (value && value.length) {
      if (value.length > 1) {
        return promise.reject('仅支持单个文件上传！');
      } else {
        if (value[0].size && value[0].size > 500 * 1024) {
          return promise.reject('图片大小超出限制，请重新上传！');
        }
        if (value[0].type && value[0].type !== 'image/png' && value[0].type !== 'image/jpeg') {
          return promise.reject('请上传正确格式的图片！');
        }
      }
      return promise.resolve();
    }
  }

  const getBase64 = file => {
    return new Promise((resolve,reject) => {
      const reader = new FileReader();
      reader.readAsDataURL(file);
      reader.onload = () => resolve(reader.result);
      reader.onerror = error => reject(error);
    });
  }

  const handlePreview = async file => {
    if (!file.url && !file.preview) {
      file.preview = await getBase64(file.originFileObj);
    }
    handlePreviewVisible(true);
    handlePreviewImage(file.url || file.preview);
    handlePreviewTitle(file.name || file.url.substring(file.url.lastIndexOf('/') + 1));
  }

  return (
    <>
      <Form
        {...formLayout}
        form={form}
        hideRequiredMark={true}
        onFinish={okHandle}
        initialValues={{
          appName: detailData && detailData.appName ? detailData.appName : undefined,
          appLogo: detailData && detailData.appPhotoKey && detailData.appPhotoUrl ? 
                  [
                    {
                      uid:detailData.appPhotoKey,
                      name:detailData.appPhotoKey,
                      status: 'done',
                      url:detailData.appPhotoUrl,
                    }
                  ] : [],
          chatbotType: detailData && detailData.chatbotType ? detailData.chatbotType : undefined,
          description: detailData && detailData.description ? detailData.description : undefined,
          upCallbackUrl: detailData && detailData.upCallbackUrl ? detailData.upCallbackUrl : undefined,
          bottomMenuType: detailData && detailData.bottomMenuType ? detailData.bottomMenuType : 1,
        }}
      >
        <FormItem
          label="应用名称"
          name="appName"
          maxLength={30}
          normalize={(value) => value.replace(/\s+/g,'')}
          validateTrigger={"onBlur"}
          rules={[
            {
              required: true,
              message: '请输入应用名称！',
            },
            ({ getFieldValue })  => ({
              async validator(rule, value) {
                if (!value || await validateAppName(value)) {
                  return Promise.resolve();
                }
                return Promise.reject('该应用名称已存在，请重新输入！');
              },
            }),
          ]}
        >
          <Input 
            placeholder="请输入应用名称，30个字符数以内。" 
            maxLength={30}
          />
        </FormItem>
        <FormItem
          label="应用LOGO"
          name={"appLogo"}
          getValueFromEvent={normFile}
          valuePropName={"fileList"}
          extra={<>仅支持JPG、PNG格式，建议LOGO图片为正圆形，尺寸不超过200X200，大小不超过500K。<br /><Text type="danger">注：该功能当前只适用于H5 Chatbot，短信小程序/5G消息暂不适用</Text></>}
          rules={[
            {
              required: true,  
              message: '请上传应用LOGO！',
            },
            {
              validator: validateAppLogo
            }
          ]}
        >
          <Upload
            action={getUploadAction}
            accept='.png,.jpg'
            listType="picture"
            headers={{
              'X-XSRF-TOKEN': Cookie.get('XSRF-TOKEN')
            }}
            beforeUpload={(file) => {
              if (file.type !== 'image/jpeg' && file.type !== 'image/png') {
                return false;
              }
              if (file.size > 500 * 1024) {
                return false;
              }
              return true;
            }}
            onPreview={handlePreview}
          >
            <Button>
              <UploadOutlined /> {detailData ? '更改图片' : '上传图片'}
            </Button>
          </Upload>
        </FormItem>
        <FormItem
          label="所属业务"
          name="chatbotType"
          rules={[
            {
              required: true,
              message: '请选择应用所属业务！',
            },
          ]}
        >
          <Select
            placeholder={'请选择'}
          >
            {
              chatbotTypeList.map(item => (
                <Option
                  key={item.value}
                  value={item.value}
                >
                  {item.label}
                </Option>
              ))
            }
          </Select>
        </FormItem>
        <FormItem
          label="应用描述"
          name="description"
          rules={[
            {
              required: true,
              message: '请输入应用描述！',
              whitespace: true,
            },
          ]}
        >
          <TextArea 
            placeholder="请输入应用描述，300个字符数以内。" 
            maxLength={300}
            rows={4}
          />
        </FormItem>
        <FormItem
          label="上行消息回调URL"
          name="upCallbackUrl"
          rules={[
            {
              required: true,
              message: '请输入上行消息回调URL！',
            },
            {
              type:'url',
              message:'URL格式错误，请重新输入！'
            }
          ]}
        >
          <TextArea 
            placeholder="请输入上行消息回调URL，300个字符数以内。" 
            maxLength={300}
            rows={4}
          />
        </FormItem>
        {/* 底部固定菜单 */}
        <FormItem
          label="底部固定菜单"
          name="bottomMenuType"
          extra={<Text type="danger">注：该底部固定菜单当前只适用于H5 Chatbot，对短信小程序/5G消息暂不适用</Text>}
          rules={[
            {
              required: true,
              message: '请选择底部固定菜单！',
            },
          ]}
        >
          <Select
            placeholder={'请选择'}
            onSelect={(v) => {
              onTypeChange(v);
            }}
          >
            {
              bottomMenuTypeList.map(item => (
                <Option
                  key={item.value}
                  value={item.value}
                >
                  {item.label}
                </Option>
              ))
            }
          </Select>
        </FormItem>
        <FormItem
          wrapperCol={{
            offset: 2,
            span: 18,
          }}
          shouldUpdate={(prevValue, curValue) => {
            return prevValue.bottomMenuType !== curValue.bottomMenuType;
          }}
        >
          {({ getFieldValue }) => {
            const bottomMenuType = getFieldValue('bottomMenuType');
            return (
              <BottomMenu 
                ref={bottomMenuRef}
                type={bottomMenuType}
                onMenuDataChange={onMenuDataChange} 
                detailData={detailData ? JSON.parse(detailData.bottomMenu) : null}
              />
            );
          }}  
        </FormItem>
        {/* 操作 */}
        <FormItem
          wrapperCol={{
            offset: 6
          }}
        >
          <Space
            size={'large'}
          >
            <Button
              onClick={() => {
                form.resetFields();
                onCancel();
              }}
            >
              取消
            </Button>
            <Button
              type={'primary'}
              htmlType={'submit'}
              loading={loading}
            >
              提交
            </Button>
          </Space>
        </FormItem>
      </Form>
      <ImageModal 
        image={previewImage}
        title={previewTitle}
        visible={previewVisible}
        handleCancel={() => handlePreviewVisible(false)}
      />
    </>
  );
};

export default AppForm;

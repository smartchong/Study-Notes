import React,{ useState,useEffect } from 'react';
import { Button, Input } from 'antd';

const SearchInput = props => {
  const { placeholder,onSearch,onReset } = props;
  const [search,setSearch] = useState(props.value);
  useEffect(() => {
    setSearch(props.value)
  },[props.value]);

  return (
    <div
      style={{
        textAlign: 'center',
      }}
    >
      <Input.Search
        placeholder={placeholder}
        enterButton="搜索"
        size="large"
        style={{
          maxWidth: 520,
          width: '100%',
        }}
        value={search}
        onChange={(e) => setSearch(e.target.value)}
        onSearch={(value) => onSearch(value)}
      />
      <Button
        style={{height:40}}
        type={'link'}
        onClick={onReset}
      >重置</Button>
    </div>
  )
};
SearchInput.defaultProps = {
  placeholder:'请输入',
  onSearch:() => {},
  onReset: () => {}
};

export default SearchInput;

import React from 'react';
import BottomPreview from './BottomPreviews';
import styles from './component.less';

const Preview  = (props) => {
    const { type,menuData } = props;

    return (
        <div className={styles.previewWrap}>
            <div className={styles.body}>
                <div className={styles.main}>
                    
                </div>
                <div className={styles.bottom}>
                    <BottomPreview
                        type={type}
                        menuData={menuData}
                    />
                </div>
            </div>
        </div>
    )
}
export default Preview;
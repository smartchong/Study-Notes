import React from 'react';
import { phonePattern,urlPattern } from '@/utils/regex';
import { Modal,Form,Input,Radio,Select,Row,Col } from 'antd';
import { PlusCircleTwoTone } from '@ant-design/icons';
import DeleteIcon from './DeleteIcon';
import styles from './component.less';
const FormItem = Form.Item;
const { Option } = Select;
const formLayout = {
    labelCol: {
        span: 7,
    },
    wrapperCol: {
        span: 13,
    },
};
const menuTypeList = [
    { label:'添加链接',value:'urlAction' },
    { label:'添加回复',value:'replyAction' },
    { label:'拨打电话',value:'dialerAction' },
];

const PlainTextModal = props => {
    const [form] = Form.useForm();
    const { menu,onSubmit,onCancel,modalVisible } = props;

    return (
        <Modal
            destroyOnClose
            title="信息配置"
            visible={modalVisible}
            onOk={() => {
                form.validateFields().then(values => {
                    onSubmit(values);
                });
            }}
            onCancel={() => {
                form.resetFields();
                onCancel();
            }}
        >
            <Form
                {...formLayout}
                form={form}
                initialValues={{
                    ...menu,
                }}
            >
                <FormItem
                    label="菜单名称"
                    name="name"
                    rules={[
                        {
                            required: true,
                            message: '请输入菜单名称！',
                        },
                        {
                            pattern: /^([\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]){2,5}$/,
                            message: '请输入正确格式的菜单名称！',
                        }
                    ]}
                >
                    <Input 
                        maxLength={5}
                        placeholder="请输入2-5个字的菜单名称"  
                    />
                </FormItem>
                <FormItem
                    label="二级菜单"
                    name="isSubMenu"
                    rules={[
                        {
                            required: true,
                            message: '请选择二级菜单！',
                        }
                    ]}
                >
                    <Radio.Group>
                        <Radio value={1}>是</Radio>
                        <Radio value={0}>否</Radio>
                    </Radio.Group>
                </FormItem>
                <FormItem
                    noStyle
                    shouldUpdate={(prevValue,curValue) => prevValue.isSubMenu !== curValue.isSubMenu}
                >
                    {
                        ({ getFieldValue,setFieldsValue }) => {
                            const isSubMenu = Number(getFieldValue('isSubMenu'));
                            // 存在二级菜单
                            if (isSubMenu === 1) {
                                if (!getFieldValue('subMenu')) {
                                    setFieldsValue({
                                        subMenu: [
                                            {
                                                type: 'urlAction',
                                                name: '',
                                                content: '',
                                            }
                                        ]
                                    });
                                }
                                return (
                                    <Form.List
                                        name="subMenu"
                                    >
                                        {
                                            (fields, { add, remove }) => (
                                                <>
                                                    {fields.map((field,index) => {
                                                        return (
                                                            <React.Fragment key={field.key}>
                                                                <Form.Item 
                                                                    label={<label style={{fontSize:16,fontWeight:600}}>菜单{index+1}</label>}
                                                                >
                                                                    {
                                                                        fields.length > 1 ? (
                                                                            <DeleteIcon 
                                                                                onClick={() => {
                                                                                    remove(field.name);
                                                                                }}
                                                                            />
                                                                        ) : null
                                                                    }
                                                                </Form.Item>
                                                                <Form.Item
                                                                    label="菜单类型"
                                                                    name={[field.name, 'type']}
                                                                    rules={[
                                                                        { required: true, message: '请选择菜单类型！' },
                                                                    ]}
                                                                >
                                                                    <Select
                                                                        placeholder='请选择'
                                                                    >
                                                                        {
                                                                            menuTypeList.map((item) => (
                                                                                <Option 
                                                                                    key={item.value}
                                                                                    value={item.value} 
                                                                                >
                                                                                    {item.label}
                                                                                </Option>
                                                                            ))
                                                                        }
                                                                    </Select>
                                                                </Form.Item>
                                                                <Form.Item
                                                                    label="菜单名称"
                                                                    name={[field.name, 'name']}
                                                                    rules={[
                                                                        { required: true, message: '请输入菜单名称！' },
                                                                        {
                                                                            pattern: /^([\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]){2,5}$/,
                                                                            message: '请输入正确格式的菜单名称！',
                                                                        }
                                                                    ]}
                                                                >
                                                                    <Input
                                                                        maxLength={5}
                                                                        placeholder={"请输入2-5个字符的菜单名称"}
                                                                    />
                                                                </Form.Item>
                                                                <Form.Item 
                                                                    noStyle 
                                                                    shouldUpdate={(prevValue,curValue) => {
                                                                        return prevValue.subMenu.length === curValue.subMenu.length && prevValue.subMenu[field.name].type !== curValue.subMenu[field.name].type;
                                                                    }}
                                                                >
                                                                    {
                                                                        ({ getFieldValue }) => {
                                                                            const subMenu = getFieldValue('subMenu');
                                                                            if (subMenu[field.name].type === 'urlAction') {
                                                                                return (
                                                                                    <Form.Item
                                                                                        label="菜单内容"
                                                                                        name={[field.name, 'content']}
                                                                                        rules={[
                                                                                            { required: true, message: '请输入菜单内容！' },
                                                                                            {
                                                                                                pattern: urlPattern,
                                                                                                message:'请输入正确格式的菜单内容！',
                                                                                            },
                                                                                        ]}
                                                                                    >
                                                                                        <Input
                                                                                            maxLength={1024}
                                                                                            placeholder={"请输入以http或https开头的地址"}
                                                                                        />
                                                                                    </Form.Item>
                                                                                )
                                                                            } else if (subMenu[field.name].type === 'replyAction') {
                                                                                return (
                                                                                    <Form.Item
                                                                                        label="菜单内容"
                                                                                        name={[field.name, 'content']}
                                                                                        rules={[
                                                                                            { required: true, message: '请输入菜单内容！',whiteSpace: true },
                                                                                        ]}
                                                                                    >
                                                                                        <Input
                                                                                            maxLength={300}
                                                                                            placeholder={"请输入回复文本"}
                                                                                        />
                                                                                    </Form.Item>
                                                                                )
                                                                            } else if (subMenu[field.name].type === 'dialerAction') {
                                                                                return (
                                                                                    <Form.Item
                                                                                        label="菜单内容"
                                                                                        name={[field.name, 'content']}
                                                                                        rules={[
                                                                                            { required: true, message: '请输入菜单内容！' },
                                                                                            {
                                                                                                pattern:phonePattern,
                                                                                                message:'请输入正确格式的菜单内容！',
                                                                                            }
                                                                                        ]}
                                                                                    >
                                                                                        <Input
                                                                                            maxLength={20}
                                                                                            placeholder={"请输入电话号码"}
                                                                                        />
                                                                                    </Form.Item>
                                                                                )
                                                                            }
                                                                        }
                                                                    }
                                                                </Form.Item>
                                                                {
                                                                    index === fields.length - 1 && index < 4 ? (
                                                                        <Row>
                                                                            <Col style={{textAlign:'right'}} span={7}>
                                                                                <PlusCircleTwoTone 
                                                                                    className={styles.addIcon}
                                                                                    onClick={() => {
                                                                                        add({
                                                                                            type: 'urlAction',
                                                                                            name: '',
                                                                                            content: '',
                                                                                        });
                                                                                    }} 
                                                                                />
                                                                            </Col>
                                                                        </Row> 
                                                                    ) : null
                                                                }    
                                                            </React.Fragment>
                                                        )
                                                    })}
                                                </>
                                            )
                                        }
                                    </Form.List>
                                )
                            } else if (isSubMenu === 0) {
                                return (
                                    <>
                                        <FormItem
                                            label="菜单类型"
                                            name="type"
                                            rules={[
                                                {
                                                    required: true,
                                                    message: '请选择菜单类型！',
                                                }
                                            ]}
                                        >
                                            <Select
                                                placeholder='请选择'
                                            >
                                                {
                                                    menuTypeList.map(item => (
                                                        <Option 
                                                            key={item.value}
                                                            value={item.value} 
                                                        >
                                                            {item.label}
                                                        </Option>
                                                    ))
                                                }
                                            </Select>
                                        </FormItem>
                                        <FormItem
                                            noStyle
                                            shouldUpdate={(prevValue,curValue) => prevValue.type !== curValue.type}
                                        >
                                            {
                                                ({ getFieldValue }) => {
                                                    const type = getFieldValue('type');
                                                    if (type === 'urlAction') {
                                                        return (
                                                            <FormItem
                                                                label="菜单内容"
                                                                name="content"
                                                                rules={[
                                                                    {
                                                                        required: true,
                                                                        message: '请输入菜单内容！',
                                                                    },
                                                                    {
                                                                        pattern: urlPattern,
                                                                        message:'请输入正确格式的菜单内容！',
                                                                    }
                                                                ]}
                                                            >
                                                                <Input 
                                                                    maxLength={1024}
                                                                    placeholder={"请输入以http或https开头的地址"}
                                                                />
                                                            </FormItem>
                                                        )
                                                    } else if (type === 'replyAction') {
                                                        return (
                                                            <FormItem
                                                                label="菜单内容"
                                                                name="content"
                                                                rules={[
                                                                    {
                                                                        required: true,
                                                                        message: '请输入菜单内容！',
                                                                        whiteSpace: true,
                                                                    },
                                                                ]}
                                                            >
                                                                <Input 
                                                                    maxLength={300}
                                                                    placeholder={"请输入回复文本"}
                                                                />
                                                            </FormItem>
                                                        )
                                                    } else if (type === 'dialerAction') {
                                                        return (
                                                            <FormItem
                                                                label="菜单内容"
                                                                name="content"
                                                                rules={[
                                                                    {
                                                                        required: true,
                                                                        message: '请输入菜单内容！',
                                                                    },
                                                                    {
                                                                        pattern: phonePattern,
                                                                        message:'请输入正确格式的菜单内容！',
                                                                    }
                                                                ]}
                                                            >
                                                                <Input 
                                                                    maxLength={20}
                                                                    placeholder={"请输入电话号码"}
                                                                />
                                                            </FormItem>
                                                        )
                                                    }   
                                                }
                                            }
                                        </FormItem>
                                    </>
                                )
                            }
                        }
                    }
                </FormItem>
            </Form>
        </Modal>
    );
}

export default PlainTextModal;
import React from 'react';
import { Form, Input, Modal, Select } from 'antd';
import { checkAppName } from '../service';
const FormItem = Form.Item;
const { TextArea } = Input;
const { Option } = Select;
const formLayout = {
  labelCol: {
    span: 7,
  },
  wrapperCol: {
    span: 13,
  },
};

const UpdateForm = (props) => {
  const {formVals} = props;
  const [form] = Form.useForm();
  const {
    chatbotTypeList,
    onSubmit: handleUpdate,
    onCancel: handleUpdateModalVisible,
    updateModalVisible,
    values,
  } = props;

  const handleNext = async () => {
    const fieldsValue = await form.validateFields();

    handleUpdate({...fieldsValue,id:values.id});
  };

  const fetchCheckName = async(appName)=>{
    const ret = await checkAppName({appName,id:values.id});
    if(ret && ret.success){
      return true;
    }else {
      return false;
    }
  }

  const renderContent = () => {
    return (
      <>
        <FormItem
          name="appName"
          label="应用名称"
          rules={[
            {
              required: true,
              message: '请输入应用名称',
            },
            ({ getFieldValue })  => ({
              async validator(rule, value) {
                if (!value || await fetchCheckName(value)) {
                  return Promise.resolve();
                }
                return Promise.reject('该应用名称已存在，请重新输入！');
              },
            }),
          ]}
        >
          <Input placeholder="请输入应用名称，30个字符数以内" maxLength={30}/>
        </FormItem>
        <FormItem
          label="所属业务"
          name="chatbotType"
          rules={[
            {
              required: true,
              message: '请选择应用所属业务',
            },
          ]}
        >
          <Select
            placeholder={'请选择'}
          >
            {
              chatbotTypeList.map(item => (
                <Option
                  key={item.value}
                  value={item.value}
                >
                  {item.label}
                </Option>
              ))
            }
          </Select>
        </FormItem>
        <FormItem
          name="description"
          label="应用描述"
          rules={[
            {
              required: true,
              message: '请输入应用描述',
              whitespace: true,
            },
          ]}
        >
          <TextArea placeholder="请输入应用描述，300个字符数以内" maxLength={300}/>
        </FormItem>
        <FormItem
          name="upCallbackUrl"
          label="上行消息回调URL"
          rules={[
            {
              required: true,
              message: '请输入上行消息回调URL',
            },
          ]}
        >
          <TextArea placeholder="请输入上行消息回调URL，300个字符数以内" maxLength={300}/>
        </FormItem>
      </>
    );
  };

  return (
    <Modal
      width={640}
      bodyStyle={{
        padding: '32px 40px 48px',
      }}
      destroyOnClose
      title="修改应用"
      visible={updateModalVisible}
      onOk={handleNext}
      onCancel={() => handleUpdateModalVisible(false, values)}
      afterClose={() => handleUpdateModalVisible()}
    >
      <Form
        {...formLayout}
        form={form}
        initialValues={values}
      >
        {renderContent()}
      </Form>
    </Modal>
  );
};

export default UpdateForm;

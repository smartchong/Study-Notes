import React from 'react';
import { Modal,Form,Input } from 'antd';
const FormItem = Form.Item;
const formLayout = {
    labelCol: {
        span: 7,
    },
    wrapperCol: {
        span: 13,
    },
};

const BottomTextModal = props => {
    const [form] = Form.useForm();
    const { bottomText,onSubmit,onCancel,modalVisible } = props;
    const validateBottomText = async (_, value) => {
        const promise = Promise;

        if (value) {
            if (/^[\s\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]{2,20}$/.test(value) && /^(?=.*\S).+$/.test(value)) {
                return promise.resolve();    
            }
            return promise.reject('请输入正确格式的底部文案！');
        }
    }

    return (
        <Modal
            destroyOnClose
            title="信息配置"
            visible={modalVisible}
            onOk={() => {
                form.validateFields().then(values => {
                    onSubmit(values.bottomText);
                });
            }}
            onCancel={() => {
                onCancel();
                form.resetFields();
            }}
        >
            <Form
                {...formLayout}
                form={form}
                initialValues={{
                    bottomText:bottomText,
                }}
            >
                <FormItem
                    label="底部文案"
                    name="bottomText"
                    rules={[
                        {
                            required: true,
                            message: '请输入底部文案！',
                        },
                        {
                            validator: validateBottomText,
                        }
                    ]}
                >
                    <Input 
                        placeholder="请输入2-20个字的底部文案" 
                        maxLength={20}
                    />
                </FormItem>
            </Form>
        </Modal>
    );
}
export default BottomTextModal;
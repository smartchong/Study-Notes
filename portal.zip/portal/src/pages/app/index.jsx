import { PlusOutlined, QuestionCircleOutlined } from '@ant-design/icons';
import { Button, Divider, message, Card, Modal, Select } from 'antd';
import React, { useRef, } from 'react';
import { connect, history } from 'umi';
import { queryRule, removeRule } from './service';
import { PageHeaderWrapper } from '@ant-design/pro-layout';
import ProTable from '@ant-design/pro-table';
import ControledInput from './components/Input';
import ControledRangePicker from './components/RangePicker';
import Image from './components/Image';
import defaultMenuData from './components/defaultMenuData';
const { Option } = Select;
const statusList = [
  {
    label: '全部',
    value: '',
  },
  {
    label: '待审核',
    value: 3,
  },
  {
    label: '审核通过',
    value: 1,
  },
  {
    label: '审核不通过',
    value: 2,
  },
];
const prepend = (arr, item) => {
  const temp = arr.slice(0);
  temp.unshift(item);
  return temp;
}
let defaultCurrent = 1;
let defaultPageSize = 20;

const Index = props => {
  const actionRef = useRef();
  const formRef = useRef(null);
  const { dispatch, appAndTableList, currentUser } = props;
  const { verifyStatus, chatbotType } = currentUser;
  const { searchParam } = appAndTableList;
  /**
   *  删除节点
   * @param selectedRows
   */
  const handleRemove = async (selectedRows) => {
    const hide = message.loading('正在删除');
    if (!selectedRows) return true;

    try {
      const ret = await removeRule({
        id: selectedRows.map((row) => row.id).join(','),
      });
      hide();
      if (ret && ret.success) {
        message.success('删除成功，即将刷新');
        if (actionRef.current) {
          actionRef.current.reload();
        }
        return true;
      } else {
        message.error(ret.message || '删除失败，请重试');
        return false;
      }
    } catch (error) {
      hide();
      message.error('删除失败，请重试');
      return false;
    }
  };
  const resetBottomMenu = () => {
    const temp = JSON.parse(JSON.stringify(defaultMenuData));
    dispatch({
      type: 'appAndTableList/setType',
      payload: { data: 1 }
    })
    dispatch({
      type: 'appAndTableList/setMenuData',
      payload: { data: temp }
    })
  }
  const columns = [
    {
      title: '应用LOGO',
      dataIndex: 'appPhotoUrl',
      hideInSearch: true,
      width: 100,
      render: (_, record) => (
        <Image
          src={_}
          title={"应用LOGO"}
        />
      )
    },
    {
      title: '应用名称',
      dataIndex: 'appName',
      width: 200,
      ellipsis: true,
      renderFormItem: (_, { onChange, type, defaultRender, ...rest }, form) => {
        return (
          <ControledInput
            maxLength={30}
            regex={/[^\w\u4e00-\u9fa5$#@^&_=+<>{}?~!()]/g}
            placeholder="请输入应用名称"
            onChange={(value) => {
              onChange(value)
            }}
            {...rest}
          />
        );
      },
    },
    {
      title: '所属业务',
      dataIndex: 'chatbotType',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              prepend(chatbotType, { label: '全部', value: '' }).map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{chatbotType.find(item => item.value === _) ? chatbotType.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '状态',
      dataIndex: 'status',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <Select
            placeholder={'全部'}
            {...rest}
          >
            {
              statusList.map(item => (
                <Option key={item.value} value={item.value}>{item.label}</Option>
              ))
            }
          </Select>
        );
      },
      render: (_, record) => (
        <span>{statusList.find(item => item.value === _) ? statusList.find(item => item.value === _).label : '-'}</span>
      )
    },
    {
      title: '创建时间',
      dataIndex: 'createTime',
      renderFormItem: (_, { type, defaultRender, ...rest }, form) => {
        return (
          <ControledRangePicker
            {...rest}
            range={89}
          />
        );
      },
    },
    {
      title: '操作',
      dataIndex: 'option',
      valueType: 'option',
      render: (_, record) => (
        record.status === 2 ? (
          <>
            <a
              onClick={() => {
                if (dispatch) {
                  dispatch({
                    type: 'appAndTableList/setParam',
                    payload: {
                      ...formRef.current.getFieldsValue(),
                      current: defaultCurrent,
                      pageSize: defaultPageSize,
                    },
                  })
                }
                history.push(`/layouts/app/list/details/${record.id}`)
              }}
            >
              查看
            </a>
            <Divider type="vertical" />
            <a
              onClick={() => {
                if (verifyStatus !== 1) {
                  Modal.warning({
                    title: '提示',
                    content: '您还未完成信息认证！',
                  });
                } else {
                  if (dispatch) {
                    resetBottomMenu();
                    dispatch({
                      type: 'appAndTableList/setParam',
                      payload: {
                        ...formRef.current.getFieldsValue(),
                        current: defaultCurrent,
                        pageSize: defaultPageSize,
                      },
                    })
                    dispatch({
                      type: 'appAndTableList/setDetailData',
                      payload: { data: null }
                    });
                  }
                  history.push(`/layouts/app/edit/${record.id}`);
                }
              }}
            >
              修改
            </a>
            <Divider type="vertical" />
            <a onClick={() => {
              Modal.confirm({
                title: '是否确定删除:',
                icon: <QuestionCircleOutlined />,
                content: '选定的应用？删除后该应用下的媒体文件、模板将同步删除，内容不可恢复。',
                onOk: () => handleRemove([record])
              })
            }}>删除</a>
          </>
        ) : (
            <>
              <a
                onClick={() => {
                  if (dispatch) {
                    dispatch({
                      type: 'appAndTableList/setParam',
                      payload: {
                        ...formRef.current.getFieldsValue(),
                        current: defaultCurrent,
                        pageSize: defaultPageSize,
                      },
                    })
                  }
                  history.push(`/layouts/app/list/details/${record.id}`)
                }}
              >
                查看
              </a>
              {/* <Divider type="vertical" />
              <a
                onClick={() => {
                  if (verifyStatus !== 1) {
                    Modal.warning({
                      title: '提示',
                      content: '您还未完成信息认证！',
                    });
                  } else {
                    if (dispatch) {
                      resetBottomMenu();
                      dispatch({
                        type: 'appAndTableList/setParam',
                        payload: {
                          ...formRef.current.getFieldsValue(),
                          current: defaultCurrent,
                          pageSize: defaultPageSize,
                        },
                      })
                      dispatch({
                        type: 'appAndTableList/setDetailData',
                        payload: { data: null }
                      });
                    }
                    history.push(`/layouts/app/edit/${record.id}`);
                  }
                }}
              >
                修改
            </a> */}
            </>
          )
      ),
    },
  ];

  return (
    <PageHeaderWrapper>
      <Card bordered={false}>
        <ProTable
          headerTitle=""
          actionRef={actionRef}
          formRef={formRef}
          rowKey="id"
          search={{
            searchText: '查询',
            resetText: '重置',
            collapsed: false,
            optionRender: ({ searchText, resetText }, { form }) => {
              if (searchParam) {
                form.setFieldsValue({
                  appName: searchParam.appName || undefined,
                  chatbotType: searchParam.chatbotType || undefined,
                  status: searchParam.status || undefined,
                  createTime: searchParam.createTime || undefined,
                });
              }
              return (
                <>
                  <Button
                    type={'primary'}
                    onClick={() => {
                      form.submit();
                    }}
                  >
                    {searchText}
                  </Button>
                  <Button
                    id={'resetBtn'}
                    type={'link'}
                    onClick={() => {
                      form.resetFields();
                      form.submit();
                    }}
                  >
                    {resetText}
                  </Button>
                </>
              );
            },
          }}
          rowSelection={false}
          options={false}
          pagination={{
            defaultCurrent: searchParam ? searchParam.current : defaultCurrent,
            defaultPageSize: searchParam ? searchParam.pageSize : defaultPageSize,
          }}
          tableAlertRender={false}
          toolBarRender={() => [
            <Button
              icon={<PlusOutlined />}
              type="primary"
              onClick={() => {
                if (verifyStatus !== 1) {
                  Modal.warning({
                    title: '提示',
                    content: '您还未完成信息认证！',
                  });
                } else {
                  if (dispatch) {
                    resetBottomMenu();
                    dispatch({
                      type: 'appAndTableList/setParam',
                      payload: {
                        ...formRef.current.getFieldsValue(),
                        current: defaultCurrent,
                        pageSize: defaultPageSize,
                      },
                    })
                  }
                  history.push('/layouts/app/create');
                }
              }}
            >
              创建应用
            </Button>
          ]}
          request={
            params => {
              if (searchParam) {
                Object.entries(searchParam).forEach(([key, value]) => {
                  params[key] = value;
                })
                if (dispatch) {
                  dispatch({
                    type: 'appAndTableList/setParam',
                    payload: null,
                  })
                }
              }
              params.startTime = params.createTime && params.createTime.length ? params.createTime[0] : null;
              params.endTime = params.createTime && params.createTime.length ? params.createTime[1] : null;
              params.pageNum = params.current;
              defaultCurrent = params.current;
              defaultPageSize = params.pageSize;
              delete params.current;
              delete params.createTime;
              return queryRule({ ...params });
            }
          }
          columns={columns}
        />
      </Card>
    </PageHeaderWrapper>
  );
};

export default connect(({ appAndTableList, user }) => ({
  appAndTableList,
  currentUser: user.currentUser,
}))(Index);

import request from '@/utils/request';
import API from '../../services/api';

export async function queryAppSelectList() {
  return request(API.APP.TABLE_SELECT_LIST);
}

export async function queryRule(params) {
  return request(API.APP.TABLE_LIST, {
    method: 'POST',
    data: { ...params },
  });
}

export async function queryAPPCount(){
  return request(API.APP.TABLE_COUNT,{
    method:'POST',
  })
}

export async function removeRule(params) {
  return request(API.APP.TABLE_DELETE, {
    method: 'POST',
    data: { ...params },
  });
}

export async function create(params) {
  return request(API.APP.CREATE, {
    method: 'POST',
    data: { ...params },
  });
}

export async function update(params) {
  return request(API.APP.UPDATE, {
    method: 'POST',
    data: { ...params },
  });
}

export async function queryDetails(params) {
  return request(API.APP.DETAIL, {
    params
  });
}

export async function checkAppName(params) {
  return request(API.APP.CHECK_NAME, {
    params
  });
}

export function getUploadAction() {
  return API.APP.UPLOAD_LOGO;
}
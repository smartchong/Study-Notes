import { history } from 'umi';
import { message,notification } from 'antd';
import { fakeAccountLogin, getFakeCaptcha, getSecretKey,getFakeImgCaptcha } from './service';
import { setAuthority } from './utils/utils';

const Model = {
  namespace: 'userAndLogin',
  state: {
    status: undefined,
    userInfo:undefined,
    secretKey:{},
    success: undefined,
  },
  effects: {
    *login({ payload }, { call, put }) {
      const response = yield call(fakeAccountLogin, payload);
      yield put({
        type: 'changeLoginStatus',
        payload: response,
      });
      if (response.success) {
        message.success('登录成功！');
        yield put({
          type:'user/fetchCurrent',
          callBack:(res) => {
            if (res && res.success && res.data.verifyStatus !== 1) {
              history.replace('/layouts/userCenter/authInfo');
            } else {
              if (typeof payload.to !== 'undefined') {
                history.replace('/cloudCard/vCard/my');
              } else {
                history.replace('/layouts/app/list');
              }
            }
          },
        });
      } else {
        document.getElementById('img_c').src = getFakeImgCaptcha();
        if (typeof response.sourceCode !== 'undefined') {
          if (response.sourceCode !== 'SIM998872') {
            notification.error({
              message: response.message || '登录失败！',
            });
            yield put({
              type: 'changeLoginTab',
              payload: response,
            });
          } else {
            notification.error({
              message: response.message || '登录失败！',
            });
          }
        } else {
          notification.error({
            message: response.message || '登录失败！',
          });
        }
      }
    },

    *getSecretKey({},{call,put}){
      const response = yield call(getSecretKey);
      if (!response) {
        notification.error({
          message: '获取失败！',
        });
      }
      return response;
    },

    *getCaptcha({ payload }, { call }) {
      yield call(getFakeCaptcha, payload);
    },
  },
  reducers: {
    changeLoginStatus(state, { payload }) {
      setAuthority(payload.currentAuthority);
      return { ...state, status: payload.status, type: payload.type,userInfo:payload };
    },
    changeLoginTab(state, { payload }) {
      return { ...state, success: payload.success };
    },
  },
};
export default Model;

import request from '@/utils/request';
import API from '../../../services/api';

export async function fakeAccountLogin(params) {
  return request(API.LOGIN.ACCOUNT, {
    method: 'POST',
    data: params,
    requestType:'form'
  });
}
export async function getSecretKey(){
  return request(API.LOGIN.SECRETKEY);
}
export async function getFakeCaptcha(mobile) {
  return request(`${API.LOGIN.CAPTCHA_SMS}?mobile=${mobile}`);
}
export async function getCaptcha(params) {
  return request(API.LOGIN.CAPTCHA, {
    method: 'POST',
    data: params,
  });
}
export function getFakeImgCaptcha() {
  return `${API.LOGIN.CAPTCHA_IMG}?_=${new Date().getTime()}`
}
export async function simAuth(params) {
  return request(API.LOGIN.SIMAUTH, {
    method: 'POST',
    data: params,
  });
}

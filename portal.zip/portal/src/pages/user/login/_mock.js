import API from '../../../services/api';

function getFakeCaptcha(req, res) {
  return res.json('captcha-xxx');
}

export default {
  [`POST  ${API.LOGIN.ACCOUNT}`]: (req, res) => {
    const { password, username, type } = req.body;

    if (username === 'admin') {
      res.send({
        success: 'ok',
        type,
        currentAuthority: 'admin',
      });
      return;
    }

    if (password === 'ant.design' && username === 'user') {
      res.send({
        success: 'ok',
        type,
        currentAuthority: 'user',
      });
      return;
    }

    if (type === 'mobile') {
      res.send({
        success: 'ok',
        type,
        currentAuthority: 'admin',
      });
      return;
    }

    res.send({
      success: 'error',
      type,
      currentAuthority: 'guest',
    });
  },
  [`GET  ${API.LOGIN.CAPTCHA_SMS}`]: getFakeCaptcha,
  [`GET  ${API.LOGIN.CAPTCHA_IMG}`]: {},
};

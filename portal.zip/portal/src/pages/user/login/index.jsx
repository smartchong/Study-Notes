import { Alert, message, notification } from 'antd';
import React, { useState, useEffect } from 'react';
import { Link, connect } from 'umi';
import styles from './style.less';
import JSEncrypt from 'jsencrypt';
import LoginFrom from './components/Login';
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
import { simAuth } from './service';
const { Tab, UserName, Password, ImgCaptcha, Mobile, Captcha, Submit } = LoginFrom;
const LoginMessage = ({ content }) => (
  <Alert
    style={{
      marginBottom: 24,
    }}
    message={content}
    type="error"
    showIcon
  />
);

const Login = props => {

  const [count, setCount] = useState(60);
  const [timing, setTiming] = useState(false);
  const { dispatch, userAndLogin = {}, submitting, location } = props;
  const { status, type: loginType } = userAndLogin;
  const [ type, setType ] = useState('account');
  useEffect(() => {
    if (!userAndLogin) {
      return;
    }
    if (userAndLogin.success === false) {
      dispatch({
        type: 'userAndLogin/changeLoginTab',
        payload: {
          success: undefined
        },
      });
      setTimeout(() => {
        setType("account");
      },500);
    }
  }, [userAndLogin]);
  useEffect(() => {
    let interval = 0;
    if (timing) {
      interval = window.setInterval(() => {
        setCount(preSecond => {
          if (preSecond <= 1) {
            setTiming(false);
            clearInterval(interval); // 重置秒数
            return 60;
          }
          return preSecond - 1;
        });
      }, 1000);
    }
    return () => clearInterval(interval);
  }, [timing]);
  let encrypt = new JSEncrypt();
  const handleSubmit = values => {
    if (typeof location.state?.to !== 'undefined') {
      values.to = location.state?.to;
    }
    if (type === 'account') {
      dispatch({
        type: 'userAndLogin/getSecretKey',
      }).then((result)=>{
        if(result){
          encrypt.setPublicKey(result);
          values.password = encrypt.encrypt(values.password);
          values.loginType = 1;
          dispatch({
            type: 'userAndLogin/login',
            payload: { ...values, type },
          });
        }
      })
    } else if (type === 'verifyCode') {
      values.username = values.mobile;
      values.password = '';
      values.loginType = 2;
      dispatch({
        type: 'userAndLogin/login',
        payload: { ...values, type },
      });
    } else if (type === 'mobile') {
      values.username = values.mobile;
      values.password = '';
      values.loginType = 3;
      simAuth({
        mobile:values.mobile,
        imageCode:values.code,
        operation:6
      }).then(res => {
        if (res.success) {
          setTiming(true);
          message.success('登录请求已发送到您的手机上，请在手机确认！');
          dispatch({
            type: 'userAndLogin/login',
            payload: { ...values, type },
          });
        } else {
          notification.error({
            message: res.message,
          });
          if (typeof res.sourceCode !== 'undefined') {
            if (res.sourceCode !== 'SIM998872') {
              setTimeout(() => {
                setType("account");
              },500);
            }
          }
        }
      })

    }
  };

  return (
    <div className={styles.main}>
      <BasicHeader />
      <div className={styles.loginWrap}>
        <div className={styles.loginBox}>
          <div className={styles.loginBg}></div>
          <div className={styles.loginForm}>
            <LoginFrom
              activeKey={type}
              onTabChange={(activeKey) => {
                setType(activeKey)
              }}
              onSubmit={handleSubmit}
            >
              <Tab key="account" tab="账号登录">
                {
                  status === 'error' && loginType === 'account' && !submitting && (
                    <LoginMessage content="账户或密码错误" />
                  )
                }
                <UserName
                  name="username"
                  placeholder="用户名/邮箱/手机号码"
                  maxLength={50}
                  rules={[
                    {
                      required: true,
                      message: '输入项不能为空！',
                    },
                  ]}
                />
                <Password
                  name="password"
                  placeholder="密码"
                  maxLength={20}
                  rules={[
                    {
                      required: true,
                      message: '请输入密码！',
                    },
                  ]}
                />
                <ImgCaptcha
                  name="code"
                  placeholder="图形验证码"
                  maxLength={4}
                  rules={[
                    {
                      required: true,
                      message: '请输入图形验证码！',
                    },
                    {
                      pattern: /^\d{4}$/,
                      message: '图形验证码错误！',
                    },
                  ]}
                />
              </Tab>
              <Tab key="verifyCode" tab="验证码登录">
                {
                  status === 'error' && loginType === 'verifyCode' && !submitting && (
                    <LoginMessage content="短信验证码错误" />
                  )
                }
                <Mobile
                  name="mobile"
                  placeholder="手机号码"
                  maxLength={11}
                  rules={[
                    {
                      required: true,
                      message: '请输入手机号码！',
                    },
                    {
                      pattern: /^1(3[0-9]|5[0-9]|8[0-9]|4[0-9]|7[0-9]|9[0-9]|66)\d{8}$/,
                      message: '手机号码错误！',
                    },
                  ]}
                />
                <ImgCaptcha
                  name="code"
                  placeholder="图形验证码"
                  maxLength={4}
                  rules={[
                    {
                      required: true,
                      message: '请输入图形验证码！',
                    },
                    {
                      pattern: /^\d{4}$/,
                      message: '图形验证码错误！',
                    },
                  ]}
                />
                <Captcha
                  name="smsCode"
                  placeholder="短信验证码"
                  maxLength={6}
                  countDown={60}
                  getCaptchaButtonText=""
                  getCaptchaSecondText="秒"
                  rules={[
                    {
                      required: true,
                      message: '请输入短信验证码！',
                    },
                    {
                      pattern: /^\d{6}$/,
                      message: '短信验证码错误！',
                    },
                  ]}
                />
              </Tab>
              <Tab key="mobile" tab="手机快捷登录">
                {
                  status === 'error' && loginType === 'mobile' && !submitting && (
                    <LoginMessage content="账户或密码错误" />
                  )
                }
                <Mobile
                  name="mobile"
                  placeholder="手机号码"
                  maxLength={11}
                  rules={[
                    {
                      required: true,
                      message: '请输入手机号码！',
                    },
                    {
                      pattern: /^1(3[0-9]|5[0-9]|8[0-9]|4[0-9]|7[0-9]|9[0-9]|66)\d{8}$/,
                      message: '手机号码错误！',
                    },
                  ]}
                />
                <ImgCaptcha
                  name="code"
                  placeholder="图形验证码"
                  maxLength={4}
                  rules={[
                    {
                      required: true,
                      message: '请输入图形验证码！',
                    },
                    {
                      pattern: /^\d{4}$/,
                      message: '图形验证码错误！',
                    },
                  ]}
                />
                <div>温馨提示：手机快捷登录暂时只支持移动号码。该服务是由中国移动提供的PC端安全登录服务。输入手机号点击登录按钮，即可在手机查看登录请求，并使用手机进行登录授权。</div>
              </Tab>
              <Submit loading={submitting}>{timing && submitting ? `登录请求已发送，请您${count}秒后重试` : '登录' }</Submit>
              <div className={styles.other}>
                <Link className={styles.register} to="/user/register">
                  免费注册
                </Link>
                {
                  type === 'account' ? (
                    <Link className={styles.forget} to="/user/retrieve-validate">
                      忘记密码
                    </Link>
                  ) : null
                }
              </div>
            </LoginFrom>
          </div>
        </div>
      </div>
    </div>
  );
};

export default connect(({ userAndLogin, loading }) => ({
  userAndLogin,
  submitting: loading.effects['userAndLogin/login'],
}))(Login);

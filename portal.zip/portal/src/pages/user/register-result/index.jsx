import React from 'react';
import { Button, Result } from 'antd';
import { FormattedMessage, formatMessage, Link } from 'umi';
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
import RegisterBox from "./components/RegisterBox";
import styles from './style.less';

const actions = (
  <div className={styles.actions}>
    <Link to="/user/login">
      <Button className={styles.loginBtn}>
        <FormattedMessage id="userandregister-result.register-result.view-mailbox" />
      </Button>
    </Link>
  </div>
);

const RegisterResult = ({ location }) => (
  <div className={styles.main}>
    <BasicHeader />
    <RegisterBox
      tabIndex={1}
    >
      <Result
        className={styles.registerResult}
        status="success"
        title={
          <div className={styles.title}>
            <FormattedMessage
              id="userandregister-result.register-result.msg"
              values={{
                userName: location.state ? location.state.account : '',
              }}
            />
          </div>
        }
        subTitle={formatMessage({
          id: 'userandregister-result.register-result.activation-welcome',
        })}
        extra={actions}
      />
    </RegisterBox>
  </div>
);

export default RegisterResult;

import { notification } from 'antd';
import { register,getSecretKey } from './service';

const Model = {
  namespace: 'userAndregister',
  state: {
    status: undefined,
  },
  effects: {
    *submit({ payload }, { call, put }) {
      const response = yield call(register, payload);
      yield put({
        type: 'registerHandle',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message,
        });
      }
    },
    *getSecretKey({},{call,put}){
      const response = yield call(getSecretKey);
      if (!response) {
        notification.error({
          message: response.message || '获取失败！',
        });
      }
      return response;
    },
  },
  reducers: {
    registerHandle(state, { payload }) {
      return { ...state, status: payload.success };
    },
  },
};
export default Model;

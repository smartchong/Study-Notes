import React, { useState, useEffect, useCallback } from 'react';
import { Link, connect, history, FormattedMessage, formatMessage } from 'umi';
import { AutoComplete, Form, Button, Checkbox, Col, Input, Popover, Progress, Row, message, notification } from 'antd';
import { getCaptcha, getImgCaptcha, repeatCheck } from "./service";
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
import RegisterBox from "./components/RegisterBox";
import AgreeBox from "./components/AgreeBox";
import styles from './style.less';
import JSEncrypt from 'jsencrypt';

const FormItem = Form.Item;
const { Option } = AutoComplete;
const passwordStatusMap = {
  ok: (
    <div className={styles.success}>
      <FormattedMessage id="userandregister.strength.strong" />
    </div>
  ),
  pass: (
    <div className={styles.warning}>
      <FormattedMessage id="userandregister.strength.medium" />
    </div>
  ),
  poor: (
    <div className={styles.error}>
      <FormattedMessage id="userandregister.strength.short" />
    </div>
  ),
};
const passwordProgressMap = {
  ok: 'success',
  pass: 'normal',
  poor: 'exception',
};
const encrypt = new JSEncrypt();
const PUBLICKEY = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCTUmOz914THaM/pFuuOvFu2Sm2Vxw35aiuZkwIezmAgJ0rAM1oAGrDKoLiBGjca7bZYHpX5u3yBnLTf6ypXLWfrETDDdCnVt7RKOyaeewu5aNLV6MYZMGos63ItvWra+B1qBM4eiSxJRQwZY5GbBGzOPQGZ2FcQa6EjMEwMRhwoQIDAQAB';

const Register = ({ submitting, dispatch, userAndregister }) => {
  const [isFirst, setIsFirst] = useState(true);
  const [count, setCount] = useState(60);
  const [timing, setTiming] = useState(false);
  const [visible, setvisible] = useState(false);
  const [imgCaptcha, setImgCaptcha] = useState(getImgCaptcha());
  const [emailList, setEmailList] = useState([]);
  const [popover, setpopover] = useState(false);
  const [agree, setAgree] = useState(false);
  const confirmDirty = false;
  const [form] = Form.useForm();
  useEffect(() => {
    if (!userAndregister) {
      return;
    }

    const account = form.getFieldValue('userName');

    if (userAndregister.status === true) {
      dispatch({
        type: 'userAndregister/registerHandle',
        payload: {
          success: undefined
        },
      });
      message.success('注册成功！');
      history.push({
        pathname: '/user/register-result',
        state: {
          account,
        },
      });
    }
  }, [userAndregister]);

  useEffect(() => {
    let interval = 0;

    if (timing) {
      interval = window.setInterval(() => {
        setCount(preSecond => {
          if (preSecond <= 1) {
            setTiming(false);
            clearInterval(interval); // 重置秒数

            return 60;
          }

          return preSecond - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [timing]);

  // 邮箱联想
  const handleEmailSearch = value => {
    let res = [];
    if (!value || value.indexOf('@') >= 0) {
      res = [];
    } else {
      res = [
        '126.com',
        '163.com',
        'yeah.net',
        'qq.com',
        'foxmail.com',
        'sina.com',
        'sina.cn',
        'aliyun.com',
        'hotmail.com',
        'outlook.com',
      ].map(domain => `${value}@${domain}`);
    }
    setEmailList(res);
  };
  // 校验信息重复
  const checkRepeat = async(type,value)=>{
    let param = {};
    param[type] = value;
    const ret = await repeatCheck(param);
    if(ret && ret.success) {
      return true;
    }else {
      return false;
    }
  }
  // 校验用户名
  const checkUserName = async (_, value) => {
    const promise = Promise;
    if (value) {
      if(!/^([0-9a-zA-Z_\u4e00-\u9fa5]){4,20}$/.test(value) || /^[0-9]*$/.test(value)) {
        return promise.reject('请输入正确格式的用户名！');
      } else {
        if (await checkRepeat('userName',value)) {
          return promise.resolve();
        }
        return promise.reject('该用户名已存在！');
      }
    }
  }
  // 校验手机号码
  const checkPhone = async (_, value) => {
    const promise = Promise;
    if (value) {
      if(!/^1(3[0-9]|5[0-9]|8[0-9]|4[0-9]|7[0-9]|9[0-9]|66)\d{8}$/.test(value)) {
        return promise.reject('手机号码错误！');
      } else {
        if (await checkRepeat('mobilePhone',value)) {
          return promise.resolve();
        }
        return promise.reject('该手机号码已注册！');
      }
    }
  }
  // 校验邮箱
  const checkEmail = async (_, value) => {
    const promise = Promise;
    if (value) {
      if(!/^([a-zA-Z0-9_\.])+@([a-zA-Z0-9_\.])+\.[a-zA-Z]{2,3}$/.test(value) || value.length > 50 || value.indexOf('._') > -1 || value.indexOf('_.') > -1 || value.indexOf('..') > -1 || value.indexOf('__') > -1 || value.slice(0,1) === '.' || value.slice(0,1) === '_') {
        return promise.reject('请输入正确格式的邮箱！');
      } else {
        if (await checkRepeat('email',value)) {
          return promise.resolve();
        }
        return promise.reject('该邮箱已注册！');
      }
    }
  }
  // 获取短信验证码
  const onGetCaptcha = useCallback(async params => {
    const result = await getCaptcha(params);
    if (result.success === false) {
      notification.error({
        message: result.message,
      });
      return;
    }
    message.success('获取验证码成功！');
    if (isFirst) {
      setIsFirst(false);
    }
    setTiming(true);
  }, []);
  // 校验两次密码是否一致
  const checkConfirm = (_, value) => {
    const promise = Promise;
    if (value && value !== form.getFieldValue('passWord')) {
      return promise.reject('密码不一致！');
    }
    return promise.resolve();
  };

  const getPasswordStatus = () => {
    const value = form.getFieldValue('password');

    if (value && value.length > 9) {
      return 'ok';
    }

    if (value && value.length > 5) {
      return 'pass';
    }

    return 'poor';
  };

  const onFinish = values => {
    encrypt.setPublicKey(PUBLICKEY);
    values.passWord = encrypt.encrypt(values.passWord);
    values.rePassWord = values.passWord;
    dispatch({
      type: 'userAndregister/submit',
      payload: { ...values },
    });
  };

  const checkPassword = (_, value) => {
    const promise = Promise; // 没有值的情况

    if (!value) {
      setvisible(!!value);
      return promise.reject(
        formatMessage({
          id: 'userandregister.password.required',
        }),
      );
    } // 有值的情况

    if (!visible) {
      setvisible(!!value);
    }

    setpopover(!popover);

    if (value.length < 6) {
      return promise.reject('');
    }

    if (value && confirmDirty) {
      form.validateFields(['confirm']);
    }

    return promise.resolve();
  };

  const renderPasswordProgress = () => {
    const value = form.getFieldValue('password');
    const passwordStatus = getPasswordStatus();
    return value && value.length ? (
      <div className={styles[`progress-${passwordStatus}`]}>
        <Progress
          status={passwordProgressMap[passwordStatus]}
          className={styles.progress}
          strokeWidth={6}
          percent={value.length * 10 > 100 ? 100 : value.length * 10}
          showInfo={false}
        />
      </div>
    ) : null;
  };

  return (
    <div className={styles.main}>
      <BasicHeader />
      <RegisterBox
        show={!agree}
        tabIndex={0}
      >
        <>
          <div className={styles.leftContent}>
            <Form
              form={form}
              name="UserRegister"
              onFinish={onFinish}
              hideRequiredMark={true}
            >
              {/* 用户名 */}
              <Form.Item
                name={"userName"}
                label={"用户名"}
                extra={"4-20个字符，允许输入纯汉字或字母和数字及下划线组合，不支持纯数字，避免设置与其他业务相同的用户名"}
                labelCol={{ span: 4 }}
                wrapperCol={{ span: 12 }}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入用户名！',
                    whitespace: true,
                  },
                  {
                    validator: checkUserName,
                  },
                ]}
              >
                <Input
                  maxLength={20}
                />
              </Form.Item>
              {/* 手机号码 */}
              <Form.Item
                name="mobilePhone"
                label={'手机号码'}
                extra={"用于动态登录，以及接收平台的相关通知"}
                labelCol={{ span: 4 }}
                wrapperCol={{ span: 12 }}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入手机号码！',
                    whitespace: true,
                  },
                  {
                    validator: checkPhone,
                  }
                ]}
              >
                <Input
                  maxLength={11}
                />
              </Form.Item>
              {/* 申请者姓名 */}
              <Form.Item
                name="realName"
                label={'申请者姓名'}
                extra={"2-5个汉字"}
                labelCol={{ span: 4 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  {
                    required: true,
                    message: '请输入申请者姓名！',
                    whitespace: true,
                  },
                  {
                    pattern: /^[\u4e00-\u9fa5]{2,5}$/,
                    message: '请输入正确格式的申请者姓名！',
                  }
                ]}
              >
                <Input
                  maxLength={5}
                />
              </Form.Item>
              {/* 图形验证码 */}
              <FormItem
                style={{marginBottom:0}}
                shouldUpdate
              >
                {({ getFieldValue }) => (
                  <FormItem
                    name="imageCode"
                    label={'图形验证码'}
                    labelCol={{ span: 4 }}
                    wrapperCol={{ span: 12 }}
                    rules={[
                      {
                        required: true,
                        message: '请输入图形验证码！',
                        whitespace: true,
                      },
                      {
                        pattern: /^\d{4}$/,
                        message: '图形验证码错误！',
                      }
                    ]}
                  >
                    <Input
                      maxLength={4}
                      suffix={<img className={styles.captchaImage} src={imgCaptcha} id='img_c'/>}
                      addonAfter={
                        <div
                          style={{ cursor: 'pointer'}}
                          onClick={()=>{
                            setImgCaptcha(getImgCaptcha())
                          }}
                        >
                          刷新
                        </div>
                      }
                    />
                  </FormItem>
                )}
              </FormItem>
              {/* 短信验证码 */}
              <FormItem
                style={{marginBottom:0}}
                shouldUpdate
              >
                {({ getFieldValue,validateFields }) => (
                  <Row gutter={8}>
                    <Col span={12}>
                      <FormItem
                        name={'smsCode'}
                        label={'短信验证码'}
                        extra={'请输入您获取到的验证码'}
                        labelCol={{ span: 8 }}
                        wrapperCol={{ span: 16 }}
                        rules={[
                          {
                            required: true,
                            message: '请输入短信验证码！',
                            whitespace: true,
                          },
                          {
                            pattern: /^\d{6}$/,
                            message: '短信验证码错误！',
                          }
                        ]}
                      >
                        <Input
                          maxLength={6}
                        />
                      </FormItem>
                    </Col>
                    <Col span={4}>
                      <Button
                        disabled={timing}
                        className={styles.getCaptcha}
                        size="large"
                        onClick={() => {
                          validateFields(['mobilePhone','imageCode']).then(() => {
                            const mobile = getFieldValue('mobilePhone');
                            const imageCode = getFieldValue('imageCode');
                            onGetCaptcha({
                              mobile,
                              imageCode,
                              operation: 1
                            });
                          });
                        }}
                      >
                        {timing ? `${count} 秒后重新获取` : isFirst ? '获取短信验证码' : '重新获取'}
                      </Button>
                    </Col>
                  </Row>
                )}
              </FormItem>
              {/* 邮箱 */}
              <FormItem
                name="email"
                label={'邮箱'}
                extra={'用于登录，接收到激活邮件才能够完成注册'}
                labelCol={{ span: 4 }}
                wrapperCol={{ span: 12 }}
                validateTrigger={"onBlur"}
                rules={[
                  {
                    required: true,
                    message: '请输入邮箱！',
                    whitespace: true,
                  },
                  {
                    validator: checkEmail,
                  },
                ]}
              >
                <AutoComplete
                  maxLength={50}
                  onSearch={handleEmailSearch}
                >
                  {emailList.map(email => (
                    <Option key={email} value={email}>
                      {email}
                    </Option>
                  ))}
                </AutoComplete>
              </FormItem>
              {/* 密码 */}
              <FormItem
                name="passWord"
                label={'密码'}
                extra={'字母、数字、特殊字符至少2种组合，8-20位，区分大小写'}
                labelCol={{ span: 4 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  {
                    required: true,
                    message: '请输入密码！',
                    whitespace: true,
                  },
                  {
                    pattern: /^((?=.*?\d)(?=.*?[A-Za-z])|(?=.*?\d)(?=.*?[$#@^&_=+%<>{}?~!])|(?=.*?[A-Za-z])(?=.*?[$#@^&_=+%<>{}?~!]))[\dA-Za-z$#@^&_=+%<>{}?~!]{8,20}$/,
                    message: '请输入正确格式的密码！',
                  },
                ]}
              >
                <Input.Password
                  maxLength={20}
                />
              </FormItem>
              {/* 确认密码 */}
              <FormItem
                name="rePassWord"
                label={'确认密码'}
                extra={'再次输入密码'}
                labelCol={{ span: 4 }}
                wrapperCol={{ span: 12 }}
                rules={[
                  {
                    required: true,
                    message: '请再次输入密码！',
                    whitespace: true,
                  },
                  {
                    validator: checkConfirm,
                  },
                ]}
              >
                <Input.Password
                  maxLength={20}
                />
              </FormItem>
              {/* 同意协议 */}
              <Form.Item
                wrapperCol={{ span: 12, offset: 4 }}
              >
                <Form.Item
                  noStyle
                  initialValue={true}
                  name="agreement"
                  valuePropName="checked"
                >
                  <Checkbox>
                    我同意并遵守
                  </Checkbox>
                </Form.Item>
                <a onClick={() => setAgree(true)}>《5G智慧家庭chatbot服务平台服务协议》</a>
              </Form.Item>
              <FormItem
                wrapperCol={{ span: 12, offset: 4 }}
                shouldUpdate
              >
                {() => {
                  return (
                    <Button
                      size="large"
                      disabled={form.getFieldValue('agreement') ? false : true}
                      loading={submitting}
                      className={styles.submit}
                      type="primary"
                      htmlType="submit"
                    >
                      <FormattedMessage id="userandregister.register.register" />
                    </Button>
                  )
                }}
              </FormItem>
            </Form>
          </div>
          <div className={styles.rightContent}>
            <div className={styles.alreadTxt}>已有账户？</div>
            <Button
              className={styles.loginBtn}
              onClick={() => history.replace('/user/login')}
            >登录</Button>
            <div className={styles.forgetTxt}>如<Link to="/user/retrieve-validate">忘记密码</Link>，可以通过手机号码找回密码</div>
          </div>
        </>
      </RegisterBox>
      {
        agree ? (
          <AgreeBox
            handleClick={() => setAgree(false)}
          />
        ) : null
      }
    </div>
  );
};

export default connect(({ userAndregister, loading }) => ({
  userAndregister,
  submitting: loading.effects['userAndregister/submit'],
}))(Register);

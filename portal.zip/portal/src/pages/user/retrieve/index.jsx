import React, { useState, useEffect, useCallback } from 'react';
import { connect, history } from 'umi';
import {  Form, Button, Col, Input, Row, message, notification } from 'antd';
import { getCaptcha, getImgCaptcha } from "./service";
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
import RetrieveBox from "./components/RetrieveBox";
import styles from './style.less';
const FormItem = Form.Item;

const Retrieve = ({ submitting, dispatch, userAndRetrieve }) => {
  const [form] = Form.useForm();
  const [count, setCount] = useState(60);
  const [timing, setTiming] = useState(false);
  const [isFirst, setIsFirst] = useState(true);
  const [imgCaptcha, setImgCaptcha] = useState(getImgCaptcha());
  const tabList = ["1 验证手机号码","2 重置密码","3 设置成功"];

  useEffect(() => {
    if (!userAndRetrieve) {
      return;
    }

    if (userAndRetrieve.status === true) {
      dispatch({
        type: 'userAndRetrieve/retrieveHandle',
        payload: {
          success: undefined
        },
      });
      history.push({
        pathname: '/user/retrieve-reset'
      });
    }
  }, [userAndRetrieve]);

  useEffect(() => {
    let interval = 0;

    if (timing) {
      interval = window.setInterval(() => {
        setCount(preSecond => {
          if (preSecond <= 1) {
            setTiming(false);
            clearInterval(interval); // 重置秒数

            return 60;
          }

          return preSecond - 1;
        });
      }, 1000);
    }

    return () => clearInterval(interval);
  }, [timing]);

  const onFinish = values => {
    dispatch({
      type: 'userAndRetrieve/submit',
      payload: { ...values },
    });
  };

  // 获取短信验证码
  const onGetCaptcha = useCallback(async params => {
    const result = await getCaptcha(params);
    if (result.success === false) {
      notification.error({
        message: result.message,
      });
      return;
    }
    message.success('获取验证码成功！');
    if (isFirst) {
      setIsFirst(false);
    }
    setTiming(true);
  }, []);

  return (
    <div className={styles.main}>
      <BasicHeader />
      <RetrieveBox
        tabList={tabList}
        selected={0}
      >
        <Form
          size={'large'}
          style={{width:'100%'}}
          form={form}
          name="UserRetrieve"
          onFinish={onFinish}
          hideRequiredMark={true}
        >
          {/* 手机号码 */}
          <Form.Item
            name="mobile"
            label={'手机号码'}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 8 }}
            validateTrigger={"onBlur"}
            rules={[
              {
                required: true,
                message: '请输入手机号码！',
                whitespace: true,
              },
              {
                pattern: /^1(3[0-9]|5[0-9]|8[0-9]|4[0-9]|7[0-9]|9[0-9]|66)\d{8}$/,
                message: '手机号码错误！',
              }
            ]}
          >
            <Input
              size={'large'}
              placeholder={'请输入注册时填写的手机号码'}
              maxLength={11}
            />
          </Form.Item>
          {/* 图形验证码 */}
          <FormItem
            style={{marginBottom:0}}
            shouldUpdate
          >
            {({ getFieldValue }) => (
              <FormItem
                name="imageCode"
                label={'图形验证码'}
                labelCol={{ span: 8 }}
                wrapperCol={{ span: 8 }}
                rules={[
                  {
                    required: true,
                    message: '请输入图形验证码！',
                    whitespace: true,
                  },
                  {
                    pattern: /^\d{4}$/,
                    message: '图形验证码错误！',
                  }
                ]}
              >
                <Input
                  size={'large'}
                  placeholder={'请输入图形验证码'}
                  maxLength={4}
                  suffix={<img className={styles.captchaImage} src={imgCaptcha} id='img_c'/>}
                  addonAfter={
                    <div
                      style={{ cursor: 'pointer'}}
                      onClick={()=>{
                        setImgCaptcha(getImgCaptcha())
                      }}
                    >
                      刷新
                    </div>
                  }
                />
              </FormItem>
            )}
          </FormItem>
          {/* 短信验证码 */}
          <FormItem
            style={{marginBottom:0}}
            shouldUpdate
          >
            {({ getFieldValue,validateFields }) => (
              <Row gutter={8}>
                <Col span={12}>
                  <FormItem
                    name={'smsCode'}
                    label={'短信验证码'}
                    labelCol={{ span: 16 }}
                    wrapperCol={{ span: 8 }}
                    rules={[
                      {
                        required: true,
                        message: '请输入短信验证码！',
                        whitespace: true,
                      },
                      {
                        pattern: /^\d{6}$/,
                        message: '短信验证码错误！',
                      }
                    ]}
                  >
                    <Input
                      size={'large'}
                      placeholder={'请输入收到的验证码'}
                      maxLength={6}
                    />
                  </FormItem>
                </Col>
                <Col span={4}>
                  <Button
                    disabled={timing}
                    className={styles.getCaptcha}
                    onClick={() => {
                      validateFields(['mobile','imageCode']).then(() => {
                        const mobile = getFieldValue('mobile');
                        const imageCode = getFieldValue('imageCode');
                        onGetCaptcha({
                          mobile,
                          imageCode,
                          operation: 3
                        });
                      });
                    }}
                  >
                    {timing ? `${count} 秒后重新获取` : isFirst ? '获取短信验证码' : '重新获取'}
                  </Button>
                </Col>
              </Row>
            )}
          </FormItem>
          <FormItem
            wrapperCol={{ span: 8, offset: 8 }}
            shouldUpdate
          >
            {() => {
              return (
                <Button
                  size="large"
                  loading={submitting}
                  className={styles.submit}
                  type="primary"
                  htmlType="submit"
                >
                  下一步
                </Button>
              )
            }}
          </FormItem>
        </Form>
      </RetrieveBox>
    </div>
  );
};

export default connect(({ userAndRetrieve, loading }) => ({
  userAndRetrieve,
  submitting: loading.effects['userAndRetrieve/submit'],
}))(Retrieve);







import request from '@/utils/request';
import API from '../../../services/api';

export async function validatePhone(params) {
  return request(API.RETRIEVE.VALIDATE, {
    method: 'POST',
    data: params,
  });
}

export async function resetPassword(params) {
  return request(API.RETRIEVE.RESET, {
    method: 'POST',
    data: params,
  });
}

export function getImgCaptcha() {
  return `${API.LOGIN.CAPTCHA_IMG}?_=${new Date().getTime()}`
}

export async function getCaptcha(params) {
  return request(API.LOGIN.CAPTCHA, {
    method: 'POST',
    data: params,
  });
}


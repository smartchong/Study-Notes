import { notification } from 'antd';
import { validatePhone,resetPassword } from './service';

const Model = {
  namespace: 'userAndRetrieve',
  state: {
    status: undefined,
    success: undefined,
  },
  effects: {
    *submit({ payload }, { call, put }) {
      const response = yield call(validatePhone, payload);
      yield put({
        type: 'retrieveHandle',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message,
        });
      }
    },
    *reset({ payload }, { call, put }) {
      const response = yield call(resetPassword, payload);
      yield put({
        type: 'resetHandle',
        payload: response,
      });
      if (!response.success) {
        notification.error({
          message: response.message,
        });
      }
    },
  },
  reducers: {
    retrieveHandle(state, { payload }) {
      return { ...state, status: payload.success };
    },
    resetHandle(state, { payload }) {
      return { ...state, success: payload.success };
    },
  },
};
export default Model;

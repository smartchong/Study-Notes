import React from 'react';
import { connect, Link } from 'umi';
import {  Button, Result } from 'antd';
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
import RetrieveBox from "./components/RetrieveBox";
import styles from './style.less';

const actions = (
  <div className={styles.actions}>
    <Link to="/user/login">
      <Button className={styles.loginBtn}>
        返回登录
      </Button>
    </Link>
  </div>
);

const RetrieveResult = (props) => {
  const tabList = ["1 验证手机号码","2 重置密码","3 设置成功"];

  return (
    <div className={styles.main}>
      <BasicHeader />
      <RetrieveBox
        tabList={tabList}
        selected={2}
      >
        <Result
          className={styles.result}
          status="success"
          title={
            <div className={styles.title}>
              密码重置成功！
            </div>
          }
          extra={actions}
        />
      </RetrieveBox>
    </div>
  )
}

export default RetrieveResult;

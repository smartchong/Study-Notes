import React, { useEffect } from 'react';
import { connect, history } from 'umi';
import {  Form, Button, Input, message } from 'antd';
import BasicHeader from '@/components/GlobalHeader/BasicHeader';
import RetrieveBox from "./components/RetrieveBox";
import JSEncrypt from 'jsencrypt';
import styles from './style.less';
const FormItem = Form.Item;
const encrypt = new JSEncrypt();
const PUBLICKEY = 'MIGfMA0GCSqGSIb3DQEBAQUAA4GNADCBiQKBgQCTUmOz914THaM/pFuuOvFu2Sm2Vxw35aiuZkwIezmAgJ0rAM1oAGrDKoLiBGjca7bZYHpX5u3yBnLTf6ypXLWfrETDDdCnVt7RKOyaeewu5aNLV6MYZMGos63ItvWra+B1qBM4eiSxJRQwZY5GbBGzOPQGZ2FcQa6EjMEwMRhwoQIDAQAB';

const Reset = ({ submitting, dispatch, userAndRetrieve }) => {
  const [form] = Form.useForm();
  const tabList = ["1 验证手机号码","2 重置密码","3 设置成功"];
  const onFinish = values => {
     encrypt.setPublicKey(PUBLICKEY);
     values.newPassword = encrypt.encrypt(values.newPassword);
     values.rePassword = values.newPassword;
     dispatch({
       type: 'userAndRetrieve/reset',
       payload: { ...values },
     });
  };
  useEffect(() => {
    if (!userAndRetrieve) {
      return;
    }

    if (userAndRetrieve.success === true) {
      dispatch({
        type: 'userAndRetrieve/resetHandle',
        payload: {
          success: undefined
        },
      });
      message.success('重置成功！');
      history.push({
        pathname: '/user/retrieve-result'
      });
    }
  }, [userAndRetrieve]);
  // 校验密码
  const checkPassword = (_, value) => {
    const promise = Promise;
    if (value) {
      if (!/^((?=.*?\d)(?=.*?[A-Za-z])|(?=.*?\d)(?=.*?[$#@^&_=+%<>{}?~!])|(?=.*?[A-Za-z])(?=.*?[$#@^&_=+%<>{}?~!]))[\dA-Za-z$#@^&_=+%<>{}?~!]{8,20}$/.test(value)) {
        return promise.reject('请输入正确格式的密码！');
      }
    }
    if (form.getFieldValue('rePassword')) {
      form.validateFields(["rePassword"]);
    }
    return promise.resolve();
  }
  // 校验两次密码是否一致
  const checkConfirm = (_, value) => {
    const promise = Promise;
    if (value && value !== form.getFieldValue('newPassword')) {
      return promise.reject('密码不一致！');
    }
    return promise.resolve();
  };
  return (
    <div className={styles.main}>
      <BasicHeader />
      <RetrieveBox
        tabList={tabList}
        selected={1}
      >
        <Form
          size={'large'}
          style={{width:'100%'}}
          form={form}
          name="UserReset"
          onFinish={onFinish}
          hideRequiredMark={true}
        >
          {/* 新密码 */}
          <FormItem
            name="newPassword"
            label={'新密码'}
            extra={'字母、数字、特殊字符至少2种组合，8-20位，区分大小写'}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 8 }}
            rules={[
              {
                required: true,
                message: '请输入密码！',
              },
              {
                validator: checkPassword,
              },
            ]}
          >
            <Input.Password
              size={'large'}
              maxLength={20}
            />
          </FormItem>
          {/* 确认密码 */}
          <FormItem
            name="rePassword"
            label={'确认密码'}
            extra={'再次输入密码'}
            labelCol={{ span: 8 }}
            wrapperCol={{ span: 8 }}
            rules={[
              {
                required: true,
                message: '请再次输入密码！',
                whitespace: true,
              },
              {
                validator: checkConfirm,
              },
            ]}
          >
            <Input.Password
              size={'large'}
              maxLength={20}
            />
          </FormItem>
          <FormItem
            wrapperCol={{ span: 8, offset: 8 }}
            shouldUpdate
          >
            {() => {
              return (
                <Button
                  size="large"
                  loading={submitting}
                  className={styles.submit}
                  type="primary"
                  htmlType="submit"
                >
                  确定
                </Button>
              )
            }}
          </FormItem>
        </Form>
      </RetrieveBox>
    </div>
  );
}


export default connect(({ userAndRetrieve, loading }) => ({
  userAndRetrieve,
  submitting: loading.effects['userAndRetrieve/reset'],
}))(Reset);

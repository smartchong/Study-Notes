import React, { memo, useContext, useMemo, ReactNode, CSSProperties } from 'react';
import { context } from '@/layouts/H5Layout';
import { useDrag } from 'react-dnd';
import schemaH5 from '@/components/BasicShop/schema';
import schemaPC from '@/components/BasicPCShop/schema';
const styles = require('./index.less');

interface IDragBoxProps {
    item: any;
    children: ReactNode;
    canvasId: string;
}

const DragBox = (props: IDragBoxProps) => {
    const { item, children } = props;
    const ctx = useContext(context);
    const schema = useMemo(() => {
        /* 
           if (ctx.theme === 'h5') {
             return schemaH5;
           } else {
             return schemaPC;
           } 
        */
        return schemaH5;
    }, [ctx.theme]);
    const [{ isDragging }, drag] = useDrag({
        item: {
            h: item.h,
            x: item.x || 0,
            type: item.type,
            category: item.category,
            config: schema[item.type as keyof typeof schema].config,
            editableEl: schema[item.type as keyof typeof schema].editData,
        },
        collect: monitor => ({
            isDragging: monitor.isDragging(),
        })
    });
    const containerStyle: CSSProperties = useMemo(
        () => ({
            opacity: isDragging ? 0.4 : 1,
            cursor: 'move',
            width: '100px',
            height: '100px',
        }),
        [isDragging]
    );

    return (
        <div className={styles.listWrap}>
            <div
                ref={drag}
                className={styles.module}
                style={{ ...containerStyle }}
            >
                <div
                    style={{
                        display: 'flex',
                        alignItems: 'center',
                        justifyContent: 'center',
                        flexDirection: 'column',
                        overflow: 'hidden',
                        height: '70px'
                    }}
                >
                    {children}
                </div>

                <div
                    style={{
                        height: '30px',
                        lineHeight: '30px',
                        textAlign: 'center',
                        backgroundColor: 'rgba(245, 245, 245, 1)',
                        color: 'rgba(118, 118, 118, 1)',
                    }}
                >
                    {item.displayName}
                </div>
            </div>
        </div>
    );
}

export default memo(DragBox);
import React, { useState, useEffect } from 'react';
import { notification } from 'antd';
import ViewRender from '@/core/ViewRender';
import { useParams } from "umi";
import { fetchDetailByShortStr, IShortStrParams } from './service';

function useWindowWidth(): number {
    const [width, setWidth] = useState(window.innerWidth);
    useEffect(() => {
        const handleResize = () => {
            setWidth(window.innerWidth);
        }
        window.addEventListener('resize', handleResize);
        return () => {
            window.removeEventListener('resize', handleResize);
        }
    }, [width]);

    return width;
}

const H5Page = () => {
    const params = useParams();
    const [data, setData] = useState([]);
    const vw = useWindowWidth();

    useEffect(() => {
        fetchDetailByShortStr({
            shortStr: (params as IShortStrParams).shortStr,
        }).then(ret => {
            if (ret && ret.success) {
                if (ret?.data?.content) setData(JSON.parse(ret?.data?.content))
            } else {
                notification.error({
                    message: ret.message
                });
            }
        });
    }, []);

    return (
        <ViewRender pointData={data} width={vw} />
    )
}

export default H5Page;
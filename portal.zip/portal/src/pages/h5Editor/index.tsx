import React, { FC } from 'react';
import { DndProvider } from 'react-dnd';
import { HTML5Backend } from 'react-dnd-html5-backend';
import Container from './Container';
import styles from './index.less';

const Index: FC = (props) => {
    return (
        <div className={styles.layout}>
            <DndProvider backend={HTML5Backend}>
                <Container {...props} />
            </DndProvider>
        </div>
    );
}

export default Index;
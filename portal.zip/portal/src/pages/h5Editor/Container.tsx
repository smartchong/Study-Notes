import React, { useState, useMemo, useRef, useEffect, MouseEvent, WheelEvent } from 'react';
import { Result, Tabs, Form, Input, Row, Col, Modal, notification } from 'antd';
import {
    AppstoreOutlined,
    CopyOutlined,
    DoubleRightOutlined,
    DoubleLeftOutlined,
    ExclamationCircleOutlined,
    FileTextOutlined,
} from '@ant-design/icons';
import DynamicEngine, { componentsType } from '@/core/DynamicEngine';
import FormRender from '@/core/FormRender';
import { connect } from 'dva';
import { history, useParams } from 'umi';
import { ActionCreators, StateWithHistory } from 'redux-undo';
import { throttle, detectMobileBrowser, getBrowserNavigatorMetaInfo } from '@/utils/tool';
import CanvasControl from './components/CanvasControl';
import PageHeader from './components/PageHeader';
import Preview from './components/Preview';
import DropBox from './DropBox';
import DragBox from './DragBox';
import Calibration from '@/components/Calibration';
import basicTemplate from '@/components/BasicShop/BaseComponents/template';
import optionTemplate from '@/components/BasicShop/OptionComponents/template';
import dateTemplate from '@/components/BasicShop/DateComponents/template';
import readonlyTemplate from '@/components/BasicShop/ReadonlyComponents/template';
import schemaH5 from '@/components/BasicShop/schema';
import { IDetailParams } from './service';
const styles = require('./index.less');
const { TabPane } = Tabs;
const { confirm } = Modal;
const formItemLayout = {
    labelCol: { span: 6 },
    wrapperCol: { span: 16 },
};

interface IProps {
    history?: any;
    location?: any;
    pstate?: any;
    cstate?: any;
    dispatch?: any;
}
interface IComponentIconType {
    [key: string]: any;
}

const Container = (props: IProps) => {
    let canvasId = 'js_canvas';
    const params = useParams();
    const [form] = Form.useForm();
    const { pstate, cstate, dispatch } = props;
    const [scale, setScale] = useState(1);
    const [collapsed, setCollapsed] = useState(false);
    const [rightCollapsed, setRightCollapsed] = useState(true);
    const [previewModal, setPreviewModal] = useState(false);
    const [diffmove, setDiffMove] = useState({
        start: { x: 0, y: 0 },
        move: false,
    });
    const [dragstate, setDragState] = useState({ x: 0, y: 0 });
    const pointData = pstate ? pstate.pointData : [];
    const cpointData = cstate ? cstate.pointData : [];
    const curPoint = pstate ? pstate.curPoint : {};
    const title = pstate ? pstate.title : '';
    const containerRef = useRef<HTMLDivElement>(null);
    const ComponentIcon: IComponentIconType = {
        base: <AppstoreOutlined />,
        page: <FileTextOutlined />,
        template: <CopyOutlined />
    };

    const changeCollapsed = useMemo(() => {
        return (c: boolean) => {
            setCollapsed(c);
        }
    }, []);

    const changeRightCollapsed = useMemo(() => {
        return (c: boolean) => {
            setRightCollapsed(c);
        }
    }, []);

    const generateHeader = useMemo(() => {
        return (type: componentsType, text: string) => {
            return (
                <div className={styles.iconWrap} title={text}>
                    {ComponentIcon[type]} {text}
                </div>
            );
        };
    }, [ComponentIcon]);

    const handleSlider = useMemo(() => {
        return (type: any) => {
            if (type) {
                setScale(
                    (prev: number) => +(prev + 0.1).toFixed(1)
                );
            } else {
                setScale(
                    (prev: number) => +(prev - 0.1).toFixed(1)
                );
            }
        }
    }, []);

    const tabRender = useMemo(() => {
        if (collapsed) {
            return (
                <>
                    <TabPane tab={generateHeader('base', '组件库')} key="1" />
                    <TabPane tab={generateHeader('page', '页面设置')} key="2" />
                    <TabPane tab={generateHeader('template', '模板库')} key="3" />
                </>
            );
        } else {
            return (
                <>
                    <TabPane tab={generateHeader('base', '')} key="1" >
                        <div className={styles.ctitle}>基础类型</div>
                        <Row
                            gutter={[12, 32]}
                            style={{
                                padding: '0 30px'
                            }}
                        >
                            {
                                basicTemplate.map((value, i) => (
                                    <Col span={12} key={i}>
                                        <DragBox
                                            canvasId={canvasId}
                                            item={value}
                                        >
                                            <DynamicEngine
                                                {...value}
                                                componentsType="base"
                                                config={schemaH5[value.type as keyof typeof schemaH5].config}
                                                isTpl={true}
                                            />
                                        </DragBox>
                                    </Col>
                                ))
                            }
                        </Row>
                        <div className={styles.ctitle}>选项类型</div>
                        <Row
                            gutter={[12, 32]}
                            style={{
                                padding: '0 30px'
                            }}
                        >
                            {
                                optionTemplate.map((value, i) => (
                                    <Col span={12} key={i}>
                                        <DragBox
                                            canvasId={canvasId}
                                            item={value}
                                        >
                                            <DynamicEngine
                                                {...value}
                                                componentsType="option"
                                                config={schemaH5[value.type as keyof typeof schemaH5].config}
                                                isTpl={true}
                                            />
                                        </DragBox>
                                    </Col>
                                ))
                            }
                        </Row>
                        <div className={styles.ctitle}>日期类型</div>
                        <Row
                            gutter={[12, 32]}
                            style={{
                                padding: '0 30px'
                            }}
                        >
                            {
                                dateTemplate.map((value, i) => (
                                    <Col span={12} key={i}>
                                        <DragBox
                                            canvasId={canvasId}
                                            item={value}
                                        >
                                            <DynamicEngine
                                                {...value}
                                                componentsType="date"
                                                config={schemaH5[value.type as keyof typeof schemaH5].config}
                                                isTpl={true}
                                            />
                                        </DragBox>
                                    </Col>
                                ))
                            }
                        </Row>
                        <div className={styles.ctitle}>只读类型</div>
                        <Row
                            gutter={[12, 32]}
                            style={{
                                padding: '0 30px'
                            }}
                        >
                            {
                                readonlyTemplate.map((value, i) => (
                                    <Col span={12} key={i}>
                                        <DragBox
                                            canvasId={canvasId}
                                            item={value}
                                        >
                                            <DynamicEngine
                                                {...value}
                                                componentsType="readonly"
                                                config={schemaH5[value.type as keyof typeof schemaH5].config}
                                                isTpl={true}
                                            />
                                        </DragBox>
                                    </Col>
                                ))
                            }
                        </Row>
                    </TabPane>
                    <TabPane tab={generateHeader('page', '')} key="2" >
                        <div className={styles.ctitle}>页面设置</div>
                    </TabPane>
                    <TabPane tab={generateHeader('template', '')} key="3" >
                        <div className={styles.ctitle}>模板库</div>
                    </TabPane>
                </>
            );
        }
    }, [canvasId, collapsed, generateHeader, basicTemplate, schemaH5]);

    const allType = useMemo(() => {
        let arr: string[] = [];
        basicTemplate.concat(optionTemplate, dateTemplate, readonlyTemplate).forEach(v => {
            arr.push(v.type);
        });
        return arr;
    }, [basicTemplate]);

    const mouseupfn = useMemo(() => {
        return () => {
            setDiffMove({
                start: { x: 0, y: 0 },
                move: false,
            });
        };
    }, []);

    const mousedownfn = useMemo(() => {
        return (e: MouseEvent<HTMLDivElement>) => {
            if (e.target === containerRef.current) {
                setDiffMove({
                    start: {
                        x: e.clientX,
                        y: e.clientY,
                    },
                    move: true,
                });
            }
        };
    }, []);

    const mousemovefn = useMemo(() => {
        return (e: MouseEvent<HTMLDivElement>) => {
            if (diffmove.move) {
                let diffx: number;
                let diffy: number;
                const newX = e.clientX;
                const newY = e.clientY;
                diffx = newX - diffmove.start.x;
                diffy = newY - diffmove.start.y;
                setDiffMove({
                    start: {
                        x: newX,
                        y: newY,
                    },
                    move: true,
                });
                setDragState(prev => {
                    return {
                        x: prev.x + diffx,
                        y: prev.y + diffy,
                    };
                });
            }
        }
    }, [diffmove.move, diffmove.start.x, diffmove.start.y]);

    const onwheelfn = useMemo(() => {
        return (e: WheelEvent<HTMLDivElement>) => {
            if (e.deltaY < 0) {
                setDragState(prev => ({
                    x: prev.x,
                    y: prev.y + 40,
                }));
            } else {
                setDragState(prev => ({
                    x: prev.x,
                    y: prev.y - 40,
                }));
            }
        };
    }, []);

    const backSize = () => {
        setScale(1);
        setDragState({ x: 0, y: 0 });
    }

    const handleFormSave = useMemo(() => {
        return (data: any) => {
            dispatch({
                type: 'editorModal/modPointData',
                payload: {
                    ...curPoint,
                    item: {
                        ...curPoint.item,
                        config: data
                    }
                }
            });
        }
    }, [curPoint, dispatch]);

    const handleDel = useMemo(() => {
        return (id: any) => {
            dispatch({
                type: 'editorModal/delPointData',
                payload: { id }
            });
        };
    }, [dispatch]);

    const redohandler = useMemo(() => {
        return () => {
            dispatch(ActionCreators.redo());
        }
    }, [dispatch]);

    const undohandler = useMemo(() => {
        return () => {
            dispatch(ActionCreators.undo());
        }
    }, [dispatch]);

    const importTpl = (data: any) => {
        dispatch({
            type: 'editorModal/importTplData',
            payload: data,
        });
    };

    const renderRight = useMemo(() => {
        return (
            <div
                className={styles.attrSetting}
                style={{
                    transition: 'all ease-in-out 0.5s',
                    transform: rightCollapsed ? 'translate(100%,0)' : 'translate(0,0)',
                }}
            >
                <Form
                    form={form}
                    {...formItemLayout}
                >
                    <Form.Item
                        label={'页面标题'}
                        name={'title'}
                        rules={[
                            {
                                required: true,
                                message: '请输入页面标题!',
                            },
                        ]}
                    >
                        <Input />
                    </Form.Item>
                </Form>
                {
                    pointData.length && curPoint ? (
                        <>
                            <div className={styles.tit}>页面设置</div>
                            <FormRender
                                config={curPoint.item.editableEl}
                                uid={curPoint.id}
                                defaultValue={curPoint.item.config}
                                onSave={handleFormSave}
                                onDel={handleDel}
                            />
                        </>
                    ) : (
                            <div style={{ paddingTop: '100px' }}>
                                <Result status="404" title="暂无数据" subTitle="请拖拽组件生成H5页面" />
                            </div>
                        )
                }
            </div>
        )
    }, [cpointData.length, curPoint, handleDel, handleFormSave, pointData.length, rightCollapsed]);

    const saveOrSubmit = (type: number): void => {
        form.validateFields().then(() => {
            if (history.location.pathname.indexOf('modify') > -1) {
                dispatch({
                    type: 'editorModal/updatePointData',
                    payload: {
                        id: +(params as IDetailParams).id,
                        title: form.getFieldValue('title'),
                        status: type,
                        content: JSON.stringify(pointData)
                    }
                }).then((response: any) => {
                    if (response.success) {
                        notification.success({
                            message: type === 0 ? '保存成功' : '提交成功',
                        });
                        history.goBack();
                    } else {
                        notification.error({
                            message: response.message || '操作失败',
                        });
                    }
                });
            } else {
                dispatch({
                    type: 'editorModal/savePointData',
                    payload: {
                        title: form.getFieldValue('title'),
                        status: type,
                        content: JSON.stringify(pointData)
                    }
                }).then((response: any) => {
                    if (response.success) {
                        notification.success({
                            message: type === 0 ? '保存成功' : '提交成功',
                        });
                        history.goBack();
                    } else {
                        notification.error({
                            message: response.message || '操作失败',
                        });
                    }
                });
            }
        }).catch((error) => {
            if (rightCollapsed) {
                setRightCollapsed(false);
            }
        })
    }

    useEffect(() => {
        // note (@livs-ops)
        if (detectMobileBrowser(getBrowserNavigatorMetaInfo())) {
            props.history.push('/mobileTip');
        }
        if (history.location.pathname.indexOf('modify') > -1) {
            dispatch({
                type: 'editorModal/fetchPointData',
                payload: {
                    id: Number((params as IDetailParams).id),
                }
            })
        } else {
            dispatch({
                type: 'editorModal/importTplData',
                payload: [],
            })
        }
        // eslint-disable-next-line react-hooks/exhaustive-deps
    }, []);

    useEffect(() => {
        form.setFieldsValue({
            title,
        });
    },[title]);

    useEffect(() => {
        if (diffmove.move && containerRef.current) {
            containerRef.current.style.cursor = 'move';
        } else {
            containerRef.current!.style.cursor = 'default';
        }
    }, [diffmove.move]);

    useEffect(() => {
        if (pstate.curPoint && pstate.curPoint.status === 'inToCanvas') {
            setRightCollapsed(false);
        }
    }, [pstate.curPoint]);

    return (
        <div className={styles.editorWrap}>
            <PageHeader
                title={history.location.pathname.indexOf('modify') > -1 ? '修改H5页面' : '创建H5页面'}
                onPreview={() => {
                    setPreviewModal(true);
                }}
                onSave={() => {
                    confirm({
                        title: '提示',
                        icon: <ExclamationCircleOutlined />,
                        content: '点击确认按钮后，H5页面设置信息将保存至草稿箱，确认要进行保存吗？',
                        okText: '确认',
                        cancelText: '取消',
                        onOk() {
                            saveOrSubmit(0);
                        },
                        onCancel() { },
                    });
                }}
                onSubmit={() => {
                    confirm({
                        title: '提示',
                        icon: <ExclamationCircleOutlined />,
                        content: '点击确认按钮后，H5页面设置信息将提交至管理员进行审核，确认要进行提交吗？',
                        okText: '确认',
                        cancelText: '取消',
                        onOk() {
                            saveOrSubmit(1);
                        },
                        onCancel() { },
                    });
                }}
                onBack={() => {
                    confirm({
                        title: '提示',
                        icon: <ExclamationCircleOutlined />,
                        content: '退出后，当前编辑内容将不进行保存，是否确认退出？',
                        okText: '确认',
                        cancelText: '取消',
                        onOk() {
                            history.goBack();
                        },
                        onCancel() { },
                    });
                }}
            />
            <div className={styles.container}>
                {/* 拖动组件库 */}
                <div
                    className={styles.list}
                    style={{
                        position: 'fixed',
                        width: collapsed ? '50px' : '350px',
                        transition: 'all ease-in-out 0.5s',
                        zIndex: 200,
                    }}
                >
                    <div
                        className={styles.componentList}
                    >
                        <Tabs
                            className="editorTabclass"
                            defaultActiveKey="1"
                            onTabClick={() => changeCollapsed(false)}
                            tabBarStyle={{
                                width: '100%'
                            }}
                            tabPosition={collapsed ? "left" : "top"}
                            type="card"
                        >
                            {tabRender}
                        </Tabs>
                    </div>
                    {/* <div
                        className={styles.collapsed}
                        style={{
                            position: 'absolute',
                            bottom: '80px', 
                            left: '20px'
                        }}
                        onClick={() => changeCollapsed(!collapsed)}
                    >
                        {collapsed ? <DoubleRightOutlined /> : <DoubleLeftOutlined />}
                    </div> */}
                </div>
                {/* placeholder */}
                <div
                    style={{
                        width: collapsed ? '50px' : '350px',
                        transition: 'all ease-in-out 0.5s',
                    }}
                >
                </div>
                <div
                    id="calibration"
                    ref={containerRef}
                    className={styles.tickMark}
                    onMouseUp={mouseupfn}
                    onMouseDown={mousedownfn}
                    onMouseMove={throttle(mousemovefn, 500)}
                    onMouseLeave={mouseupfn}
                    onWheel={onwheelfn}
                >
                    <div
                        className={styles.tickMarkTop}
                    >
                        <Calibration
                            id="calibrationUp"
                            direction="up"
                            multiple={scale}
                        />
                    </div>
                    <div
                        className={styles.tickMarkLeft}
                    >
                        <Calibration
                            id="calibrationRight"
                            direction="right"
                            multiple={scale}
                        />
                    </div>
                    <DropBox
                        allType={allType}
                        canvasId={canvasId}
                        dragState={dragstate}
                        setDragState={setDragState}
                        scaleNum={scale}
                    />
                    {/* 画布控制滑块 */}
                    {/* <CanvasControl 
                        backSize={backSize}
                        scaleNum={scale}
                        handleSlider={handleSlider}
                    /> */}
                </div>
                {renderRight}
                <div
                    className={styles.rightcolla}
                    style={{
                        position: 'absolute',
                        right: rightCollapsed ? 0 : '320px',
                        transform: 'translate(0,-50%)',
                        transition: 'all ease-in-out 0.5s',
                    }}
                    onClick={() => changeRightCollapsed(!rightCollapsed)}
                >
                    {
                        !rightCollapsed ? <DoubleRightOutlined /> : <DoubleLeftOutlined />
                    }
                </div>
                {/* placeholder */}
                <div
                    style={{
                        width: rightCollapsed ? 0 : '320px',
                        transition: 'all ease-in-out 0.5s',
                    }}
                >
                </div>
            </div>
            <Modal
                className={styles.previewModal}
                visible={previewModal}
                onCancel={() => setPreviewModal(false)}
            >
                <Preview />
            </Modal>
        </div>
    )
}

export default connect((state: any) => {
    return {
        pstate: state.editorModal,
        cstate: state.editorPcModal
    };
})(Container);
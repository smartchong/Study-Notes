import request from '@/utils/request';
import API from '@/services/api';

export interface IDetailParams {
  id: number;
}

export interface IShortStrParams {
  shortStr: string;
}

export interface ISaveParams {
  id?: number;
  content: string;
  status: number;
  title: string;
}

// 保存
export async function save(params: ISaveParams) {
  return request(`${API.HFMANAGE.SAVE}`, {
    method: 'POST',
    data: params,
  });
}

// 更新
export async function update(params: ISaveParams) {
  return request(`${API.HFMANAGE.UPDATE}`, {
    method: 'POST',
    data: params,
  });
}

// 详情
export async function fetchDetail(params: IDetailParams) {
  return request(`${API.HFMANAGE.DETAIL}?id=${params.id}`, {
    method: 'POST',
    data: params,
  });
}

// 根据短链获取详情
export async function fetchDetailByShortStr(params: IShortStrParams) {
  return request(`${API.HFMANAGE.SHORTLINK}`, {
    params,
  });
}

# Ant Design Pro

This project is initialized with [Ant Design Pro](https://pro.ant.design). Follow is the quick guide for how to use.

## Environment Prepare

Install `node_modules`:

```bash
npm install
```

or

```bash
yarn
```

## Provided Scripts

Ant Design Pro provides some useful script to help you quick start and build with web project, code style check and test.

Scripts provided in `package.json`. It's safe to modify or add additional script:

### Start project

```bash
npm start
```

### Build project

```bash
npm run build
```

### Check code style

```bash
npm run lint
```

You can also use script to auto fix some lint error:

```bash
npm run lint:fix
```

### Test code

```bash
npm test
```

## More

You can view full document on our [official website](https://pro.ant.design). And welcome any feedback in our [github](https://github.com/ant-design/ant-design-pro).

## H5 页面管理系统

### 技术栈

- **React** 前端框架
- **dva** 状态管理库
- **less** css 预编译语言
- **umi** 插件化的企业级前端应用框架
- **antd** PC 端组件库
- **ant-mobile** 移动端组件库
- **react-dnd** 基于 react 的拖放库 [文档](https://react-dnd.github.io/react-dnd/examples/tutorial)

### 系统结构 

- **入口** [文件位置](./src/layouts/H5Layout.tsx)
- **页面容器** [文件位置](./src/pages/h5Editor/Container.tsx)
- **拖动容器** [文件位置](./src/pages/h5Editor/DragBox.tsx)
- **放置容器** [文件位置](./src/pages/h5Editor/DropBox.tsx)
- **右侧编辑器** [文件位置](./src/core/FormRender.tsx)
- **预览组件** [文件位置](./src/pages/h5Editor/components/Preview/index.tsx)
- **自定义拖放组件库** [文件位置](./src/components/BasicShop/schema.ts)




/**
 * 在生产环境 代理是无法生效的，所以这里没有生产环境的配置
 * The agent cannot take effect in the production environment
 * so there is no configuration of the production environment
 * For details, please see
 * https://pro.ant.design/docs/deploy
 */
//old http://172.27.12.61:9991
//dev http://172.21.25.171:9991
//pro http://172.28.27.64:9991

export default {
  dev: {
    '/portal': {
      target: 'http://172.21.25.171:9991',
      // target: 'http://172.18.35.2:9991',
      // target: 'http://127.0.0.1:9991',
      changeOrigin: true,
      pathRewrite: {
        '^': '',
      },
    },
  },
  test: {
    '/portal': {
      target: 'http://172.21.25.26:9991',
      changeOrigin: true,
      pathRewrite: {
        '^': '',
      },
    },
  },
  pre: {
    '/': {
      target: '',
      changeOrigin: true,
      pathRewrite: {
        '^': '',
      },
    },
  },
};

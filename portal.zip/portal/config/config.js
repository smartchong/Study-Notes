// https://umijs.org/config/
import path from 'path';
import { defineConfig, utils } from 'umi';
import defaultSettings from './defaultSettings';
import proxy from './proxy';
import webpackPlugin from './plugin.config';
const { winPath } = utils; // preview.pro.ant.design only do not use in your production ;
// preview.pro.ant.design 专用环境变量，请不要在你的项目中使用它。

const { ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION, REACT_APP_ENV, GA_KEY, NODE_ENV } = process.env;

export default defineConfig({
  base: '/',
  publicPath: NODE_ENV === 'development' ? '/' : '/portal/',
  hash: true,
  history: { type: 'hash' },
  alias:{
    assets: path.resolve(__dirname, 'src/assets/'),
    components: path.resolve(__dirname,'src/components/')
  },
  antd: {},
  analytics: GA_KEY
    ? {
        ga: GA_KEY,
      }
    : false,
  dva: {
    hmr: true,
  },
  locale: {
    // default zh-CN
    default: 'zh-CN',
    // default true, when it is true, will use `navigator.language` overwrite default
    antd: true,
    baseNavigator: true,
  },
  dynamicImport: {
    loading: '@/components/PageLoading/index',
  },
  targets: {
    ie: 11,
  },
  // umi routes: https://umijs.org/docs/routing
  routes: [
    {
      path: '/',
      component: '../layouts/SecurityLayout',
      routes: [
        {
          path: '/',
          component: './Home',
        },
        {
          path: '/user',
          component: '../layouts/UserLayout',
          routes: [
            {
              name: 'login',
              path: '/user/login',
              component: './user/login',
            },
            {
              name: 'register-result',
              path: '/user/register-result',
              component: './user/register-result',
            },
            {
              name: 'register',
              path: '/user/register',
              component: './user/register',
            },
            {
              name: 'retrieve-validate',
              path: '/user/retrieve-validate',
              component: './user/retrieve',
            },
            {
              name: 'retrieve-reset',
              path: '/user/retrieve-reset',
              component: './user/retrieve/reset',
            },
            {
              name: 'retrieve-result',
              path: '/user/retrieve-result',
              component: './user/retrieve/result',
            },
            {
              component: '404',
            },
          ],
        },
        // 门户子系统
        {
          path: '/layouts',
          component: '../layouts/BasicLayout',
          Routes: ['src/pages/Authorized'],
          authority: ['admin', 'user'],
          routes: [
            // 应用管理
            {
              name: 'app',
              icon: 'AppstoreOutlined',
              path: '/layouts/app',
              routes: [
                // 应用列表
                {
                  name: 'list',
                  path: '/layouts/app/list',
                  component: './app',
                },
                // 应用详情
                {
                  name: 'details',
                  path: '/layouts/app/list/details/:id',
                  component: './app/details',
                  hideInMenu: true,
                },
                // 创建应用
                {
                  name: 'create',
                  path: '/layouts/app/create',
                  component: './app/create',
                  hideInMenu: true,
                },
                // 修改应用
                {
                  name: 'edit',
                  path: '/layouts/app/edit/:id',
                  component: './app/edit',
                  hideInMenu: true,
                },
              ]
            },
            // 媒体管理
            {
              name: 'media',
              icon: 'PlayCircleOutlined',
              path: '/layouts/media',
              routes: [
                // 媒体列表
                {
                  name: 'list',
                  path: '/layouts/media/table-list',
                  component: './media/table-list',
                }
              ]
            },
            //h5页面列表
            {
              path: '/layouts/hfManage',
              name: 'hfManage',
              icon: 'Html5Outlined',
              routes: [
                {
                  name: 'list',
                  path: '/layouts/hfManage/list',
                  component: './hfManage',
                }
              ]
            },
            // 短信管理
            {
              name: 'smsApplet',
              icon: 'message',
              path: '/layouts/smsApplet',
              routes:[
                {
                  name: 'template',
                  path: '/layouts/smsApplet/template',
                  component: './smsApplet/template',
                },
                {
                  name: 'template.add',
                  path: '/layouts/smsApplet/template/add',
                  component: './smsApplet/template/add',
                  hideInMenu: true,
                },
                {
                  name: 'template.modify',
                  path: '/layouts/smsApplet/template/modify/:id',
                  component: './smsApplet/template/modify',
                  hideInMenu: true,
                },
                {
                  name: 'template.details',
                  path: '/layouts/smsApplet/template/details/:id',
                  component: './smsApplet/template/details',
                  hideInMenu: true,
                },
                {
                  name: 'shortLink',
                  path: '/layouts/smsApplet/shortLink',
                  component: './smsApplet/shortLink',
                },
                {
                  name: 'shortLink.add',
                  path: '/layouts/smsApplet/shortLink/add',
                  component: './smsApplet/shortLink/add',
                  hideInMenu: true,
                },
                {
                  name: 'shortLink.modify',
                  path: '/layouts/smsApplet/shortLink/modify/:id',
                  component: './smsApplet/shortLink/modify',
                  hideInMenu: true,
                },
                {
                  name: 'shortLink.details',
                  path: '/layouts/smsApplet/shortLink/details/:id',
                  component: './smsApplet/shortLink/details',
                  hideInMenu: true,
                },
              ],
            },
            // 模板管理
            {
              name: 'template',
              icon: 'NumberOutlined',
              path: '/layouts/template',
              component: './template/layout',
              routes:[
                // 模板列表
                {
                  name: 'templateList',
                  path: '/layouts/template/list',
                  component: './template',
                },
                // 创建模板
                {
                  name: 'templateCreate',
                  path: '/layouts/template/create',
                  component: './template/create',
                  hideInMenu: true,
                },
                // 修改模板
                {
                  name: 'templateEdit',
                  path: '/layouts/template/edit/:id',
                  component: './template/edit',
                  hideInMenu: true,
                },
              ]
            },
            // 收信人管理
            {
              name:'recipient',
              icon:'MailOutlined',
              path:'/layouts/recipient',
              routes:[
                // 收信人列表
                {
                  name:'list',
                  path:'/layouts/recipient/recipientlist',
                  component:'./recipient/recipientlist',
                },
                // 黑名单列表
                {
                  name:'blacklist',
                  path:'/layouts/recipient/blacklist',
                  component:'./recipient/blacklist',
                }
              ]
            },
            // 发送管理
            {
              name: 'send',
              icon: 'NotificationOutlined',
              path: '/layouts/send',
              routes: [
                // 群发管理
                {
                  name: 'massSend',
                  path: '/layouts/send/massSend',
                  component: './send/massSend',
                },
                // 单发测试
                {
                  name: 'testSend',
                  path: '/layouts/send/testSend',
                  component: './send/testSend',
                },
              ]
            },
            // 收发记录
            {
              name: 'msgRecord',
              icon: 'form',
              path: '/layouts/msgRecord',
              routes:[
                // 收发记录列表
                {
                  name: 'list',
                  path: '/layouts/msgRecord/list',
                  component: './msgRecord/index',
                },
                // 收发记录详情
                {
                  name: 'details',
                  path: '/layouts/msgRecord/details/:id',
                  component: './msgRecord/details',
                  hideInMenu: true,
                },
              ]
            },
            // 消息统计
            {
              name: 'msgStatistics',
              icon: 'LineChartOutlined',
              path: '/layouts/msgStatistics',
              routes:[
                // 发送数据
                {
                  name: 'sendMsg',
                  path: '/layouts/msgStatistics/sendMsg',
                  component: './msgStatistics/sendMsg',
                },
                // 发送数据详情
                {
                  name: 'details',
                  path: '/layouts/msgStatistics/sendMsg/details',
                  component: './msgStatistics/sendMsg/details',
                  hideInMenu: true,
                },
                // 交互数据
                {
                  name: 'interMsg',
                  path: '/layouts/msgStatistics/interMsg',
                  component: './msgStatistics/interMsg',
                }
              ]
            },
            // 配置管理
            {
              name: 'config',
              icon: 'SettingOutlined',
              path: '/layouts/config',
              routes:[
                {
                  name: 'list',
                  path: '/layouts/config/table-list',
                  component: './config/table-list',
                }
              ]
            },
            // 用户中心
            {
              name: 'userCenter',
              icon: 'UserOutlined',
              path: '/layouts/userCenter',
              routes:[
                {
                  name: 'account',
                  path: '/layouts/userCenter/account',
                  component: './userCenter/account',
                },
                {
                  name: 'changePWD',
                  path: '/layouts/userCenter/changePWD',
                  component: './userCenter/changePWD',
                },
                {
                  name: 'authInfo',
                  path: '/layouts/userCenter/authInfo',
                  component: './userCenter/authInfo',
                },
              ],
            },
            // 产品管理
            {
              name: 'product',
              icon: 'ShopOutlined',
              path: '/layouts/product',
              hideInMenu: false,
              routes: [
                // 硬件产品管理
                {
                  name: 'hardware',
                  path: '/layouts/product/hardware',
                  component: './product/hardware',
                },
                {
                  name: 'hardware.details',
                  path: '/layouts/product/hardware/details/:id',
                  component: './product/hardware/details',
                  hideInMenu: true,
                },
                // 内容产品管理
                {
                  name: 'content',
                  path: '/layouts/product/content',
                  component: './product/content',
                },
                {
                  name: 'content.details',
                  path: '/layouts/product/content/details/:id',
                  component: './product/content/details',
                  hideInMenu: true,
                },
              ]
            },
            // 订单管理
            {
              name: 'order',
              icon: 'ShoppingOutlined',
              path: '/layouts/order',
              hideInMenu: false,
              routes: [
                // 硬件订单管理
                {
                  name: 'hardware',
                  path: '/layouts/order/hardware',
                  component: './order/hardware',
                },
                {
                  name: 'hardware.details',
                  path: '/layouts/order/hardware/details/:id',
                  component: './order/hardware/details',
                  hideInMenu: true,
                },
                // 内容订单管理
                {
                  name: 'content',
                  path: '/layouts/order/content',
                  component: './order/content',
                },
                {
                  name: 'content.details',
                  path: '/layouts/order/content/details/:id',
                  component: './order/content/details',
                  hideInMenu: true,
                },
              ]
            },
            {
              component: './404',
            },
          ],
        },
        // 能力中台单点登录
        {
          path: '/nlzt',
          component: '../layouts/SSOLayout',
          routes: [
            // 媒体管理
            {
              name: 'media',
              path: '/nlzt/media',
              routes: [
                // 媒体列表
                {
                  name: 'list',
                  path: '/nlzt/media/list',
                  component: './media/table-list',
                }
              ]
            },
            // 模板管理
            {
              name: 'template',
              path: '/nlzt/template',
              component: './template/layout',
              routes:[
                // 模板列表
                {
                  name: 'templateList',
                  path: '/nlzt/template/list',
                  component: './template',
                },
                // 创建模板
                {
                  name: 'templateCreate',
                  path: '/nlzt/template/create',
                  component: './template/create',
                  hideInMenu: true,
                },
                // 修改模板
                {
                  name: 'templateEdit',
                  path: '/nlzt/template/edit/:id',
                  component: './template/edit',
                  hideInMenu: true,
                },
              ]
            },
            // 配置管理
            {
              name: 'config',
              icon: 'SettingOutlined',
              path: '/nlzt/config',
              routes:[
                {
                  name: 'list',
                  path: '/nlzt/config/table-list',
                  component: './config/table-list',
                }
              ]
            },
          ],
        },
        // 云名片子系统
        {
          path: '/cloudCard',
          component: '../layouts/CloudCardLayout',
          routes: [
            // 电子名片
            {
              name: 'vCard',
              icon: 'IdcardOutlined',
              path: '/cloudCard/vCard',
              routes: [
                {
                  name: 'my',
                  path: '/cloudCard/vCard/my',
                  component: './vCard',
                }
              ]
            },
            // 成员管理
            {
              name: 'member',
              icon: 'TeamOutlined',
              path: '/cloudCard/member',
              routes:[
                {
                  name: 'list',
                  path: '/cloudCard/member/list',
                  component: './member',
                },
                // {
                //   name: 'modify',
                //   path: '/cloudCard/member/modify/:id',
                //   component: './member/modify',
                //   hideInMenu: true,
                // },
                {
                  name: 'details',
                  path: '/cloudCard/member/details/:id',
                  component: './member/details',
                  hideInMenu: true,
                },
              ]
            }
          ],
        },
        // H5页面管理系统
        {
          path: '/h5Editor',
          component: '../layouts/H5Layout',
          routes: [
            {
              name: 'add',
              path: '/h5Editor/add',
              component: './h5Editor',
            },
            {
              name: 'modify',
              path: '/h5Editor/modify/:id',
              component: './h5Editor',
            }
          ]
        },
        // H5
        {
          path: '/h5/:shortStr',
          component: '../pages/h5Editor/h5Page',
        },
      ],
    },
  ],
  // Theme for antd: https://ant.design/docs/react/customize-theme-cn
  theme: {
    // ...darkTheme,
    'primary-color': defaultSettings.primaryColor,
  },
  define: {
    REACT_APP_ENV: REACT_APP_ENV || false,
    ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION:
      ANT_DESIGN_PRO_ONLY_DO_NOT_USE_IN_YOUR_PRODUCTION || '', // preview.pro.ant.design only do not use in your production ; preview.pro.ant.design 专用环境变量，请不要在你的项目中使用它。
  },
  ignoreMomentLocale: true,
  lessLoader: {
    javascriptEnabled: true,
  },
  extraPostCSSPlugins:[
    require('postcss-flexbugs-fixes'),
    require('autoprefixer'),
  ],
  cssLoader: {
    modules: {
      getLocalIdent: (context, _, localName) => {
        if (
          context.resourcePath.includes('node_modules') ||
          context.resourcePath.includes('ant.design.pro.less') ||
          context.resourcePath.includes('global.less')
        ) {
          return localName;
        }

        const match = context.resourcePath.match(/src(.*)/);

        if (match && match[1]) {
          const antdProPath = match[1].replace('.less', '');
          const arr = winPath(antdProPath)
            .split('/')
            .map(a => a.replace(/([A-Z])/g, '-$1'))
            .map(a => a.toLowerCase());
          return `antd-pro${arr.join('-')}-${localName}`.replace(/--/g, '-');
        }

        return localName;
      },
    },
  },
  manifest: {
    basePath: '/',
  },
  proxy: proxy[REACT_APP_ENV || 'dev'],
  chainWebpack: webpackPlugin,
});

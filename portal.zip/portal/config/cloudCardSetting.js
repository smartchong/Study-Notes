export default {
    navTheme: 'dark',
    primaryColor: "#1890ff",
    breakpoint: false,
    contentWidth: 'Fluid',
    fixedHeader: true,
    fixSiderbar: true,
    menu: {
        locale: true,
    },
    title: '云名片系统',
    pwa: false,
    iconfontUrl: '',
};
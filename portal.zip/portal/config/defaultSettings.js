export default {
  navTheme: 'dark',
  primaryColor: '#1890ff',
  contentWidth: 'Fluid',
  fixedHeader: true,
  fixSiderbar: false,
  autoHideHeader: false,
  colorWeak: false,
  breakpoint: false,
  menu: {
    locale: true,
  },
  title: '5G智慧家庭Chatbot服务平台',
  pwa: false,
  iconfontUrl: '',
};

(function () {
  var deviceWidth = document.documentElement.clientWidth;
  // if(deviceWidth > 640) deviceWidth = 640;
  document.documentElement.style.fontSize = deviceWidth / 6.4 + 'px';
})();

function closePage() {
  var userAgent = navigator.userAgent;
  if (userAgent.indexOf("Firefox") != -1 || userAgent.indexOf("Chrome") !=-1) {
    window.location.href="about:blank";
  }else if(userAgent.indexOf('Android') > -1 || userAgent.indexOf('Linux') > -1){
    window.opener=null;window.open('about:blank','_self','').close();
  }else {
    window.opener = null;
    window.open("about:blank", "_self");
    window.close();
  }
}

function openPage(url) {
  document.location.href = url + '?random=' + Math.random();
}

function picker(isShow) {
  if(isShow){
    document.getElementById('picker').classList.add('show')
  }else {
    document.getElementById('picker').classList.remove('show')
  }
}
